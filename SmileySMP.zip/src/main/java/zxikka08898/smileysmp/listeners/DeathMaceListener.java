package zxikka08898.smileysmp.listeners;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import zxikka08898.smileysmp.commands.DeathMaceCommand;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class DeathMaceListener implements Listener {

    private final JavaPlugin plugin;
    private final Set<UUID> activeAnimations = new HashSet<>();
    private static final String DEATH_MACE_PLAIN = "Death Mace";

    public DeathMaceListener(JavaPlugin plugin) {
        this.plugin = plugin;
        startDeathMaceChecker();
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        // Ensure all players are tracked
    }

    private void startDeathMaceChecker() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    checkAndTriggerAnimation(player);
                }
            }
        }.runTaskTimer(plugin, 0L, 100L); // Check every 5 seconds (100 ticks)
    }

    private void checkAndTriggerAnimation(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        
        if (item == null || !item.hasItemMeta() || item.getItemMeta().displayName() == null) {
            return;
        }

        // Get the plain text version of the item name
        String itemName = PlainTextComponentSerializer.plainText().serialize(item.getItemMeta().displayName());

        // Check if it's the Death Mace
        if (itemName.equals(DEATH_MACE_PLAIN) && !activeAnimations.contains(player.getUniqueId())) {
            activeAnimations.add(player.getUniqueId());
            startStormAnimation(player);
        }
    }

    private void startStormAnimation(Player player) {
        new BukkitRunnable() {
            int tick = 0;
            final int maxTicks = 25;
            final double startHeight = 2.2;
            final double radius = 1.2;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    activeAnimations.remove(player.getUniqueId());
                    this.cancel();
                    return;
                }

                // Calculate descending height
                double progress = (double) tick / maxTicks;
                double currentHeight = startHeight * (1 - progress);

                Location playerLoc = player.getLocation();
                
                // Create circular/spiral pattern
                for (int i = 0; i < 8; i++) {
                    double angle = (tick * 0.5 + i * 45) * Math.PI / 180;
                    double x = playerLoc.getX() + radius * Math.cos(angle);
                    double y = playerLoc.getY() + currentHeight;
                    double z = playerLoc.getZ() + radius * Math.sin(angle);
                    
                    Location particleLoc = new Location(playerLoc.getWorld(), x, y, z);

                    // Spawn mixed particles
                    if (i % 2 == 0) {
                        playerLoc.getWorld().spawnParticle(Particle.FLAME, particleLoc, 1, 0.1, 0.1, 0.1, 0.01);
                    } else {
                        playerLoc.getWorld().spawnParticle(Particle.LAVA, particleLoc, 1, 0, 0, 0, 0);
                    }

                    // Deep red dust
                    Particle.DustOptions dustOptions = new Particle.DustOptions(Color.fromRGB(255, 0, 0), 1.5f);
                    playerLoc.getWorld().spawnParticle(Particle.DUST, particleLoc, 2, 0.05, 0.05, 0.05, dustOptions);

                    // Gust particle for wind effect
                    if (tick % 3 == 0) {
                        playerLoc.getWorld().spawnParticle(Particle.GUST, particleLoc, 1, 0.2, 0.2, 0.2, 0);
                    }
                }

                tick++;

                if (tick >= maxTicks) {
                    activeAnimations.remove(player.getUniqueId());
                    this.cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}

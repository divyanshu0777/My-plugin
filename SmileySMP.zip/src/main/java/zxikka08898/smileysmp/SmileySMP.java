package zxikka08898.smileysmp;

import org.bukkit.plugin.java.JavaPlugin;
import zxikka08898.smileysmp.commands.DeathMaceCommand;
import zxikka08898.smileysmp.commands.ItemNameCommand;
import zxikka08898.smileysmp.commands.SMPCommand;
import zxikka08898.smileysmp.commands.SmileyCommand;
import zxikka08898.smileysmp.listeners.DeathMaceListener;

public final class SmileySMP extends JavaPlugin {

    @Override
    public void onEnable() {
        // Register commands
        getCommand("itemname").setExecutor(new ItemNameCommand());
        getCommand("smp").setExecutor(new SMPCommand(this));
        getCommand("deathmace").setExecutor(new DeathMaceCommand());
        getCommand("smiley").setExecutor(new SmileyCommand());
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new DeathMaceListener(this), this);
        
        getLogger().info("SmileySMP has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("SmileySMP has been disabled!");
    }
}

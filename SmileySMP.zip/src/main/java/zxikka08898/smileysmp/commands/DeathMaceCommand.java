package zxikka08898.smileysmp.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

public class DeathMaceCommand implements CommandExecutor {

    public static final String DEATH_MACE_NAME = "&4&lDeath Mace";

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        if (!player.hasPermission("smileysmp.deathmace")) {
            player.sendMessage("§cYou don't have permission to use this command!");
            return true;
        }

        // Create Death Mace
        ItemStack deathMace = new ItemStack(Material.MACE);
        ItemMeta meta = deathMace.getItemMeta();
        
        Component name = LegacyComponentSerializer.legacyAmpersand().deserialize(DEATH_MACE_NAME);
        meta.displayName(name);
        
        deathMace.setItemMeta(meta);

        // Give to player
        player.getInventory().addItem(deathMace);
        player.sendMessage("§aYou have received the §4§lDeath Mace§a!");

        return true;
    }
}

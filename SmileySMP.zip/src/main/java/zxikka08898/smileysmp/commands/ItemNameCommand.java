package zxikka08898.smileysmp.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

public class ItemNameCommand implements CommandExecutor {

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return true;
        }

        if (!player.hasPermission("smileysmp.itemname")) {
            player.sendMessage("§cYou don't have permission to use this command!");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage("§cUsage: /itemname <new name...>");
            return true;
        }

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType().isAir()) {
            player.sendMessage("§cYou must be holding an item!");
            return true;
        }

        // Join all arguments to create the new name
        String newName = String.join(" ", args);
        
        // Convert legacy color codes to Adventure Component
        Component nameComponent = LegacyComponentSerializer.legacyAmpersand().deserialize(newName);
        
        ItemMeta meta = item.getItemMeta();
        meta.displayName(nameComponent);
        item.setItemMeta(meta);

        player.sendMessage("§aItem renamed to: " + newName);
        return true;
    }
}

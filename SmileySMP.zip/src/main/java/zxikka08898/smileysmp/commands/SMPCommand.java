package zxikka08898.smileysmp.commands;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

import java.time.Duration;

public class SMPCommand implements CommandExecutor {

    private final JavaPlugin plugin;

    public SMPCommand(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("smileysmp.smp")) {
            sender.sendMessage("§cYou don't have permission to use this command!");
            return true;
        }

        if (args.length < 2 || !args[0].equalsIgnoreCase("announce")) {
            sender.sendMessage("§cUsage: /smp announce <title> | <subtitle>");
            return true;
        }

        // Join all arguments except "announce" and split by |
        String fullMessage = String.join(" ", args).substring(9).trim(); // Remove "announce "
        String[] parts = fullMessage.split("\\|", 2);

        if (parts.length < 2) {
            sender.sendMessage("§cUsage: /smp announce <title> | <subtitle>");
            return true;
        }

        String titleText = parts[0].trim();
        String subtitleText = parts[1].trim();

        // Convert legacy color codes
        Component title = LegacyComponentSerializer.legacyAmpersand().deserialize(titleText);
        Component subtitle = LegacyComponentSerializer.legacyAmpersand().deserialize(subtitleText);

        // Show title to all players
        Title displayTitle = Title.title(
                title,
                subtitle,
                Title.Times.times(
                        Duration.ofMillis(500),
                        Duration.ofSeconds(5),
                        Duration.ofSeconds(1)
                )
        );

        for (Player player : Bukkit.getOnlinePlayers()) {
            player.showTitle(displayTitle);
        }

        // Create animated boss bar
        createAnimatedBossBar(title);

        sender.sendMessage("§aAnnouncement sent!");
        return true;
    }

    private void createAnimatedBossBar(Component title) {
        BossBar bossBar = BossBar.bossBar(
                title,
                1.0f,
                BossBar.Color.RED,
                BossBar.Overlay.PROGRESS
        );

        // Show to all players
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.showBossBar(bossBar);
        }

        // Animate the boss bar
        new BukkitRunnable() {
            int ticks = 0;
            final int totalTicks = 200; // 10 seconds = 200 ticks
            final BossBar.Color[] colors = {BossBar.Color.RED, BossBar.Color.YELLOW, BossBar.Color.PURPLE};
            int colorIndex = 0;

            @Override
            public void run() {
                ticks++;

                // Update progress (drain from 1.0 to 0.0)
                float progress = 1.0f - ((float) ticks / totalTicks);
                bossBar.progress(Math.max(0.0f, progress));

                // Cycle colors every ~3.33 seconds (67 ticks)
                if (ticks % 67 == 0) {
                    colorIndex = (colorIndex + 1) % colors.length;
                    bossBar.color(colors[colorIndex]);
                }

                // Stop after 10 seconds
                if (ticks >= totalTicks) {
                    for (Player player : Bukkit.getOnlinePlayers()) {
                        player.hideBossBar(bossBar);
                    }
                    this.cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}

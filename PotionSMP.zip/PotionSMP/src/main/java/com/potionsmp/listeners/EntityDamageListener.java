package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.util.Vector;

public class EntityDamageListener implements Listener {

    private final PotionSMP plugin;

    public EntityDamageListener(PotionSMP plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent e) {
        // ── Aqua: attacker hits someone ──
        if (e.getDamager() instanceof Player attacker && e.getEntity() instanceof LivingEntity victim) {
            if (plugin.getPotionManager().getAqua().isActive(attacker.getUniqueId())) {
                plugin.getPotionManager().getAqua().onAttackerHit(attacker, victim);
            }
        }

        // ── Shield: defender is hit ──
        if (e.getEntity() instanceof Player defender) {
            var shield = plugin.getPotionManager().getShield();

            if (shield.isActive(defender.getUniqueId())) {
                // Reduce damage
                double reduced = shield.reduceDamage(defender, e.getDamage());
                e.setDamage(reduced);

                // Reduce knockback by scheduling a velocity correction
                double kbMult = shield.knockbackMultiplier(defender.getUniqueId());
                if (kbMult < 1.0) {
                    final double mult = kbMult;
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                        Vector v = defender.getVelocity();
                        defender.setVelocity(new Vector(v.getX() * mult, v.getY(), v.getZ() * mult));
                    }, 1L);
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent e) {
        // Regen: prevent fall damage during dive launch
        if (e.getEntity() instanceof Player player) {
            if (e.getCause() == EntityDamageEvent.DamageCause.FALL &&
                    plugin.getPotionManager().getRegen().isDiving(player.getUniqueId())) {
                e.setCancelled(true);
            }
        }
    }
}

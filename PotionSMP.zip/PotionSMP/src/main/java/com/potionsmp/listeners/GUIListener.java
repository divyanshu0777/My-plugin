package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.entity.Player;

public class GUIListener implements Listener {

    private final PotionSMP plugin;

    public GUIListener(PotionSMP plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        // Check title matches our GUI
        String title = e.getView().getTitle();
        if (!title.equals("§bPotion SMP")) return;

        e.setCancelled(true);
        if (e.getCurrentItem() == null) return;

        plugin.getPotionManager().handleGUIClick(player, e.getCurrentItem());
    }
}

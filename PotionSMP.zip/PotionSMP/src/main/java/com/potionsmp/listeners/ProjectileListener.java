package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;

public class ProjectileListener implements Listener {

    private final PotionSMP plugin;

    public ProjectileListener(PotionSMP plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onProjectileHit(ProjectileHitEvent e) {
        // If a projectile hits a Shield player, cancel impact damage
        if (!(e.getHitEntity() instanceof Player defender)) return;
        if (plugin.getPotionManager().getShield().isActive(defender.getUniqueId())) {
            // Projectile is already being deflected by the aura task; cancel hit
            Projectile proj = e.getEntity();
            proj.remove();
            e.setCancelled(true);
        }
    }
}

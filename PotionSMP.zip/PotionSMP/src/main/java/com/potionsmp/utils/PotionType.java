package com.potionsmp.utils;

public enum PotionType {
    AQUA("§b§lAqua Potion"),
    SHIELD("§f§lShield Potion"),
    REGEN("§e§lRegen Potion");

    private final String displayName;

    PotionType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}

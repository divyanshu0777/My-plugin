package com.potionsmp;

import com.potionsmp.listeners.*;
import com.potionsmp.managers.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class PotionSMP extends JavaPlugin {

    private static PotionSMP instance;

    private CooldownManager cooldownManager;
    private TaskManager     taskManager;
    private AuraManager     auraManager;
    private BossBarManager  bossBarManager;
    private PotionManager   potionManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        cooldownManager = new CooldownManager();
        taskManager     = new TaskManager(this);
        auraManager     = new AuraManager(this);
        bossBarManager  = new BossBarManager(this);
        potionManager   = new PotionManager(this);

        // Listeners
        var pm = getServer().getPluginManager();
        pm.registerEvents(new GUIListener(this),            this);
        pm.registerEvents(new PlayerInteractListener(this), this);
        pm.registerEvents(new EntityDamageListener(this),   this);
        pm.registerEvents(new PlayerMoveListener(this),     this);
        pm.registerEvents(new ProjectileListener(this),     this);
        pm.registerEvents(new PlayerQuitListener(this),     this);

        // /potionsmp command
        getCommand("potionsmp").setExecutor((CommandSender sender, Command cmd, String label, String[] args) -> {
            if (!(sender instanceof Player player)) { sender.sendMessage("§cPlayers only!"); return true; }
            potionManager.openGUI(player);
            return true;
        });

        getLogger().info("PotionSMP v" + getDescription().getVersion() + " enabled!");
    }

    @Override
    public void onDisable() {
        taskManager.cancelAll();
        bossBarManager.removeAll();
        auraManager.stopAll();
        getLogger().info("PotionSMP disabled.");
    }

    public static PotionSMP getInstance() { return instance; }

    public CooldownManager getCooldownManager() { return cooldownManager; }
    public TaskManager     getTaskManager()     { return taskManager; }
    public AuraManager     getAuraManager()     { return auraManager; }
    public BossBarManager  getBossBarManager()  { return bossBarManager; }
    public PotionManager   getPotionManager()   { return potionManager; }
}

package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.potions.AquaPotion;
import com.potionsmp.potions.RegenPotion;
import com.potionsmp.potions.ShieldPotion;
import com.potionsmp.utils.AbilityState;
import com.potionsmp.utils.PotionType;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public class PotionManager {

    public static final NamespacedKey POTION_KEY = new NamespacedKey(PotionSMP.getInstance(), "potionsmp_type");

    private final PotionSMP plugin;
    private final Map<UUID, AbilityState> states = new HashMap<>();

    private final AquaPotion   aqua;
    private final ShieldPotion shield;
    private final RegenPotion  regen;

    public PotionManager(PotionSMP plugin) {
        this.plugin = plugin;
        this.aqua   = new AquaPotion(plugin);
        this.shield = new ShieldPotion(plugin);
        this.regen  = new RegenPotion(plugin);
    }

    // ── GUI ──────────────────────────────────────────────────────────────────

    public void openGUI(Player player) {
        Inventory inv = plugin.getServer().createInventory(null, 9, "§bPotion SMP");

        inv.setItem(0, makeItem(Material.BLUE_DYE, "§b§lAqua Potion",
                List.of("§7Shift + Right Click to activate",
                        "§7■ Poseidon's Wrath",
                        "§7■ Ocean Domain  §eDuration: §f15s  §eCooldown: §f240s"),
                PotionType.AQUA));

        inv.setItem(1, makeItem(Material.SHIELD, "§f§lShield Potion",
                List.of("§7Shift + Left Click to activate",
                        "§7■ Divine Barrier",
                        "§7■ 60% KB Reduction  §eDuration: §f10s  §eCooldown: §f45s"),
                PotionType.SHIELD));

        inv.setItem(2, makeItem(Material.GOLDEN_APPLE, "§e§lRegen Potion",
                List.of("§7Right Click to activate",
                        "§7■ Vitality Surge",
                        "§7■ Aerial Mace Dive  §eDuration: §f20s  §eCooldown: §f45s"),
                PotionType.REGEN));

        // Slots 3-8: decorative glass panes
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta();
        fm.setDisplayName("§8Coming soon...");
        filler.setItemMeta(fm);
        for (int i = 3; i < 9; i++) inv.setItem(i, filler);

        player.openInventory(inv);
    }

    private ItemStack makeItem(Material mat, String name, List<String> lore, PotionType type) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(POTION_KEY, PersistentDataType.STRING, type.name());
        item.setItemMeta(meta);
        return item;
    }

    // ── GUI Click Handler ─────────────────────────────────────────────────────

    public void handleGUIClick(Player player, ItemStack clicked) {
        if (clicked == null || !clicked.hasItemMeta()) return;
        var pdc = clicked.getItemMeta().getPersistentDataContainer();
        if (!pdc.has(POTION_KEY, PersistentDataType.STRING)) return;

        PotionType type;
        try { type = PotionType.valueOf(pdc.get(POTION_KEY, PersistentDataType.STRING)); }
        catch (Exception e) { return; }

        UUID uuid = player.getUniqueId();
        AbilityState state = states.computeIfAbsent(uuid, u -> new AbilityState());

        if (type == state.getEquippedPotion()) {
            unequip(player);
        } else {
            equip(player, type);
        }
        player.closeInventory();
    }

    // ── Equip/Unequip ─────────────────────────────────────────────────────────

    public void equip(Player player, PotionType type) {
        UUID uuid = player.getUniqueId();
        // Cancel old ability if running
        endAll(player);
        AbilityState state = states.computeIfAbsent(uuid, u -> new AbilityState());
        state.setEquippedPotion(type);

        String msg = plugin.getConfig().getString("messages.equipped", "§aEquipped: §b{potion}")
                .replace("{potion}", type.getDisplayName());
        player.sendMessage(cfg("messages.prefix") + msg);
        actionBar(player, "§b✦ " + type.getDisplayName() + " §7equipped.");
    }

    public void unequip(Player player) {
        endAll(player);
        states.remove(player.getUniqueId());
        player.sendMessage(cfg("messages.prefix") + cfg("messages.unequipped"));
    }

    // ── Ability Triggers ──────────────────────────────────────────────────────

    /** Shift + Right Click */
    public void triggerShiftRight(Player player) {
        AbilityState state = states.get(player.getUniqueId());
        if (state == null || !state.hasPotion()) { sendNoPotion(player); return; }
        if (state.getEquippedPotion() == PotionType.AQUA) aqua.activate(player);
        else actionBar(player, "§cShift + Right Click is only for Aqua Potion.");
    }

    /** Shift + Left Click */
    public void triggerShiftLeft(Player player) {
        AbilityState state = states.get(player.getUniqueId());
        if (state == null || !state.hasPotion()) { sendNoPotion(player); return; }
        if (state.getEquippedPotion() == PotionType.SHIELD) shield.activate(player);
        else actionBar(player, "§cShift + Left Click is only for Shield Potion.");
    }

    /** Right Click */
    public void triggerRight(Player player) {
        AbilityState state = states.get(player.getUniqueId());
        if (state == null || !state.hasPotion()) { sendNoPotion(player); return; }
        if (state.getEquippedPotion() == PotionType.REGEN) regen.activate(player);
        else actionBar(player, "§cRight Click ability is only for Regen Potion.");
    }

    // ── Cleanup ───────────────────────────────────────────────────────────────

    public void endAll(Player player) {
        plugin.getTaskManager().cancelPlayer(player.getUniqueId());
        plugin.getAuraManager().stop(player.getUniqueId());
        plugin.getBossBarManager().remove(player.getUniqueId());
        aqua.cleanup(player);
        shield.cleanup(player);
        regen.cleanup(player);
        AbilityState state = states.get(player.getUniqueId());
        if (state != null) state.setAbilityActive(false);
    }

    public void removePlayer(UUID uuid) {
        Player p = plugin.getServer().getPlayer(uuid);
        if (p != null) endAll(p);
        states.remove(uuid);
        plugin.getCooldownManager().clear(uuid);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void sendNoPotion(Player player) {
        player.sendMessage(cfg("messages.prefix") + cfg("messages.no-potion"));
    }

    public static void actionBar(Player player, String msg) {
        player.sendActionBar(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacySection().deserialize(msg));
    }

    public void sendCooldown(Player player, PotionType type) {
        long sec = plugin.getCooldownManager().remainingSeconds(player.getUniqueId(), type);
        String msg = cfg("messages.on-cooldown")
                .replace("{ability}", type.getDisplayName())
                .replace("{time}", String.valueOf(sec));
        player.sendMessage(cfg("messages.prefix") + msg);
        actionBar(player, msg);
    }

    private String cfg(String path) {
        return plugin.getConfig().getString(path, "");
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public AbilityState getState(UUID uuid) { return states.get(uuid); }
    public AquaPotion   getAqua()   { return aqua; }
    public ShieldPotion getShield() { return shield; }
    public RegenPotion  getRegen()  { return regen; }
}

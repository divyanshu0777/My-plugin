package com.potionsmp.potions;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.PotionManager;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.boss.BarColor;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

public class AquaPotion {

    private final PotionSMP plugin;
    private final Set<UUID> active = new HashSet<>();
    private final Map<UUID, ArmorStand> tridents = new HashMap<>();

    public AquaPotion(PotionSMP plugin) { this.plugin = plugin; }

    // ── Activate ─────────────────────────────────────────────────────────────

    public void activate(Player player) {
        UUID uuid = player.getUniqueId();
        var cdm = plugin.getCooldownManager();

        if (cdm.isOnCooldown(uuid, PotionType.AQUA)) {
            plugin.getPotionManager().sendCooldown(player, PotionType.AQUA);
            return;
        }

        active.add(uuid);
        int dur  = plugin.getConfig().getInt("aqua.duration", 15);
        int ticks = dur * 20;

        // ── Notify ──
        player.sendTitle("§b§l⚡ POSEIDON'S WRATH", "§7The ocean bows to you.", 5, 40, 10);
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_CONDUIT_ACTIVATE, 1f, 0.8f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 0.5f);

        // ── Buffs ──
        applyBuffs(player, ticks);

        // ── Boss bar ──
        plugin.getBossBarManager().show(player, "§b⚡ Poseidon's Wrath", BarColor.BLUE, dur);

        // ── Summon trident stand ──
        summonTrident(player);

        // ── Aura (every 2 ticks) ──
        startAura(player);

        // ── Domain task (every vortex-interval ticks) ──
        startDomain(player);

        // ── End ──
        plugin.getTaskManager().later(uuid, () -> end(player), ticks);
        cdm.setCooldown(uuid, PotionType.AQUA, plugin.getConfig().getLong("aqua.cooldown", 240));
    }

    // ── Buffs ─────────────────────────────────────────────────────────────────

    private void applyBuffs(Player player, int ticks) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING,  ticks, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE,   ticks, 0, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE,            ticks, 1, true, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,     ticks + 60, 0, true, false));
    }

    // ── Trident ───────────────────────────────────────────────────────────────

    private void summonTrident(Player player) {
        UUID uuid = player.getUniqueId();
        Location loc = player.getLocation().add(0, 2.2, 0);

        ArmorStand stand = (ArmorStand) player.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
        stand.setVisible(false);
        stand.setGravity(false);
        stand.setCollidable(false);
        stand.setGlowing(true);
        stand.setSmall(true);
        stand.setCustomNameVisible(true);
        stand.customName(net.kyori.adventure.text.Component.text("§b⚡ Poseidon's Trident"));

        ItemStack trident = new ItemStack(Material.TRIDENT);
        ItemMeta meta = trident.getItemMeta();
        meta.setDisplayName("§b⚡ Poseidon's Trident");
        meta.setUnbreakable(true);
        meta.addEnchant(Enchantment.LOYALTY, 3, true);
        meta.addEnchant(Enchantment.SHARPNESS, 10, true);
        trident.setItemMeta(meta);
        stand.getEquipment().setItemInMainHand(trident);

        tridents.put(uuid, stand);

        // Orbit animation
        double[] angle = {0.0};
        plugin.getTaskManager().repeat(uuid, () -> {
            if (!player.isOnline() || stand.isDead()) return;
            angle[0] += 0.12;
            double r = 1.6;
            Location orbit = player.getLocation().clone().add(
                    Math.cos(angle[0]) * r, 2.3, Math.sin(angle[0]) * r);
            stand.teleport(orbit);
            player.getWorld().spawnParticle(Particle.BUBBLE_COLUMN_UP, stand.getLocation(), 2, 0.1, 0.1, 0.1, 0.02);
            player.getWorld().spawnParticle(Particle.DRIP_WATER, stand.getLocation(), 1, 0, 0, 0, 0);
        }, 0L, 1L);
    }

    // ── Aura ──────────────────────────────────────────────────────────────────

    private void startAura(Player player) {
        UUID uuid = player.getUniqueId();
        World world = player.getWorld();
        double[] ring = {0.0};

        plugin.getAuraManager().start(uuid, () -> {
            if (!player.isOnline()) return;
            Location loc = player.getLocation().add(0, 1, 0);
            ring[0] += 0.25;

            // Blue dust rings
            for (int i = 0; i < 2; i++) {
                double r = 0.8 + i * 0.6;
                double angle = ring[0] + Math.PI * i;
                for (int j = 0; j < 8; j++) {
                    double a = angle + (2 * Math.PI / 8) * j;
                    Location p = loc.clone().add(Math.cos(a) * r, i * 0.4 - 0.4, Math.sin(a) * r);
                    world.spawnParticle(Particle.DUST, p, 1,
                            new Particle.DustOptions(Color.fromRGB(0, 150, 255), 1.0f));
                }
            }

            // Bubble pops + drips
            world.spawnParticle(Particle.BUBBLE_POP,    loc, 3, 0.4, 0.6, 0.4, 0.02);
            world.spawnParticle(Particle.DRIP_WATER,    loc, 3, 0.5, 1.0, 0.5, 0);
            world.spawnParticle(Particle.SPLASH,        loc, 4, 0.5, 0.3, 0.5, 0.1);

            // Dragon breath / conduit sparkle
            if (Math.random() < 0.3)
                world.spawnParticle(Particle.DRAGON_BREATH, loc, 2, 0.5, 0.5, 0.5, 0.01);
            if (Math.random() < 0.2)
                world.spawnParticle(Particle.BUBBLE_COLUMN_UP, loc, 3, 0.3, 0.3, 0.3, 0.01);

            // Ambient sound
            if (Math.random() < 0.07)
                world.playSound(loc, Sound.BLOCK_CONDUIT_AMBIENT, 0.3f, 1.0f);

        }, 2L);
    }

    // ── Ocean Domain ──────────────────────────────────────────────────────────

    private void startDomain(Player player) {
        UUID uuid = player.getUniqueId();
        World world = player.getWorld();
        double radius   = plugin.getConfig().getDouble("aqua.domain-radius", 15.0);
        long   interval = plugin.getConfig().getLong("aqua.vortex-interval", 30);
        double pullStr  = plugin.getConfig().getDouble("aqua.pull-strength", 0.45);
        double dmg      = plugin.getConfig().getDouble("aqua.vortex-damage", 6.0);

        plugin.getTaskManager().repeat(uuid, () -> {
            if (!player.isOnline()) return;
            Location center = player.getLocation();

            // Storm atmosphere
            for (int i = 0; i < 12; i++) {
                double rx = (Math.random() - 0.5) * radius * 2;
                double rz = (Math.random() - 0.5) * radius * 2;
                Location rain = center.clone().add(rx, 4 + Math.random() * 3, rz);
                world.spawnParticle(Particle.FALLING_WATER, rain, 1, 0, 0, 0, 0);
                world.spawnParticle(Particle.SPLASH, rain, 2, 0.2, 0.2, 0.2, 0.05);
            }

            // Vortex ring
            spawnVortexRing(world, center, radius * 0.55, 24);

            world.playSound(center, Sound.BLOCK_CONDUIT_AMBIENT, 0.35f, 0.9f);

            // Affect enemies
            for (Entity e : world.getNearbyEntities(center, radius, radius, radius)) {
                if (!(e instanceof LivingEntity living) || e instanceof ArmorStand) continue;
                if (e instanceof Player p && p.getUniqueId().equals(uuid)) continue;

                // Pull
                Vector pull = center.toVector().subtract(living.getLocation().toVector()).normalize().multiply(pullStr);
                pull.setY(Math.max(0, pull.getY()));
                living.setVelocity(living.getVelocity().add(pull));

                // Slowness III
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int)interval + 10, 2, true, false));

                // Vortex strike – true damage
                living.damage(dmg, player);
                living.setNoDamageTicks(0);

                // Stun via slowness V briefly
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 15, 4, true, false));

                // Water explosion on hit
                spawnWaterExplosion(world, living.getLocation());
            }

            // Thunder crack
            world.playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.25f, 0.6f);

        }, 0L, interval);
    }

    private void spawnVortexRing(World world, Location center, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double a = (2 * Math.PI / points) * i;
            Location p = center.clone().add(Math.cos(a) * radius, 0.5, Math.sin(a) * radius);
            world.spawnParticle(Particle.BUBBLE_COLUMN_UP, p, 2, 0.1, 0.3, 0.1, 0.05);
            world.spawnParticle(Particle.DUST, p, 1,
                    new Particle.DustOptions(Color.fromRGB(0, 100, 220), 1.3f));
        }
    }

    private void spawnWaterExplosion(World world, Location loc) {
        world.spawnParticle(Particle.SPLASH,            loc, 25, 0.6, 0.6, 0.6, 0.3);
        world.spawnParticle(Particle.BUBBLE_COLUMN_UP,  loc, 15, 0.4, 0.4, 0.4, 0.15);
        world.spawnParticle(Particle.DRIP_WATER,        loc, 10, 0.5, 0.5, 0.5, 0);
        world.playSound(loc, Sound.ENTITY_GENERIC_SPLASH, 0.7f, 0.8f);
    }

    // ── Hit callback (from EntityDamageListener) ──────────────────────────────

    public void onAttackerHit(Player attacker, LivingEntity victim) {
        if (!active.contains(attacker.getUniqueId())) return;
        Location loc = victim.getLocation();

        // True damage (bypass armour)
        victim.damage(plugin.getConfig().getDouble("aqua.lightning-damage", 8.0), attacker);
        victim.setNoDamageTicks(0);

        // Lightning visual
        attacker.getWorld().strikeLightningEffect(loc);

        // Water explosion + pull
        spawnWaterExplosion(attacker.getWorld(), loc);
        double pull = plugin.getConfig().getDouble("aqua.pull-strength", 0.45) * 2.5;
        Vector v = attacker.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(pull);
        v.setY(0.2);
        victim.setVelocity(v);

        attacker.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.0f);
    }

    // ── End / Cleanup ─────────────────────────────────────────────────────────

    public void end(Player player) {
        cleanup(player);
        plugin.getAuraManager().stop(player.getUniqueId());
        plugin.getBossBarManager().remove(player.getUniqueId());
        PotionManager.actionBar(player, "§7Poseidon's Wrath has ended.");
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_CONDUIT_DEACTIVATE, 1f, 1f);
    }

    public void cleanup(Player player) {
        UUID uuid = player.getUniqueId();
        active.remove(uuid);

        ArmorStand stand = tridents.remove(uuid);
        if (stand != null && !stand.isDead()) stand.remove();

        player.removePotionEffect(PotionEffectType.WATER_BREATHING);
        player.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
        player.removePotionEffect(PotionEffectType.HASTE);
        player.removePotionEffect(PotionEffectType.NIGHT_VISION);
    }

    public boolean isActive(UUID uuid) { return active.contains(uuid); }
}

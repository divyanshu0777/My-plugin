package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * §e Speed Potion – Lightning Fast Warrior
 *
 * SINGLE SOURCE OF TRUTH: every change to this potion's Minecraft "SPEED"
 * PotionEffect goes through {@link #updateSpeedEffect(PotionSMP, Player, int, int)}.
 * No other method in this class ever calls player.addPotionEffect(SPEED, ...)
 * directly, so exactly one Speed effect can ever exist for this potion at a
 * time — it is never possible for Speed I and Speed IV (or any two levels)
 * to coexist.
 *
 * PASSIVE:
 * - Base Speed I always active while equipped
 * - Every hit → +1 on the "×⚡" hit counter (HUD, via HitCounterManager)
 * - 5×⚡ → the SAME Speed effect is replaced in place with Speed IV
 *   (never Dash, never the old Max Speed system)
 * - Continuing to land hits while in Speed IV mode refreshes that same
 *   Speed IV effect's duration instead of stacking a new one
 * - When hits stop and the Speed IV window naturally expires, the
 *   controller reverts the same effect back down to Speed I
 * - 25% reduced iframes on hit targets
 *
 * ACTIVE – Lightning Dash (manual /slot1 or /slot2 ONLY — never auto-triggered
 * by the ×⚡ counter):
 * - Dash in look direction
 * - Speed IV during dash (also goes through updateSpeedEffect)
 * - 20% damage reduction
 * - Shockwave at end (4-5 block radius)
 * - Duration: 1.8s | Cooldown: 28s
 */
public class SpeedAbility implements Ability, Listener {

    private static final int SPEED_I_AMPLIFIER  = 0;
    private static final int SPEED_IV_AMPLIFIER = 3;

    // Sentinel duration meaning "permanent" (applied as Integer.MAX_VALUE).
    private static final int PERMANENT = -1;

    // Number of hits needed to fill the "×⚡" counter and enter Speed IV mode.
    private static final int HIT_THRESHOLD = 5;
    // How long each Speed IV application/refresh lasts before auto-reverting
    // to Speed I if no further valid hit lands in that window.
    private static final int MAX_SPEED_DURATION_TICKS = 60; // 3s

    // Players currently equipped with Speed — guards onEquip()/onUnequip()
    // against being invoked twice for the same player (e.g. re-drinking
    // Speed while already equipped), which would otherwise double up the
    // passive effect application.
    private final Set<UUID> equipped = new HashSet<>();
    // Players currently dashing
    private final Set<UUID> dashing  = new HashSet<>();
    // Players currently in continuous-hit Speed IV mode (as opposed to
    // Dash's own, separate, temporary Speed IV). Only used to decide
    // whether a new hit should "refresh" vs "trigger" — the actual Speed
    // effect itself is always managed solely by updateSpeedEffect().
    private final Set<UUID> comboSpeedActive = new HashSet<>();
    // The single pending "revert to Speed I" task per player, if any.
    // updateSpeedEffect() always cancels this before doing anything else,
    // so a stale/older timer can never fire after a newer Speed state has
    // been set, and never overwrite it later.
    private final Map<UUID, BukkitTask> pendingRevert = new HashMap<>();

    public void register(PotionSMP plugin) {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public PotionType type() { return PotionType.SPEED; }

    // ── Equip / Unequip ───────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        // Ownership guard — DrinkListener calls onEquip() unconditionally
        // whenever this potion is (re)assigned to a slot, including the
        // case where SPEED is drunk again while already equipped (it just
        // lands in the other empty slot). If already equipped, this is a
        // no-op so we never redundantly reset an in-progress Speed IV combo.
        if (!equipped.add(uid)) {
            return;
        }

        plugin.getHitCounterManager().reset(uid, type());
        comboSpeedActive.remove(uid);
        updateSpeedEffect(plugin, player, SPEED_I_AMPLIFIER, PERMANENT);
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        equipped.remove(uid);
        dashing.remove(uid);
        comboSpeedActive.remove(uid);
        plugin.getHitCounterManager().reset(uid, type());

        // Cancel any in-flight timer BEFORE removing the effect, so it can
        // never fire afterward and silently reapply Speed I/IV once this
        // potion is no longer equipped.
        BukkitTask pending = pendingRevert.remove(uid);
        if (pending != null) pending.cancel();

        player.removePotionEffect(PotionEffectType.SPEED);
    }

    // ── Cleanup on quit / death — Multiple Dash Fix ────────────────────────
    // Ensures "dashing" (and related temp-boost state) can never get stuck
    // if the player disconnects or dies mid-dash.

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uid = event.getPlayer().getUniqueId();
        dashing.remove(uid);
        equipped.remove(uid);
        comboSpeedActive.remove(uid);
        BukkitTask pending = pendingRevert.remove(uid);
        if (pending != null) pending.cancel();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        // Only clear the in-progress dash flag — hit-combo/passive state
        // is left alone here since respawn/equip handling already governs
        // that elsewhere, and touching it would be a gameplay change.
        dashing.remove(event.getEntity().getUniqueId());
    }

    // ── Passive hit: ×⚡ counter → single-effect Speed IV mode ─────────────

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        UUID uid = player.getUniqueId();

        int newCount = plugin.getHitCounterManager().registerHit(
            uid, type(), target.getUniqueId(), player.getWorld().getFullTime());
        if (newCount == -1) return; // debounced duplicate event for the same swing

        // Reduce iframes by 25% (set to 75% of default 20)
        target.setNoDamageTicks(Math.max(0, (int)(target.getNoDamageTicks() * 0.75)));

        // Spark on hit
        target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,
            target.getLocation().add(0,1,0), 4, 0.2,0.2,0.2, 0.05);

        if (comboSpeedActive.contains(uid)) {
            // Already in Speed IV mode from a previous 5×⚡ — a continued
            // hit REFRESHES the same effect's duration. This still goes
            // through updateSpeedEffect(), which overwrites the existing
            // Speed IV in place rather than adding a second one.
            updateSpeedEffect(plugin, player, SPEED_IV_AMPLIFIER, MAX_SPEED_DURATION_TICKS);
        } else if (newCount >= HIT_THRESHOLD) {
            // 5×⚡ reached — replace Speed I with Speed IV (never Dash, never
            // the old Max Speed system).
            plugin.getHitCounterManager().reset(uid, type());
            comboSpeedActive.add(uid);
            updateSpeedEffect(plugin, player, SPEED_IV_AMPLIFIER, MAX_SPEED_DURATION_TICKS);
        }
    }

    /**
     * SINGLE CONTROLLER for this potion's Minecraft "SPEED" PotionEffect.
     * Every Speed-effect change (passive Speed I, combo Speed IV, Dash's
     * Speed IV) must go through here — nowhere else in this class calls
     * player.addPotionEffect(SPEED, ...) directly.
     *
     * Bukkit only ever tracks one PotionEffect per type on a player, so
     * addPotionEffect() below always replaces whatever Speed effect (if
     * any) is currently active — Speed I and Speed IV can never coexist.
     *
     * @param amplifier    0 = Speed I, 3 = Speed IV, etc.
     * @param durationTicks PERMANENT for the passive level, or a finite
     *                      tick count for a temporary boost that will
     *                      auto-revert to Speed I when it expires.
     */
    private void updateSpeedEffect(PotionSMP plugin, Player player, int amplifier, int durationTicks) {
        UUID uid = player.getUniqueId();

        // Always cancel any existing revert timer FIRST. This guarantees a
        // previous (older) timer can never fire later and overwrite the
        // Speed state we are about to set here.
        BukkitTask pending = pendingRevert.remove(uid);
        if (pending != null) pending.cancel();

        if (durationTicks == PERMANENT) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,
                Integer.MAX_VALUE, amplifier, false, false));
            return;
        }

        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,
            durationTicks, amplifier, false, false));

        BukkitTask revert = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            pendingRevert.remove(uid);
            comboSpeedActive.remove(uid);
            if (!player.isOnline()) return;
            if (!plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) return;

            // Natural expiry with no further hits/dash — revert to Speed I.
            updateSpeedEffect(plugin, player, SPEED_I_AMPLIFIER, PERMANENT);
        }, durationTicks);

        pendingRevert.put(uid, revert);
    }

    // ── Active: Lightning Dash ────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        // Hard guard: never allow a second dash while one is already
        // active — checked independently of cooldown timing/config so it
        // can't be bypassed even with a custom short cooldown value.
        if (dashing.contains(uid)) return ActivationResult.ON_COOLDOWN;

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        int cooldown = plugin.getConfig().getInt("potions.speed.active-cooldown", 28);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

        executeDash(plugin, player);
        return ActivationResult.SUCCESS;
    }

    private void executeDash(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        dashing.add(uid);

        // Dash's Speed IV supersedes any combo Speed IV that may be active —
        // it goes through the same single controller, so there is still
        // only ever one Speed effect on the player.
        comboSpeedActive.remove(uid);
        updateSpeedEffect(plugin, player, SPEED_IV_AMPLIFIER, 40);
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE,  40, 0, false, false));

        // Launch in look direction
        Vector dir = player.getLocation().getDirection().normalize().multiply(1.4);
        dir.setY(Math.max(dir.getY(), 0.1));
        player.setVelocity(dir);

        player.sendTitle("", "§e⚡ Lightning Dash!", 2, 15, 5);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.8f);

        // Dash trail
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= 36 || !player.isOnline() || player.isDead() || !dashing.contains(uid)) { // 1.8s
                    if (player.isOnline() && !player.isDead()) {
                        triggerShockwave(plugin, player);
                        player.removePotionEffect(PotionEffectType.RESISTANCE);
                    }
                    dashing.remove(uid);
                    cancel(); return;
                }
                Location loc = player.getLocation();
                loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 5, 0.2,0.2,0.2, 0.05);
                loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK,   loc, 2, 0.3,0.1,0.3, 0);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void triggerShockwave(PotionSMP plugin, Player player) {
        Location loc = player.getLocation();
        World world  = loc.getWorld();
        double radius = plugin.getConfig().getDouble("potions.speed.shockwave-radius", 4.5);
        double dmg    = plugin.getConfig().getDouble("potions.speed.shockwave-damage", 5.0);

        // Ring particles
        for (int i = 0; i < 36; i++) {
            double angle = Math.toRadians(i * 10);
            Location p = loc.clone().add(Math.cos(angle)*radius, 0.1, Math.sin(angle)*radius);
            world.spawnParticle(Particle.ELECTRIC_SPARK, p, 2, 0.1,0.1,0.1, 0.05);
            world.spawnParticle(Particle.SWEEP_ATTACK,   p, 1, 0,0,0, 0);
        }

        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.4f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.5f);

        // Damage + knockback nearby
        for (Entity e : world.getNearbyEntities(loc, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(player.getUniqueId())) continue;
            le.damage(dmg, player);
            le.setNoDamageTicks(0);
            Vector kb = le.getLocation().toVector().subtract(loc.toVector()).normalize()
                .multiply(1.5).setY(0.5);
            le.setVelocity(kb);
        }
    }

    // ── Reduce iframes on victim (EntityDamageByEntityEvent) ─────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (!equipped.contains(p.getUniqueId())) return;
        if (e.getEntity() instanceof LivingEntity le) {
            plugin_ref_hack(p).getServer().getScheduler().runTaskLater(
                plugin_ref_hack(p), () -> le.setNoDamageTicks(
                    (int)(le.getNoDamageTicks() * 0.75)), 1L);
        }
    }
    // Small helper to get plugin ref without storing it (pattern: use getInstance)
    private PotionSMP plugin_ref_hack(Player p) { return PotionSMP.getInstance(); }
}

package com.potionsmp.listeners;

import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.Ability;
import com.potionsmp.managers.SlotManager;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import java.util.UUID;

/**
 * Slot assignment logic on drink:
 *  - Slot 1 empty → goes to Slot 1
 *  - Slot 1 filled, Slot 2 empty → goes to Slot 2
 *  - Both filled → Slot 1 is replaced (oldest slot)
 *
 * Vanilla base-effect is stripped 1 tick after drinking (isPotionSmpInfinite()
 * check protects custom permanent passives — applied via Integer.MAX_VALUE,
 * not Bukkit's -1 convention — from being accidentally removed).
 */
public class DrinkListener implements Listener {

    private final PotionSMP plugin;

    public DrinkListener(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent event) {
        PotionType type = PotionUtils.getPotionType(event.getItem());
        if (type == null) return;

        Player player = event.getPlayer();
        SlotManager slots = plugin.getSlotManager();
        UUID uid = player.getUniqueId();

        // Strip vanilla base-effect 1 tick after drinking. ItemBuilder already
        // builds every PotionSMP potion on a neutral WATER base (no vanilla
        // effect is granted by the item itself), so in practice this is a
        // defensive safety net — but it must never delete the PotionSMP
        // passive that onEquip() applies a few lines below this block.
        //
        // Bug fixed here: PotionEffect#isInfinite() only returns true for
        // duration == -1 (PotionEffect.INFINITE_DURATION). Every ability's
        // onEquip() applies its "infinite" passive with Integer.MAX_VALUE,
        // not -1, so the old `!active.isInfinite()` check treated that
        // freshly-applied passive as non-infinite and deleted it one tick
        // after equip (this actually broke FIRE and REGEN, both of which
        // pass through this exact effect type). isPotionSmpInfinite() below
        // now recognizes both conventions as "protected".
        PotionEffectType vanillaEffect = vanillaEffectFor(type);
        if (vanillaEffect != null) {
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) return;
                PotionEffect active = player.getPotionEffect(vanillaEffect);
                if (active != null && !isPotionSmpInfinite(active)) {
                    player.removePotionEffect(vanillaEffect);
                }
            });
        }

        PotionType slot1 = slots.getSlot1(uid);
        PotionType slot2 = slots.getSlot2(uid);

        int targetSlot;
        PotionType displaced;

        if (slot1 == null) {
            // Slot 1 empty → assign to Slot 1
            targetSlot = SlotManager.SLOT_1;
            displaced = null;
            slots.setSlot1(uid, type);

        } else if (slot2 == null) {
            // Slot 1 filled, Slot 2 empty → assign to Slot 2
            targetSlot = SlotManager.SLOT_2;
            displaced = null;
            slots.setSlot2(uid, type);

        } else {
            // Both filled → replace Slot 1 (oldest)
            targetSlot = SlotManager.SLOT_1;
            displaced = slot1;
            slots.setSlot1(uid, type);
        }

        // Unequip displaced potion's passive if replaced
        if (displaced != null && displaced != type) {
            Ability oldAbility = plugin.getAbilityRegistry().get(displaced);
            if (oldAbility != null) oldAbility.onUnequip(plugin, player);
            if (!PotionUtils.isQuiet()) {
                player.sendMessage(PotionUtils.colorize("&7Slot " + targetSlot + " replaced: &f"
                    + displaced.getDisplayName() + " &7removed."));
            }
        }

        // Equip new potion's passive
        Ability newAbility = plugin.getAbilityRegistry().get(type);
        if (newAbility != null) newAbility.onEquip(plugin, player);

        if (!PotionUtils.isQuiet()) {
            player.sendMessage(PotionUtils.colorize("&a✦ " + type.getDisplayName()
                + " &aequipped to &eSlot " + targetSlot + "&a!"));
        }

        // Immediate HUD refresh — don't wait for the periodic 10-tick tick
        plugin.getHudManager().sendOnce(player);
    }

    private PotionEffectType vanillaEffectFor(PotionType type) {
        return switch (type) {
            case FIRE     -> PotionEffectType.FIRE_RESISTANCE;
            case FREEZE   -> PotionEffectType.SLOWNESS;
            case REGEN    -> PotionEffectType.REGENERATION;
            case GLITCH   -> PotionEffectType.MINING_FATIGUE;
            case SHIELD   -> PotionEffectType.SLOWNESS; // Turtle Master gives slowness
            case TELEPORT -> PotionEffectType.INVISIBILITY;
            case SPEED    -> PotionEffectType.SPEED;
            default       -> null;
        };
    }

    /**
     * Treats an effect as "belongs to PotionSMP's own infinite passive, do
     * not touch" if it's infinite by either convention used in this
     * codebase: Bukkit's own -1 (isInfinite()), or the Integer.MAX_VALUE
     * duration every Ability.onEquip() actually uses. A real vanilla potion
     * effect (e.g. a brewed Fire Resistance potion drunk separately) will
     * always have a small, finite duration and is unaffected by this.
     */
    private boolean isPotionSmpInfinite(PotionEffect effect) {
        return effect.isInfinite() || effect.getDuration() > 1_000_000;
    }
}

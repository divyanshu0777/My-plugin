package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Handles freezing entities in place - used both by Freeze's passive
 * (brief 1s "struck"/stun on every 10th hit) and its active Arctic Prison
 * (full 3s area freeze). Locks position every tick and applies heavy
 * Slowness/Mining Fatigue so the entity can't move, attack, mine, or act.
 */
public class FrozenPlayerManager {

    private final PotionSMP plugin;
    private final Map<UUID, Location> frozenEntities = new HashMap<>();
    private final Map<UUID, Integer> frozenTaskIds = new HashMap<>();

    // Whatever infinite PotionSMP passive (if any) occupied SLOWNESS /
    // MINING_FATIGUE / JUMP_BOOST right before we overwrote it with the
    // freeze CC — restored once the freeze ends instead of just being
    // deleted, so freezing a Glitch-potion wearer (infinite Mining
    // Fatigue) or any future infinite passive on these types doesn't
    // permanently erase it.
    private final Map<UUID, PotionEffect[]> preFreezeSnapshot = new HashMap<>();

    private static final Particle.DustOptions FROST_LOCK_CYAN =
            new Particle.DustOptions(Color.fromRGB(185, 241, 255), 0.7f);

    public FrozenPlayerManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void freezeEntity(LivingEntity entity, int durationTicks) {
        UUID uid = entity.getUniqueId();
        Location loc = entity.getLocation().clone();
        frozenEntities.put(uid, loc);

        // Snapshot any infinite passive on these exact types BEFORE the CC
        // overwrites them, so unfreeze() can put it back instead of just
        // deleting it outright.
        preFreezeSnapshot.put(uid, new PotionEffect[] {
            PotionUtils.snapshotIfInfinite(entity, PotionEffectType.SLOWNESS),
            PotionUtils.snapshotIfInfinite(entity, PotionEffectType.MINING_FATIGUE),
            PotionUtils.snapshotIfInfinite(entity, PotionEffectType.JUMP_BOOST)
        });

        int dur = durationTicks + 5;
        entity.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, dur, 254, false, false));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, dur, 254, false, false));
        entity.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, dur, 128, false, false));

        // Cancel any previous freeze task for this entity before starting a new one
        Integer existing = frozenTaskIds.remove(uid);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);

        BukkitRunnable lockTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= durationTicks || !entity.isValid()) {
                    unfreeze(entity);
                    cancel();
                    return;
                }
                if (entity.getLocation().distanceSquared(loc) > 0.1) {
                    entity.teleport(loc);
                }
                entity.setVelocity(new Vector(0, 0, 0));

                // Sparse frost accent while locked — every 4th tick, single
                // cyan particle, instead of the old 9-particle-per-tick
                // SNOWFLAKE/ITEM_SNOWBALL cloud.
                if (ticks % 4 == 0) {
                    entity.getWorld().spawnParticle(Particle.DUST, entity.getLocation().add(0, 1, 0),
                            1, 0.2, 0.3, 0.2, 0, FROST_LOCK_CYAN);
                }

                ticks++;
            }
        };
        int taskId = lockTask.runTaskTimer(plugin, 0L, 1L).getTaskId();
        frozenTaskIds.put(uid, taskId);
    }

    public void unfreeze(LivingEntity entity) {
        UUID uid = entity.getUniqueId();
        frozenEntities.remove(uid);
        Integer taskId = frozenTaskIds.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);
        entity.removePotionEffect(PotionEffectType.SLOWNESS);
        entity.removePotionEffect(PotionEffectType.MINING_FATIGUE);
        entity.removePotionEffect(PotionEffectType.JUMP_BOOST);

        // Restore whatever infinite passive was there before the freeze,
        // if any — this is what stops unfreezing from permanently erasing
        // an unrelated potion's owned effect.
        PotionEffect[] snapshot = preFreezeSnapshot.remove(uid);
        if (snapshot != null) {
            PotionUtils.restoreIfMissing(entity, PotionEffectType.SLOWNESS, snapshot[0]);
            PotionUtils.restoreIfMissing(entity, PotionEffectType.MINING_FATIGUE, snapshot[1]);
            PotionUtils.restoreIfMissing(entity, PotionEffectType.JUMP_BOOST, snapshot[2]);
        }
    }

    public boolean isFrozen(UUID uid) {
        return frozenEntities.containsKey(uid);
    }

    public void unfreezeAll() {
        for (int id : frozenTaskIds.values()) {
            plugin.getServer().getScheduler().cancelTask(id);
        }
        frozenEntities.clear();
        frozenTaskIds.clear();
        preFreezeSnapshot.clear();
    }
}

package com.potionsmp.utils;

import com.potionsmp.PotionSMP;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PotionUtils {

    private static NamespacedKey key() {
        return new NamespacedKey(PotionSMP.getInstance(), "potionsmp_type");
    }

    /**
     * Returns the PotionType of this item, or null if it's not a PotionSMP potion.
     */
    public static PotionType getPotionType(ItemStack item) {
        if (item == null || item.getType() != Material.POTION) return null;
        if (!item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (!meta.getPersistentDataContainer().has(key(), PersistentDataType.STRING)) return null;
        String id = meta.getPersistentDataContainer().get(key(), PersistentDataType.STRING);
        return PotionType.fromId(id);
    }

    public static void tagPotion(ItemMeta meta, PotionType type) {
        meta.getPersistentDataContainer().set(key(), PersistentDataType.STRING, type.getId());
    }

    public static int getModelData(PotionType type) {
        return PotionSMP.getInstance().getConfig().getInt("potions." + type.getId() + ".custom-model-data", 100);
    }

    public static String msg(String key) {
        String raw = PotionSMP.getInstance().getConfig().getString("messages." + key, "&cMissing message: " + key);
        return colorize(raw);
    }

    public static String colorize(String s) {
        return s.replace("&", "\u00a7");
    }

    /**
     * Whether equip/passive-on-equip chat spam should be suppressed.
     * Defaults to true (quiet) if unset. Active-ability, cooldown, error,
     * and combat-critical messages are never gated by this — only the
     * "X equipped to Slot N", "Slot N replaced", and per-ability
     * "passive active" lines fired from onEquip().
     */
    public static boolean isQuiet() {
        return PotionSMP.getInstance().getConfig().getBoolean("messages.quiet", true);
    }

    // ── Generic infinite-effect ownership guard ─────────────────────────
    //
    // Bukkit always replaces a same-type PotionEffect outright — there is
    // no stacking, no "stronger one wins" comparison. That means any code
    // that temporarily applies an effect (a CC debuff, an active ability's
    // own boosted variant, etc.) to an entity that already has an infinite
    // PotionSMP passive of that exact PotionEffectType will silently and
    // permanently erase that passive once the temporary one naturally
    // expires — nothing puts the infinite one back.
    //
    // These three helpers are a generic, type-agnostic snapshot/restore
    // pattern for that situation. They don't know or care which ability or
    // potion owns the effect — only whether an "infinite" one (by either
    // convention this codebase uses: Bukkit's own -1, or the
    // Integer.MAX_VALUE every Ability.onEquip() actually applies) existed
    // right before it's about to be overwritten. Call sites: snapshot
    // before overwriting, then restore later only if nothing else has
    // legitimately taken over that effect type in the meantime.

    /** True for Bukkit's own -1 convention OR the Integer.MAX_VALUE convention every Ability actually uses. */
    public static boolean isInfinite(PotionEffect effect) {
        return effect.isInfinite() || effect.getDuration() > 1_000_000;
    }

    /**
     * Call BEFORE overwriting/removing an effect of this type on this
     * entity. Returns the current effect if it's an infinite PotionSMP
     * passive (safe to restore later), or null if there's nothing to
     * protect (no effect present, or a normal finite/vanilla one — which
     * should just behave like vanilla and is never restored here).
     */
    public static PotionEffect snapshotIfInfinite(LivingEntity entity, PotionEffectType type) {
        PotionEffect current = entity.getPotionEffect(type);
        return (current != null && isInfinite(current)) ? current : null;
    }

    /**
     * Call AFTER a temporary effect of this type has ended (naturally
     * expired, or been explicitly removed). Re-applies the snapshot only
     * if the entity currently has NO effect of this type — i.e. it's
     * actually gone, not legitimately replaced by something newer applied
     * in the meantime, which is left alone.
     */
    public static void restoreIfMissing(LivingEntity entity, PotionEffectType type, PotionEffect snapshot) {
        if (snapshot == null || !entity.isValid()) return;
        if (entity.getPotionEffect(type) == null) {
            entity.addPotionEffect(snapshot);
        }
    }
}

package com.potionsmp.utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.List;

public class ItemBuilder {

    public static ItemStack buildPotion(com.potionsmp.utils.PotionType type) {
        ItemStack item = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) item.getItemMeta();

        meta.setCustomModelData(PotionUtils.getModelData(type));
        meta.setDisplayName(type.getDisplayName());

        switch (type) {

            case FIRE -> {
                // Vanilla base intentionally neutralized to WATER — see note on HASTE
                // below. The Fire Resistance vanilla effect must never be granted;
                // PotionSMP's own Fire passive/active system handles this potion.
                // setColor() is visual-only (matches vanilla Fire Resistance's real
                // liquid color, #FF9900) — it does NOT grant any effect.
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(255, 153, 0));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fEvery 10 hits ignites enemies"),
                    PotionUtils.colorize("&7Passive: &fInfinite Fire Resistance"),
                    PotionUtils.colorize("&7Active: &c&lInferno Rage &7(10×10 aura, 10s)"),
                    PotionUtils.colorize("&eCooldown: &f30s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case FREEZE -> {
                // Visual-only: vanilla Water Breathing color (#98DAC0).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(152, 218, 192));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fEvery 10 hits stuns target for 1s"),
                    PotionUtils.colorize("&7Active: &b&lArctic Prison &7(10-block freeze zone)"),
                    PotionUtils.colorize("&eCooldown: &f45s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case REGEN -> {
                // Visual-only: vanilla Regeneration color (#CD5CAB).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(205, 92, 171));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fRegeneration I (always active)"),
                    PotionUtils.colorize("&7Active: &a&lVitality Surge"),
                    PotionUtils.colorize("&f  Double-jump to launch · Mace Dive for 10-heart AoE"),
                    PotionUtils.colorize("&f  Land again to re-launch while ability is active"),
                    PotionUtils.colorize("&eCooldown: &f45s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case GLITCH -> {
                // Visual-only: vanilla Harming/Instant Damage color (#A9656A).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(169, 101, 106));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fMining Fatigue I + glitch aura"),
                    PotionUtils.colorize("&7Active: &d&lSystem Corruption &7(10s)"),
                    PotionUtils.colorize("&f  Force-drop · no pickup · teleport stutter"),
                    PotionUtils.colorize("&eCooldown: &f35s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case SHIELD -> {
                // Visual-only: vanilla Turtle Master color (#8D82E6).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(141, 130, 230));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Active: &f&lDivine Barrier &7(8s)"),
                    PotionUtils.colorize("&f  Full damage + knockback immunity"),
                    PotionUtils.colorize("&f  Dual spinning celestial rings"),
                    PotionUtils.colorize("&eCooldown: &f45s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case ENDER -> {
                // Visual-only: vanilla Night Vision color (#C2FF66).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(194, 255, 102));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &5Void Corruption"),
                    PotionUtils.colorize("&f  Every 10 hits → void lightning + 1s stun + true dmg"),
                    PotionUtils.colorize("&7Active: &5&lAbyss Domain &7(12s, 15-block radius)"),
                    PotionUtils.colorize("&f  Blindness · Weakness II · True DOT · Void Lightning"),
                    PotionUtils.colorize("&f  Suppresses Teleport/Shield/Regen inside zone"),
                    PotionUtils.colorize("&eCooldown: &f180s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case TELEPORT -> {
                // Visual-only: vanilla Invisibility color (#F6F6F6).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(246, 246, 246));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &3Infinite Invisibility"),
                    PotionUtils.colorize("&f  Faint shadow trail — barely detectable"),
                    PotionUtils.colorize("&7Active: &3&lShadow Teleport &7(instant)"),
                    PotionUtils.colorize("&f  5s countdown → teleport to nearest player"),
                    PotionUtils.colorize("&f  Applies Nausea + Blindness to target (3s)"),
                    PotionUtils.colorize("&eCooldown: &f90s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case SPEED -> {
                // Visual-only: vanilla Swiftness color (#33EBFF).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(51, 235, 255));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &eSpeed I (stacks to Speed IV on hits)"),
                    PotionUtils.colorize("&f  Speed resets to I if no hit for 1.5s"),
                    PotionUtils.colorize("&f  25% reduced iframes on targets"),
                    PotionUtils.colorize("&7Active: &e&lLightning Dash &7(1.8s)"),
                    PotionUtils.colorize("&f  Dash forward · shockwave on end"),
                    PotionUtils.colorize("&eCooldown: &f28s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case FEATHER -> {
                // Visual-only: vanilla Slow Falling color (#F3CFB9).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(243, 207, 185));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fFully immune to fall damage"),
                    PotionUtils.colorize("&f  Auto-glide when falling — slow descent"),
                    PotionUtils.colorize("&f  Preserves horizontal momentum while gliding"),
                    PotionUtils.colorize("&f  Glide ends automatically on landing"),
                    PotionUtils.colorize("&7Active: &fNone (fully passive potion)"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case EMERALD -> {
                // Visual-only: vanilla Luck color (#59C106).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(89, 193, 6));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &aPermanent Luck"),
                    PotionUtils.colorize("&f  Mob drops = Looting III · 1.5× EXP"),
                    PotionUtils.colorize("&f  15% chance consumables are not consumed"),
                    PotionUtils.colorize("&7Active: &a&lHero's Blessing &7(11s)"),
                    PotionUtils.colorize("&f  Hero of the Village · 3× EXP · 30% item save"),
                    PotionUtils.colorize("&eCooldown: &f50s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case STRENGTH -> {
                // Visual-only: vanilla Strength color (#FFC700).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(255, 199, 0));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &42× damage to hostile mobs"),
                    PotionUtils.colorize("&f  Bonus dmg at low enemy HP (<6/4/2 hearts)"),
                    PotionUtils.colorize("&7Active: &4&lSpark &7(15s)"),
                    PotionUtils.colorize("&f  Every attack = critical hit"),
                    PotionUtils.colorize("&f  Disables enemy shields · Arrows pierce shields"),
                    PotionUtils.colorize("&eCooldown: &f30s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case HASTE -> {
                // No vanilla "Haste" potion type exists in org.bukkit.potion.PotionType —
                // Minecraft has never had a brewable Haste potion (Haste only comes from
                // beacons/conduits). Use a neutral WATER base + an explicit gold tint so
                // the item still visually reads as "Haste"; the real gameplay identity is
                // carried by PotionUtils.tagPotion() (PDC) + custom-model-data (set above).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(222, 184, 45));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &6Efficiency III + Fortune II on held pickaxe"),
                    PotionUtils.colorize("&f  Haste I always active (+10% attack speed)"),
                    PotionUtils.colorize("&7Active: &6&lHaste Rush &7(10s)"),
                    PotionUtils.colorize("&f  Efficiency 10 · Fortune 5 · Unbreaking 10"),
                    PotionUtils.colorize("&f  Enchants restored automatically after 10s"),
                    PotionUtils.colorize("&eCooldown: &f45s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }
        }

        PotionUtils.tagPotion(meta, type);
        item.setItemMeta(meta);
        return item;
    }
}

package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * §e Speed Potion – Lightning Fast Warrior
 *
 * PASSIVE:
 * - Base Speed I always active
 * - Five consecutive perfect hits within 1.5s → temporary Speed IV
 * - No hit for 1.5s → reset the combo and remain at Speed I
 * - 25% reduced iframes on hit targets
 *
 * ACTIVE – Lightning Dash:
 * - Dash in look direction
 * - Speed IV during dash
 * - 20% damage reduction
 * - Shockwave at end (4-5 block radius)
 * - Duration: 1.8s | Cooldown: 28s
 */
public class SpeedAbility implements Ability, Listener {

    // Consecutive perfect-hit counter per player (0–5).
    // This is dedicated combo state and is never derived from the Speed amplifier.
    private final Map<UUID, Integer> speedStacks   = new HashMap<>();
    // One combo-expiration task per player.
    private final Map<UUID, BukkitTask> comboExpirationTasks = new HashMap<>();
    // Players currently dashing
    private final Set<UUID>          dashing        = new HashSet<>();
    // Pending "restore passive Speed" tasks — keyed so a newer temporary
    // Speed boost (burst OR dash) always supersedes an older one instead
    // of both fighting over the player's Speed effect.
    private final Map<UUID, BukkitTask> pendingSpeedRestore = new HashMap<>();
    private static final long COMBO_WINDOW_TICKS = 30L;
    private static final int  MAX_HITS           = 5;
    // Speed IV (5th perfect hit) now lasts exactly 3 seconds instead of
    // being permanent.
    private static final int  SPEED_IV_BURST_TICKS = 60;


    @Override
    public PotionType type() { return PotionType.SPEED; }

    // ── Equip / Unequip ───────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        applySpeed(plugin, player, 1);
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        speedStacks.remove(uid);
        dashing.remove(uid);
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();
        BukkitTask combo = comboExpirationTasks.remove(uid);
        if (combo != null) combo.cancel();
        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.SPEED);
    }

    // ── Cleanup on quit / death — Multiple Dash Fix ────────────────────────
    // Ensures "dashing" (and related temp-boost state) can never get stuck
    // if the player disconnects or dies mid-dash.

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uid = event.getPlayer().getUniqueId();
        dashing.remove(uid);
        speedStacks.remove(uid);
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();
        BukkitTask combo = comboExpirationTasks.remove(uid);
        if (combo != null) combo.cancel();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID uid = player.getUniqueId();

        // Minecraft clears active potion effects on death. Cancel any
        // pending Speed restore so it cannot fire while the player is dead.
        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();

        // The stack-decay loop must also stop during the dead state;
        // PassiveReapplyListener starts a fresh, idempotent loop on respawn.
        BukkitTask combo = comboExpirationTasks.remove(uid);
        if (combo != null) combo.cancel();

        dashing.remove(uid);

        // Do not call clear(): death has already wiped the Bukkit effect, so
        // restoring the pre-PotionSMP Resistance snapshot would be wrong.
        // Discard only our bookkeeping claim; the respawn equip path will
        // create fresh ownership state.
        PotionSMP plugin = PotionSMP.getInstance();
        if (plugin != null) {
            plugin.getEffectOwnershipManager()
                .discard(player, type(), PotionEffectType.RESISTANCE);
        }
    }

    // ── Passive hit: five-hit perfect combo ───────────────────────────────

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        UUID uid = player.getUniqueId();

        int hits = Math.min(speedStacks.getOrDefault(uid, 0) + 1, MAX_HITS);
        speedStacks.put(uid, hits);

        // Every valid hit resets the 1.5 second combo window. There is never
        // more than one expiration task for a player.
        BukkitTask previous = comboExpirationTasks.remove(uid);
        if (previous != null) previous.cancel();

        if (hits < MAX_HITS) {
            // The passive state remains Speed I until the fifth hit.
            applySpeed(plugin, player, 1);
            scheduleComboExpiration(plugin, player);
        } else {
            // Fifth hit: trigger the existing temporary Speed IV burst.
            speedStacks.put(uid, 0);
            applyTemporarySpeed(plugin, player, 3, SPEED_IV_BURST_TICKS);
        }

        // Reduce iframes by 25% (set to 75% of default 20)
        target.setNoDamageTicks(Math.max(0, (int)(target.getNoDamageTicks() * 0.75)));

        // Spark on hit
        target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,
            target.getLocation().add(0,1,0), 4, 0.2,0.2,0.2, 0.05);
    }

    private void scheduleComboExpiration(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            comboExpirationTasks.remove(uid);
            if (!player.isOnline()) return;
            if (!plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) return;

            speedStacks.put(uid, 0);

            // Do not overwrite an unrelated temporary Speed IV (for example
            // the existing dash). Its own restore task will return to the
            // correct passive Speed I state.
            if (!pendingSpeedRestore.containsKey(uid)) {
                applySpeed(plugin, player, 1);
            }
        }, COMBO_WINDOW_TICKS);
        comboExpirationTasks.put(uid, task);
    }

    private void applySpeed(PotionSMP plugin, Player player, int level) {
        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, level - 1, false, false));
    }

    /**
     * Applies a TIME-LIMITED Speed effect (never Integer.MAX_VALUE) and
     * schedules a restore of the player's correct passive Speed level once
     * it naturally expires. Shared by both the 5th-hit Speed IV burst and
     * Dash's own Speed IV so neither one permanently loses/overwrites the
     * hit-combo passive level — a newer temporary boost always cancels and
     * replaces any older pending restore.
     */
    private void applyTemporarySpeed(PotionSMP plugin, Player player, int amplifier, int durationTicks) {
        UUID uid = player.getUniqueId();

        BukkitTask pending = pendingSpeedRestore.remove(uid);
        if (pending != null) pending.cancel();

        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.SPEED, durationTicks, amplifier, false, false));

        BukkitTask restore = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            pendingSpeedRestore.remove(uid);
            if (!player.isOnline()) return;
            if (!plugin.getSlotManager().hasEquipped(uid, PotionType.SPEED)) return;

            // Speed IV is always temporary. After the burst, return directly
            // to the passive/default Speed I state.
            speedStacks.put(uid, 0);
            applySpeed(plugin, player, 1);
        }, durationTicks);

        pendingSpeedRestore.put(uid, restore);
    }

    // ── Active: Lightning Dash ────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        // Hard guard: never allow a second dash while one is already
        // active — checked independently of cooldown timing/config so it
        // can't be bypassed even with a custom short cooldown value.
        if (dashing.contains(uid)) return ActivationResult.ON_COOLDOWN;

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        int cooldown = plugin.getConfig().getInt("potions.speed.active-cooldown", 28);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

        executeDash(plugin, player);
        return ActivationResult.SUCCESS;
    }

    private void executeDash(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        dashing.add(uid);

        // Speed IV + 20% damage reduction during dash. Speed IV is applied
        // as a temporary boost (via applyTemporarySpeed) so the player's
        // correct passive Speed level is automatically restored once the
        // dash's speed window ends, instead of being left with no Speed
        // effect at all.
        applyTemporarySpeed(plugin, player, 3, 40);
        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.RESISTANCE, 40, 0, false, false));

        // Launch in look direction
        Vector dir = player.getLocation().getDirection().normalize().multiply(1.4);
        dir.setY(Math.max(dir.getY(), 0.1));
        player.setVelocity(dir);

        player.sendTitle("", "§e⚡ Lightning Dash!", 2, 15, 5);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.8f);

        // Dash trail
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= 36 || !player.isOnline() || player.isDead() || !dashing.contains(uid)) { // 1.8s
                    if (player.isOnline() && !player.isDead()) {
                        triggerShockwave(plugin, player);
                        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.RESISTANCE);
                    }
                    dashing.remove(uid);
                    cancel(); return;
                }
                Location loc = player.getLocation();
                loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 5, 0.2,0.2,0.2, 0.05);
                loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK,   loc, 2, 0.3,0.1,0.3, 0);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void triggerShockwave(PotionSMP plugin, Player player) {
        Location loc = player.getLocation();
        World world  = loc.getWorld();
        double radius = plugin.getConfig().getDouble("potions.speed.shockwave-radius", 4.5);
        double dmg    = plugin.getConfig().getDouble("potions.speed.shockwave-damage", 5.0);

        // Ring particles
        for (int i = 0; i < 36; i++) {
            double angle = Math.toRadians(i * 10);
            Location p = loc.clone().add(Math.cos(angle)*radius, 0.1, Math.sin(angle)*radius);
            world.spawnParticle(Particle.ELECTRIC_SPARK, p, 2, 0.1,0.1,0.1, 0.05);
            world.spawnParticle(Particle.SWEEP_ATTACK,   p, 1, 0,0,0, 0);
        }

        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.4f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.5f);

        // Damage + knockback nearby
        for (Entity e : world.getNearbyEntities(loc, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(player.getUniqueId())) continue;
            le.damage(dmg, player);
            le.setNoDamageTicks(0);
            Vector kb = le.getLocation().toVector().subtract(loc.toVector()).normalize()
                .multiply(1.5).setY(0.5);
            le.setVelocity(kb);
        }
    }
}

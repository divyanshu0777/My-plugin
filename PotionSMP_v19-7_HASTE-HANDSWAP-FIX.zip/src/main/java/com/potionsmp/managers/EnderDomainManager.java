package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.abilities.Ability;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Manages the Ender Potion's Abyss Domain active ability.
 *
 * Domain (15-block radius, 12s):
 *  - Enemies: Blindness + Weakness II + True DOT every second
 *  - Void lightning every 2s on random enemy
 *  - Rotating dragon-breath energy rings
 *  - Suppresses Teleport/Shield/Regen abilities for enemies inside
 *  - Collapses with void explosion after duration
 */
public class EnderDomainManager {

    private final PotionSMP plugin;

    private final Map<UUID, BukkitTask> domainTasks  = new HashMap<>();
    private final Map<UUID, BukkitTask> lightnTasks  = new HashMap<>();

    /**
     * Enemies inside domain(s): targetUUID → the set of domain-owner UUIDs
     * whose Abyss Domain currently covers them. A Set (not a single UUID) is
     * required so overlapping domains from different owners are tracked
     * independently — a player only counts as unsuppressed once this set is
     * empty, i.e. once they've left every domain that was covering them.
     * This is the ONE source of truth every suppressible ability checks via
     * {@link #isSuppressed(UUID)}.
     */
    private final Map<UUID, Set<UUID>> suppressed = new HashMap<>();

    public EnderDomainManager(PotionSMP plugin) { this.plugin = plugin; }

    // ── Is a player suppressed? ───────────────────────────────────────────

    public boolean isSuppressed(UUID uuid) {
        Set<UUID> owners = suppressed.get(uuid);
        return owners != null && !owners.isEmpty();
    }

    // ── Regen's passive effect has no recurring loop of its own to gate, so
    //    it's stripped/restored right at the suppress/unsuppress transition
    //    detected above. Guarded by SlotManager so a vanilla Regeneration
    //    effect (from an unrelated potion, beacon, etc.) is never touched —
    //    only the PotionSMP one, and only for players who actually have the
    //    Regen ability equipped. ──────────────────────────────────────────

    private void suppressRegenIfEquipped(Player player) {
        if (plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.REGEN)) {
            player.removePotionEffect(PotionEffectType.REGENERATION);
        }
    }

    private void restoreRegenIfEquipped(UUID uid) {
        Player player = plugin.getServer().getPlayer(uid);
        if (player == null || !player.isOnline()) return;
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.REGEN)) return;
        Ability regen = plugin.getAbilityRegistry().get(PotionType.REGEN);
        if (regen != null) regen.onEquip(plugin, player);
    }

    // ── Start domain ──────────────────────────────────────────────────────

    public void startDomain(Player owner) {
        UUID uid = owner.getUniqueId();
        cancelPlayer(uid);

        int    durSec    = plugin.getConfig().getInt("potions.ender.active-duration", 12);
        int    durTicks  = durSec * 20;
        double radius    = plugin.getConfig().getDouble("potions.ender.domain-radius", 15.0);
        double dotDmg    = plugin.getConfig().getDouble("potions.ender.dot-damage", 1.5);
        int    lIntTicks = plugin.getConfig().getInt("potions.ender.lightning-interval-ticks", 40);
        double lDmg      = plugin.getConfig().getDouble("potions.ender.lightning-damage", 4.0);

        Location center = owner.getLocation().clone();

        // Activation burst
        spawnActivationBurst(center, radius);
        center.getWorld().playSound(center, Sound.ENTITY_ENDER_DRAGON_GROWL,  1.5f, 0.6f);
        center.getWorld().playSound(center, Sound.BLOCK_END_PORTAL_SPAWN,      1.0f, 0.5f);
        owner.sendTitle("§5§l☠ ABYSS DOMAIN", "§8Void corruption spreads...", 5, 40, 10);

        // Main loop – every 20 ticks (1 s)
        BukkitTask domain = new BukkitRunnable() {
            int elapsed = 0;
            double ringAngle = 0;

            @Override
            public void run() {
                if (elapsed >= durTicks || !owner.isOnline()) {
                    endDomain(owner);
                    cancel();
                    return;
                }
                drawVoidRings(center, radius, ringAngle);
                ringAngle += 18;
                spawnGroundVoid(center, radius);
                applyDebuffs(owner, center, radius, dotDmg);
                center.getWorld().playSound(center, Sound.ENTITY_ENDER_DRAGON_AMBIENT, 0.5f, 0.3f);
                elapsed += 20;
            }
        }.runTaskTimer(plugin, 0L, 20L);
        domainTasks.put(uid, domain);

        // Lightning loop
        BukkitTask lightning = new BukkitRunnable() {
            int elapsed = 0;
            @Override
            public void run() {
                if (elapsed >= durTicks || !owner.isOnline()) { cancel(); return; }
                List<LivingEntity> enemies = getEnemies(owner, center, radius);
                if (!enemies.isEmpty()) {
                    LivingEntity target = enemies.get(new Random().nextInt(enemies.size()));
                    strikeVoid(owner, target, lDmg);
                }
                elapsed += lIntTicks;
            }
        }.runTaskTimer(plugin, lIntTicks, lIntTicks);
        lightnTasks.put(uid, lightning);

        // Auto-end
        plugin.getServer().getScheduler().runTaskLater(plugin,
            () -> { if (domainTasks.containsKey(uid)) endDomain(owner); },
            durTicks + 2L);
    }

    // ── Apply debuffs each tick ───────────────────────────────────────────

    private void applyDebuffs(Player owner, Location center, double radius, double dot) {
        UUID uid = owner.getUniqueId();
        List<LivingEntity> enemies = getEnemies(owner, center, radius);
        Set<UUID> currentlyInside = new HashSet<>();

        for (LivingEntity enemy : enemies) {
            UUID enemyId = enemy.getUniqueId();
            currentlyInside.add(enemyId);

            boolean wasSuppressed = isSuppressed(enemyId);
            suppressed.computeIfAbsent(enemyId, k -> new HashSet<>()).add(uid);
            // Strip PotionSMP's own Regen effect the moment they first enter
            // suppression (from this or any domain) — see requirement that
            // Regen must not keep providing its regeneration while suppressed.
            if (!wasSuppressed && enemy instanceof Player p) {
                suppressRegenIfEquipped(p);
            }

            enemy.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 0, false, false));
            enemy.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS,  30, 1, false, false));
            enemy.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING,   30, 0, false, false));
            enemy.damage(dot, owner);
            enemy.setNoDamageTicks(0);
            enemy.getWorld().spawnParticle(Particle.DRAGON_BREATH,
                enemy.getLocation().add(0,1,0), 5, 0.3,0.5,0.3, 0.02);
            if (enemy instanceof Player p)
                p.sendActionBar(net.kyori.adventure.text.Component.text(
                    "§5☠ Inside " + owner.getName() + "'s Abyss Domain!"));
        }

        // Release this domain's hold on anyone no longer inside it. A player
        // only becomes fully unsuppressed (and gets abilities restored) once
        // their owner-set is empty — i.e. no OTHER overlapping domain is
        // still covering them either.
        for (Iterator<Map.Entry<UUID, Set<UUID>>> it = suppressed.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Set<UUID>> entry = it.next();
            if (currentlyInside.contains(entry.getKey())) continue;
            Set<UUID> owners = entry.getValue();
            if (owners.remove(uid) && owners.isEmpty()) {
                it.remove();
                restoreRegenIfEquipped(entry.getKey());
            }
        }
    }

    // ── Void lightning ────────────────────────────────────────────────────

    private void strikeVoid(Player owner, LivingEntity target, double dmg) {
        Location loc = target.getLocation();
        loc.getWorld().strikeLightningEffect(loc);
        target.damage(dmg, owner);
        target.setNoDamageTicks(0);
        target.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, false, false));
        loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, loc.clone().add(0,1,0), 15, 0.5,1,0.5, 0.05);
        loc.getWorld().spawnParticle(Particle.REVERSE_PORTAL, loc.clone().add(0,1,0), 10, 0.4,0.6,0.4, 0.1);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1f, 0.5f);
        loc.getWorld().playSound(loc, Sound.BLOCK_END_GATEWAY_SPAWN,      1f, 0.8f);
    }

    // ── Collapse ──────────────────────────────────────────────────────────

    public void endDomain(Player owner) {
        UUID uid = owner.getUniqueId();
        cancelPlayer(uid);
        // Remove this domain's hold on everyone it was suppressing. Anyone
        // whose owner-set becomes empty as a result is now fully
        // unsuppressed — but if another overlapping domain still covers
        // them, their set still isn't empty and they stay suppressed.
        for (Iterator<Map.Entry<UUID, Set<UUID>>> it = suppressed.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Set<UUID>> entry = it.next();
            Set<UUID> owners = entry.getValue();
            if (owners.remove(uid) && owners.isEmpty()) {
                it.remove();
                restoreRegenIfEquipped(entry.getKey());
            }
        }
        if (!owner.isOnline()) return;
        Location loc = owner.getLocation();
        loc.getWorld().spawnParticle(Particle.DRAGON_BREATH, loc, 200, 8,2,8, 0.1);
        loc.getWorld().spawnParticle(Particle.PORTAL,        loc, 300, 8,3,8, 0.5);
        loc.getWorld().spawnParticle(Particle.END_ROD,       loc, 100, 5,3,5, 0.3);
        loc.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_DEATH, 0.8f, 0.4f);
        loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE,    1.0f, 0.5f);
        owner.sendTitle("", "§8Domain collapsed.", 5, 20, 10);
    }

    // ── Visual helpers ────────────────────────────────────────────────────

    private void drawVoidRings(Location center, double radius, double offset) {
        int pts = (int)(radius * 6);
        for (int r = 0; r < 3; r++) {
            double rad = radius * (0.4 + r * 0.3);
            double y   = r * 1.0;
            for (int i = 0; i < pts; i++) {
                double a = Math.toRadians((360.0/pts)*i + offset + r*60);
                Location p = center.clone().add(Math.cos(a)*rad, y, Math.sin(a)*rad);
                center.getWorld().spawnParticle(Particle.DRAGON_BREATH, p, 1, 0,0,0, 0);
                if (i % 5 == 0)
                    center.getWorld().spawnParticle(Particle.PORTAL, p, 1, 0,0,0, 0.1);
            }
        }
    }

    private void spawnGroundVoid(Location center, double radius) {
        for (int i = 0; i < 8; i++) {
            double a = Math.random() * Math.PI * 2;
            double r = Math.random() * radius;
            Location p = center.clone().add(Math.cos(a)*r, 0.1, Math.sin(a)*r);
            center.getWorld().spawnParticle(Particle.DRAGON_BREATH,   p, 1, 0,0,0, 0.01);
            center.getWorld().spawnParticle(Particle.REVERSE_PORTAL,  p, 1, 0.1,0,0.1, 0.02);
        }
    }

    private void spawnActivationBurst(Location center, double radius) {
        center.getWorld().spawnParticle(Particle.DRAGON_BREATH,  center, 150, radius*.5, 2, radius*.5, 0.1);
        center.getWorld().spawnParticle(Particle.PORTAL,         center, 200, radius*.5, 3, radius*.5, 0.5);
        center.getWorld().spawnParticle(Particle.REVERSE_PORTAL, center, 100, radius*.4, 2, radius*.4, 0.2);
        center.getWorld().spawnParticle(Particle.END_ROD,        center,  80, radius*.4, 2, radius*.4, 0.2);
        center.getWorld().spawnParticle(Particle.SQUID_INK,      center,  60, radius*.3, 1, radius*.3, 0.1);
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private List<LivingEntity> getEnemies(Player owner, Location center, double radius) {
        List<LivingEntity> list = new ArrayList<>();
        for (Entity e : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(owner.getUniqueId())) continue;
            if (e instanceof ArmorStand) continue;
            list.add(le);
        }
        return list;
    }

    private void cancelPlayer(UUID uid) {
        BukkitTask d = domainTasks.remove(uid);
        if (d != null) d.cancel();
        BukkitTask l = lightnTasks.remove(uid);
        if (l != null) l.cancel();
    }

    public void cancelAll() {
        new HashSet<>(domainTasks.keySet()).forEach(uid -> {
            Player p = plugin.getServer().getPlayer(uid);
            if (p != null) endDomain(p); else cancelPlayer(uid);
        });
        suppressed.clear();
    }

    public boolean hasDomain(UUID uuid) { return domainTasks.containsKey(uuid); }
}

package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Tracks which PotionType (if any) occupies Slot 1 and Slot 2 for each player.
 * Drinking a potion always goes into Slot 1, replacing whatever was there
 * (Slot 2 is untouched). A future /swap command can move Slot 1 <-> Slot 2.
 *
 * The in-memory maps below are the fast path used during a live session
 * (including across a disconnect/reconnect on the same running server —
 * nothing clears them on quit, by design). {@link #saveToPlayer} and
 * {@link #loadFromPlayer} mirror that state into the player's own
 * PersistentDataContainer, which Bukkit saves as part of the player's data
 * file — so it survives a real server restart. Only two small string values
 * are stored; reused via {@link PotionType#getId()} / {@link
 * PotionType#fromId}, the same round-trip already used for tagging potion
 * items, so no new data format is introduced.
 */
public class SlotManager {

    public static final int SLOT_1 = 1;
    public static final int SLOT_2 = 2;

    private static final String PDC_KEY_SLOT1 = "potionsmp_slot1";
    private static final String PDC_KEY_SLOT2 = "potionsmp_slot2";

    private final Map<UUID, PotionType> slot1 = new HashMap<>();
    private final Map<UUID, PotionType> slot2 = new HashMap<>();

    public PotionType getSlot1(UUID uuid) {
        return slot1.get(uuid);
    }

    public PotionType getSlot2(UUID uuid) {
        return slot2.get(uuid);
    }

    public PotionType getSlot(UUID uuid, int slot) {
        return slot == SLOT_1 ? getSlot1(uuid) : getSlot2(uuid);
    }

    /**
     * Places a potion into Slot 1, returning whatever was previously there
     * (or null if Slot 1 was empty).
     */
    public PotionType setSlot1(UUID uuid, PotionType type) {
        return slot1.put(uuid, type);
    }

    public PotionType setSlot2(UUID uuid, PotionType type) {
        return slot2.put(uuid, type);
    }

    public void swap(UUID uuid) {
        PotionType a = slot1.get(uuid);
        PotionType b = slot2.get(uuid);
        if (b != null) slot1.put(uuid, b); else slot1.remove(uuid);
        if (a != null) slot2.put(uuid, a); else slot2.remove(uuid);
    }

    /** True if this potion type currently occupies EITHER slot for this player. */
    public boolean hasEquipped(UUID uuid, PotionType type) {
        return type != null && (type.equals(slot1.get(uuid)) || type.equals(slot2.get(uuid)));
    }

    public void clearAll(UUID uuid) {
        slot1.remove(uuid);
        slot2.remove(uuid);
    }

    private NamespacedKey slot1Key() {
        return new NamespacedKey(PotionSMP.getInstance(), PDC_KEY_SLOT1);
    }

    private NamespacedKey slot2Key() {
        return new NamespacedKey(PotionSMP.getInstance(), PDC_KEY_SLOT2);
    }

    /**
     * Writes this player's current Slot 1 / Slot 2 into their own
     * PersistentDataContainer, so it survives a server restart. Call right
     * after any slot mutation for which a live Player is available.
     */
    public void saveToPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        PersistentDataContainer pdc = player.getPersistentDataContainer();

        PotionType t1 = slot1.get(uuid);
        if (t1 != null) pdc.set(slot1Key(), PersistentDataType.STRING, t1.getId());
        else pdc.remove(slot1Key());

        PotionType t2 = slot2.get(uuid);
        if (t2 != null) pdc.set(slot2Key(), PersistentDataType.STRING, t2.getId());
        else pdc.remove(slot2Key());
    }

    /**
     * Restores this player's Slot 1 / Slot 2 from their own
     * PersistentDataContainer — used on join (and, for anyone already online
     * when the plugin is reloaded, once at enable time) so a fresh server
     * process still knows what they had equipped. Missing or unrecognized
     * saved data (a corrupted value, or an id from a potion type that no
     * longer exists) safely leaves that slot empty rather than failing;
     * whatever is already in memory for a slot with no saved value is left
     * untouched.
     */
    public void loadFromPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        PersistentDataContainer pdc = player.getPersistentDataContainer();

        String id1 = pdc.get(slot1Key(), PersistentDataType.STRING);
        PotionType t1 = PotionType.fromId(id1);
        if (t1 != null) slot1.put(uuid, t1);

        String id2 = pdc.get(slot2Key(), PersistentDataType.STRING);
        PotionType t2 = PotionType.fromId(id2);
        if (t2 != null) slot2.put(uuid, t2);
    }
}

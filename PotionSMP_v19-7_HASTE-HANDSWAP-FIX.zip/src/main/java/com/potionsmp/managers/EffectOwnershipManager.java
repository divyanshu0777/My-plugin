package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

/**
 * Central bookkeeping so PotionSMP only ever adds/removes the potion effects
 * it applied itself — never a vanilla effect, a beacon effect, another
 * plugin's effect, or another PotionSMP ability's effect of the same type.
 *
 * Bukkit only allows ONE active {@link PotionEffect} instance per (entity,
 * type) at a time, so any naive addPotionEffect()/removePotionEffect() call
 * risks silently clobbering — or later blindly deleting — whatever else was
 * using that same effect type. This manager tracks, per player and effect
 * type, a small LIFO stack of the PotionSMP claims currently "holding" that
 * slot:
 *
 *  - {@link #apply}: pushes (or refreshes, if the same ability already holds
 *    the slot) a claim, remembering — the FIRST time PotionSMP ever touches
 *    that slot for that player — whatever non-PotionSMP effect (if any) was
 *    already active there.
 *  - {@link #clear}: pops only the calling ability's own claim. If another
 *    PotionSMP ability's claim is still underneath, its effect is handed
 *    straight back (so ending one ability's effect can never wipe out
 *    another's). Only once every PotionSMP claim on that slot is gone is the
 *    original pre-PotionSMP effect restored (or, if there wasn't one, the
 *    slot is simply cleared).
 *
 * No repeating task is used for this — all bookkeeping happens exactly at
 * the moments an ability itself calls apply()/clear(); the existing
 * per-ability passive loops already provide any periodic refreshing needed.
 */
public class EffectOwnershipManager {

    private final PotionSMP plugin;

    private static final class Claim {
        final PotionType owner;
        final PotionEffect effect;
        Claim(PotionType owner, PotionEffect effect) {
            this.owner = owner;
            this.effect = effect;
        }
    }

    // player -> effect type -> LIFO stack of PotionSMP claims currently on that slot
    private final Map<UUID, Map<PotionEffectType, Deque<Claim>>> claims = new HashMap<>();
    // player -> effect type -> the non-PotionSMP effect (possibly "none") present
    // right before the FIRST PotionSMP claim ever touched that slot
    private final Map<UUID, Map<PotionEffectType, Optional<PotionEffect>>> original = new HashMap<>();

    public EffectOwnershipManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    /**
     * Apply a PotionSMP-owned effect. If {@code owner} doesn't currently hold
     * this (player, type) slot, whatever is already active there — from any
     * source — is snapshotted first so it can be restored later. If
     * {@code owner} already holds the slot (e.g. a passive refresh tick),
     * its existing claim is simply replaced rather than stacking a duplicate.
     */
    public void apply(Player player, PotionType owner, PotionEffect effect) {
        UUID uid = player.getUniqueId();
        PotionEffectType type = effect.getType();

        Deque<Claim> stack = claims.computeIfAbsent(uid, k -> new HashMap<>())
            .computeIfAbsent(type, k -> new ArrayDeque<>());

        if (stack.isEmpty()) {
            // First PotionSMP touch on this slot for this player — snapshot
            // whatever (possibly nothing) is already active there.
            original.computeIfAbsent(uid, k -> new HashMap<>())
                .putIfAbsent(type, Optional.ofNullable(player.getPotionEffect(type)));
        } else {
            // Refresh in place rather than pushing a duplicate layer for the
            // same ability.
            stack.removeIf(c -> c.owner == owner);
        }

        stack.push(new Claim(owner, effect));
        player.addPotionEffect(effect);
    }

    /**
     * Release {@code owner}'s claim on this (player, type) slot. Does
     * nothing if {@code owner} doesn't currently hold it — which is exactly
     * what keeps one PotionSMP ability from ever removing another's effect
     * of the same type. If another PotionSMP ability's claim is still
     * underneath, its effect is re-applied; only once the stack is fully
     * empty is the original pre-PotionSMP effect restored (or the slot
     * cleared, if there wasn't one).
     */
    public void clear(Player player, PotionType owner, PotionEffectType type) {
        UUID uid = player.getUniqueId();
        Map<PotionEffectType, Deque<Claim>> perPlayer = claims.get(uid);
        if (perPlayer == null) return;
        Deque<Claim> stack = perPlayer.get(type);
        if (stack == null || stack.isEmpty()) return;

        if (!stack.removeIf(c -> c.owner == owner)) return; // we don't hold this slot — never touch it

        if (!stack.isEmpty()) {
            // Another PotionSMP ability still claims this slot.
            player.addPotionEffect(stack.peek().effect);
            return;
        }

        perPlayer.remove(type);
        if (perPlayer.isEmpty()) claims.remove(uid);

        Map<PotionEffectType, Optional<PotionEffect>> perPlayerOriginal = original.get(uid);
        Optional<PotionEffect> restore = perPlayerOriginal != null ? perPlayerOriginal.remove(type) : null;
        if (perPlayerOriginal != null && perPlayerOriginal.isEmpty()) original.remove(uid);

        if (restore != null && restore.isPresent()) {
            player.addPotionEffect(restore.get());
        } else {
            player.removePotionEffect(type);
        }
    }

    /**
     * Discards one PotionSMP ownership claim without touching the player's
     * current Bukkit effect. This is intended for lifecycle events such as
     * death, where Minecraft has already cleared the player's effects and
     * restoring the pre-PotionSMP snapshot would be incorrect.
     */
    public void discard(Player player, PotionType owner, PotionEffectType type) {
        UUID uid = player.getUniqueId();
        Map<PotionEffectType, Deque<Claim>> perPlayer = claims.get(uid);
        if (perPlayer == null) return;

        Deque<Claim> stack = perPlayer.get(type);
        if (stack == null || stack.isEmpty()) return;
        if (!stack.removeIf(c -> c.owner == owner)) return;

        if (stack.isEmpty()) {
            perPlayer.remove(type);
            if (perPlayer.isEmpty()) claims.remove(uid);

            Map<PotionEffectType, Optional<PotionEffect>> perPlayerOriginal = original.get(uid);
            if (perPlayerOriginal != null) {
                perPlayerOriginal.remove(type);
                if (perPlayerOriginal.isEmpty()) original.remove(uid);
            }
        }
    }

    /**
     * Plugin disable/reload: hands every tracked slot, for every currently
     * online player, back to whatever was there before PotionSMP touched it.
     */
    public void restoreAll() {
        for (UUID uid : new HashSet<>(claims.keySet())) {
            Player player = plugin.getServer().getPlayer(uid);
            Map<PotionEffectType, Deque<Claim>> perPlayer = claims.get(uid);
            if (player == null || !player.isOnline() || perPlayer == null) continue;

            Map<PotionEffectType, Optional<PotionEffect>> perPlayerOriginal = original.get(uid);
            for (PotionEffectType type : new HashSet<>(perPlayer.keySet())) {
                Optional<PotionEffect> restore = perPlayerOriginal != null ? perPlayerOriginal.get(type) : null;
                if (restore != null && restore.isPresent()) {
                    player.addPotionEffect(restore.get());
                } else {
                    player.removePotionEffect(type);
                }
            }
        }
        claims.clear();
        original.clear();
    }
}

package com.potionsmp;

import com.potionsmp.abilities.*;
import com.potionsmp.commands.*;
import com.potionsmp.hud.HudManager;
import com.potionsmp.listeners.*;
import com.potionsmp.managers.*;
import com.potionsmp.utils.PotionType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class PotionSMP extends JavaPlugin {

    private static PotionSMP instance;

    private CooldownManager     cooldownManager;
    private HitCounterManager   hitCounterManager;
    private FrozenPlayerManager frozenPlayerManager;
    private FireAuraManager     fireAuraManager;
    private RegenAbilityManager regenAbilityManager;
    private VitalityParticleRenderer vitalityParticleRenderer;
    private EnderDomainManager  enderDomainManager;
    private ParticleManager     particleManager;
    private GlitchManager       glitchManager;
    private ShieldManager       shieldManager;
    private ShieldAuraManager   shieldAuraManager;
    private BossBarManager      bossBarManager;
    private SlotManager         slotManager;
    private FeatherFlightManager featherFlightManager;
    private AbilityRegistry     abilityRegistry;
    private HudManager          hudManager;
    private JumpListener        jumpListener;
    private EffectOwnershipManager effectOwnershipManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // ── Managers ──────────────────────────────────────────────────────
        cooldownManager     = new CooldownManager();
        hitCounterManager   = new HitCounterManager();
        frozenPlayerManager = new FrozenPlayerManager(this); // self-registers events
        fireAuraManager     = new FireAuraManager(this);
        regenAbilityManager = new RegenAbilityManager(this);
        vitalityParticleRenderer = new VitalityParticleRenderer(this);
        enderDomainManager  = new EnderDomainManager(this);
        particleManager     = new ParticleManager(this);
        glitchManager       = new GlitchManager(this);
        shieldAuraManager   = new ShieldAuraManager(this);
        shieldManager       = new ShieldManager(this);
        bossBarManager      = new BossBarManager(this);
        slotManager         = new SlotManager();
        featherFlightManager = new FeatherFlightManager(this);
        abilityRegistry     = new AbilityRegistry();
        hudManager          = new HudManager(this);
        jumpListener        = new JumpListener(this);
        effectOwnershipManager = new EffectOwnershipManager(this);

        // ── Listeners ─────────────────────────────────────────────────────
        var pm = getServer().getPluginManager();
        pm.registerEvents(new DrinkListener(this),  this);
        pm.registerEvents(new CombatListener(this), this);
        pm.registerEvents(jumpListener,              this);
        pm.registerEvents(new GUIListener(this),    this);
        PassiveReapplyListener passiveReapplyListener = new PassiveReapplyListener(this);
        pm.registerEvents(passiveReapplyListener, this);

        // Register every ability that implements Listener. Non-listener abilities
        // simply no-op through Ability.register(plugin). This avoids reflection
        // and keeps listener registration in one place.
        for (PotionType type : PotionType.values()) {
            Ability ability = abilityRegistry.get(type);
            if (ability != null) ability.register(this);
        }

        // ── Commands ──────────────────────────────────────────────────────
        // Primary fix for the startup NPE was adding 'swap' to plugin.yml's
        // commands: section (it was missing). These null-checks are just
        // defense-in-depth so a future plugin.yml edit fails loudly via the
        // log instead of crashing onEnable.
        PotionCommand potionCmd = new PotionCommand(this);
        registerCommand("potionsmp", potionCmd, potionCmd);
        registerCommand("slot1", new SlotCommand(this, SlotManager.SLOT_1), null);
        registerCommand("slot2", new SlotCommand(this, SlotManager.SLOT_2), null);
        registerCommand("swap", new SwapCommand(this), null);

        hudManager.start();

        // Reload safety: a plugin reload while players are already connected
        // fires neither PlayerJoinEvent nor PlayerRespawnEvent for them, so
        // every manager above just started from empty. Rehydrate slots from
        // each online player's PersistentDataContainer and reapply their
        // passives directly, the same way a fresh join would. On a genuine
        // server restart this loop simply does nothing (no players online
        // yet); real joins are still handled by the listener as normal.
        for (Player onlinePlayer : getServer().getOnlinePlayers()) {
            passiveReapplyListener.reapplyNextTick(onlinePlayer);
        }

        getLogger().info("PotionSMP v" + getDescription().getVersion() + " enabled — 12 potions loaded.");
    }

    /**
     * Null-safe command registration. Logs a severe error (instead of
     * crashing onEnable with an NPE) if a command name isn't declared under
     * commands: in plugin.yml.
     */
    private void registerCommand(String name, org.bukkit.command.CommandExecutor executor,
                                  org.bukkit.command.TabCompleter tabCompleter) {
        org.bukkit.command.PluginCommand command = getCommand(name);
        if (command == null) {
            getLogger().severe("Command '" + name + "' is missing from plugin.yml! "
                + "It will not function until it is declared under commands: in plugin.yml.");
            return;
        }
        command.setExecutor(executor);
        if (tabCompleter != null) {
            command.setTabCompleter(tabCompleter);
        }
    }


    @Override
    public void onDisable() {
        frozenPlayerManager.unfreezeAll();
        fireAuraManager.cancelAll();
        enderDomainManager.cancelAll();
        particleManager.cancelAll();
        glitchManager.cancelAll();
        shieldManager.cancelAll();
        shieldAuraManager.cancelAll();
        vitalityParticleRenderer.shutdown();
        bossBarManager.removeAll();
        featherFlightManager.cancelAll();
        effectOwnershipManager.restoreAll();
        // Haste's tracked pickaxe enchants live in item NBT, not a potion
        // effect, so EffectOwnershipManager's restore above doesn't cover
        // them — without this, a player's inventory could be saved to disk
        // mid-Haste with the temporary enchants baked in permanently.
        Ability haste = abilityRegistry.get(PotionType.HASTE);
        if (haste instanceof HasteAbility hasteAbility) hasteAbility.restoreAllTrackedItems(this);
        hudManager.stop();
        getLogger().info("PotionSMP disabled.");
    }

    // ── Accessors ─────────────────────────────────────────────────────────
    public static PotionSMP getInstance()                    { return instance; }
    public CooldownManager getCooldownManager()              { return cooldownManager; }
    public HitCounterManager getHitCounterManager()          { return hitCounterManager; }
    public FrozenPlayerManager getFrozenPlayerManager()      { return frozenPlayerManager; }
    public FireAuraManager getFireAuraManager()              { return fireAuraManager; }
    public RegenAbilityManager getRegenAbilityManager()      { return regenAbilityManager; }
    public VitalityParticleRenderer getVitalityParticleRenderer() { return vitalityParticleRenderer; }
    public EnderDomainManager getEnderDomainManager()        { return enderDomainManager; }
    public SlotManager getSlotManager()                      { return slotManager; }
    public AbilityRegistry getAbilityRegistry()              { return abilityRegistry; }
    public HudManager getHudManager()                        { return hudManager; }
    public ParticleManager getParticleManager()              { return particleManager; }
    public GlitchManager getGlitchManager()                  { return glitchManager; }
    public ShieldManager getShieldManager()                  { return shieldManager; }
    public ShieldAuraManager getShieldAuraManager()          { return shieldAuraManager; }
    public BossBarManager getBossBarManager()                { return bossBarManager; }
    public FeatherFlightManager getFeatherFlightManager()     { return featherFlightManager; }
    public JumpListener getJumpListener()                    { return jumpListener; }
    public EffectOwnershipManager getEffectOwnershipManager() { return effectOwnershipManager; }
}

package com.potionsmp.commands;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Handles the standalone /swap command (registered in plugin.yml).
 * Swaps whatever potions currently occupy Slot 1 and Slot 2 for the player.
 * Mirrors the "swap" subcommand already present in PotionCommand.
 */
public class SwapCommand implements CommandExecutor {

    private final PotionSMP plugin;

    public SwapCommand(PotionSMP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length != 0) {
            sender.sendMessage(PotionUtils.colorize("&cUsage: /" + label));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(PotionUtils.colorize("&cThis command can only be used in-game."));
            return true;
        }

        plugin.getSlotManager().swap(player.getUniqueId());
        plugin.getSlotManager().saveToPlayer(player);
        player.sendMessage(PotionUtils.colorize("&a✦ Swapped Slot 1 and Slot 2!"));

        // Immediate HUD refresh — don't wait for the periodic 10-tick tick
        plugin.getHudManager().sendOnce(player);
        return true;
    }
}

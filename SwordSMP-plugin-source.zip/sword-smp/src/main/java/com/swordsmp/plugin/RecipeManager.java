package com.swordsmp.plugin;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/**
 * Registers the three crafting-table recipes. Per the design spec, every
 * recipe uses ONLY vanilla items — including the weapon's own vanilla base
 * item (Netherite Sword / Mace / Netherite Spear) as one of the three main
 * ingredients — and NO custom items.
 *
 * The crafted "result" ItemStack here is a placeholder/marker item, NOT the
 * final legendary weapon. CraftListener intercepts the player taking this
 * result from the crafting table and redirects it into RitualManager —
 * matching "Weapons are NOT given instantly on craft."
 */
public class RecipeManager {

    private final SwordSMPPlugin plugin;
    private final NamespacedKey ritualTriggerKey;

    public RecipeManager(SwordSMPPlugin plugin) {
        this.plugin = plugin;
        this.ritualTriggerKey = new NamespacedKey(plugin, "ritual_trigger");
    }

    public NamespacedKey ritualTriggerKey() {
        return ritualTriggerKey;
    }

    public void registerAll() {
        registerShadowBlade();
        registerDarkHammer();
        registerSkyHell();
    }

    private ItemStack triggerItem(WeaponType type) {
        // The "result" players see in the crafting grid: a marker item shaped
        // like the weapon's vanilla base item, tagged so CraftListener can
        // recognize it and start the ritual instead of granting it directly.
        ItemStack item = new ItemStack(type.baseItem());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§e§lForge: " + type.displayName());
            meta.getPersistentDataContainer().set(ritualTriggerKey, PersistentDataType.STRING, type.id());
            item.setItemMeta(meta);
        }
        return item;
    }

    public WeaponType identifyTrigger(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        String id = meta.getPersistentDataContainer().get(ritualTriggerKey, PersistentDataType.STRING);
        return id == null ? null : WeaponType.byId(id);
    }

    // Grid layout used by all three recipes: A B A / C D C / A B A
    private void registerShadowBlade() {
        NamespacedKey key = new NamespacedKey(plugin, "shadow_blade_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, triggerItem(WeaponType.SHADOW_BLADE));
        recipe.shape("ABA", "CDC", "ABA");
        recipe.setIngredient('A', Material.WITHER_SKELETON_SKULL);
        recipe.setIngredient('B', Material.ECHO_SHARD);
        recipe.setIngredient('C', Material.NETHERITE_SWORD); // Base Weapon
        recipe.setIngredient('D', Material.NETHER_STAR);
        plugin.getServer().addRecipe(recipe);
    }

    private void registerDarkHammer() {
        NamespacedKey key = new NamespacedKey(plugin, "dark_hammer_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, triggerItem(WeaponType.DARK_HAMMER));
        recipe.shape("ABA", "CDC", "ABA");
        recipe.setIngredient('A', Material.ECHO_SHARD);
        recipe.setIngredient('B', Material.WITHER_ROSE);
        recipe.setIngredient('C', Material.MACE); // Base Weapon
        recipe.setIngredient('D', Material.ENCHANTED_GOLDEN_APPLE);
        plugin.getServer().addRecipe(recipe);
    }

    private void registerSkyHell() {
        NamespacedKey key = new NamespacedKey(plugin, "sky_hell_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, triggerItem(WeaponType.SKY_HELL));
        // Doc grid for Sky Hell is rendered as "A CA / B D B / A C A" but the
        // ingredient ROLES match the same universal pattern (A=x4, B=x2,
        // C=base weapon x1, D=x1) used by the other two recipes.
        recipe.shape("ABA", "CDC", "ABA");
        recipe.setIngredient('A', Material.ENDER_EYE);
        recipe.setIngredient('B', Material.CONDUIT);
        recipe.setIngredient('C', Material.NETHERITE_SPEAR); // Base Weapon
        recipe.setIngredient('D', Material.HEART_OF_THE_SEA);
        plugin.getServer().addRecipe(recipe);
    }
}

package com.swordsmp.plugin;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Main plugin entry point. Responsible only for wiring managers/listeners
 * together and registering them with Bukkit — no game logic lives here.
 */
public class SwordSMPPlugin extends JavaPlugin {

    private Keys keys;
    private WeaponManager weaponManager;
    private CooldownManager cooldownManager;
    private CloneManager cloneManager;
    private FallImmunityManager fallImmunityManager;
    private ArenaManager arenaManager;
    private BossBarManager bossBarManager;
    private RitualManager ritualManager;
    private RecipeManager recipeManager;

    private ShadowBladeListener shadowBladeListener;
    private DarkHammerListener darkHammerListener;
    private SkyHellListener skyHellListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.keys = new Keys(this);
        this.weaponManager = new WeaponManager(this);
        this.cooldownManager = new CooldownManager();
        this.cloneManager = new CloneManager(this);
        this.fallImmunityManager = new FallImmunityManager();
        this.arenaManager = new ArenaManager();
        this.bossBarManager = new BossBarManager();
        this.ritualManager = new RitualManager(this, arenaManager, bossBarManager);
        this.recipeManager = new RecipeManager(this);

        this.shadowBladeListener = new ShadowBladeListener(this);
        this.darkHammerListener = new DarkHammerListener(this);
        this.skyHellListener = new SkyHellListener(this);

        registerListeners();
        recipeManager.registerAll();
        registerCommand();

        getLogger().info("SwordSMP enabled — Shadow Blade / Dark Hammer / Sky Hell ready.");
    }

    @Override
    public void onDisable() {
        getLogger().info("SwordSMP disabled.");
    }

    private void registerListeners() {
        var pm = getServer().getPluginManager();
        pm.registerEvents(new ActivationListener(this), this);
        pm.registerEvents(cloneManager, this);
        pm.registerEvents(fallImmunityManager, this);
        pm.registerEvents(arenaManager, this);
        pm.registerEvents(darkHammerListener, this);
        pm.registerEvents(shadowBladeListener, this);
        pm.registerEvents(new CraftListener(this), this);
        pm.registerEvents(new PlayerDeathListener(this), this);
    }

    private void registerCommand() {
        var command = getCommand("swordsmp");
        if (command != null) {
            command.setExecutor(new SwordSMPCommand(this));
        }
    }

    public FileConfiguration getPluginConfig() {
        return getConfig();
    }

    public Keys getKeys() {
        return keys;
    }

    public WeaponManager getWeaponManager() {
        return weaponManager;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }

    public CloneManager getCloneManager() {
        return cloneManager;
    }

    public FallImmunityManager getFallImmunityManager() {
        return fallImmunityManager;
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }

    public BossBarManager getBossBarManager() {
        return bossBarManager;
    }

    public RitualManager getRitualManager() {
        return ritualManager;
    }

    public RecipeManager getRecipeManager() {
        return recipeManager;
    }

    public ShadowBladeListener getShadowBladeListener() {
        return shadowBladeListener;
    }

    public DarkHammerListener getDarkHammerListener() {
        return darkHammerListener;
    }

    public SkyHellListener getSkyHellListener() {
        return skyHellListener;
    }
}

package com.swordsmp.plugin;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Orchestrates the full ritual flow shared by all three weapons:
 *   1. Player clicks the crafting result (handled by CraftListener calling
 *      RitualManager#startRitual).
 *   2. Weapon is NOT given instantly.
 *   3. 3-second start sequence (lightning/thunder/particles).
 *   4. Bosses spawn inside a 100x100 arena centered on the crafting location.
 *   5. A global boss bar tracks the ritual countdown for all players.
 *   6. If all bosses die before the timer expires -> success, weapon given.
 *   7. If the timer reaches zero first -> failure, weapon NOT given.
 *
 * "Only ONE ritual can be active at a time" is enforced globally.
 * "If crafter dies mid-ritual: ritual CONTINUES" — death does not cancel it.
 */
public class RitualManager {

    private final SwordSMPPlugin plugin;
    private final ArenaManager arenaManager;
    private final BossBarManager bossBarManager;

    private ActiveRitual activeRitual; // null when no ritual running

    public RitualManager(SwordSMPPlugin plugin, ArenaManager arenaManager, BossBarManager bossBarManager) {
        this.plugin = plugin;
        this.arenaManager = arenaManager;
        this.bossBarManager = bossBarManager;
    }

    public boolean isRitualActive() {
        return activeRitual != null;
    }

    public boolean startRitual(Player crafter, WeaponType type, Location craftLocation) {
        if (isRitualActive()) {
            crafter.sendMessage("§cAnother legendary ritual is already in progress. Try again later.");
            return false;
        }

        ActiveRitual ritual = new ActiveRitual(crafter.getUniqueId(), type, craftLocation.clone());
        activeRitual = ritual;

        runStartSequence(craftLocation, () -> beginRitualProper(ritual));
        return true;
    }

    private void runStartSequence(Location loc, Runnable onComplete) {
        var world = loc.getWorld();
        if (world == null) {
            onComplete.run();
            return;
        }

        for (int second = 1; second <= 3; second++) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                world.strikeLightningEffect(loc);
                world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 3f, 1f);
                world.spawnParticle(Particle.FLASH, loc, 3);
                world.spawnParticle(Particle.EXPLOSION, loc, 3);
            }, (second - 1) * 20L);
        }

        plugin.getServer().getScheduler().runTaskLater(plugin, onComplete, 60L);
    }

    private void beginRitualProper(ActiveRitual ritual) {
        WeaponType type = ritual.weaponType;

        long ritualSeconds = switch (type) {
            case SHADOW_BLADE -> plugin.getPluginConfig().getLong("ritual.shadow_blade_seconds", 180);
            case DARK_HAMMER -> plugin.getPluginConfig().getLong("ritual.dark_hammer_seconds", 180);
            case SKY_HELL -> plugin.getPluginConfig().getLong("ritual.sky_hell_seconds", 60);
        };
        int arenaSize = plugin.getPluginConfig().getInt("ritual.arena_size", 100);

        arenaManager.openArena(ritual.craftLocation, arenaSize);

        List<LivingEntity> bosses = spawnBosses(type, ritual.craftLocation, ritual);
        ritual.bossUuids.addAll(bosses.stream().map(LivingEntity::getUniqueId).toList());

        BossBar bossBar = bossBarManager.createRitualBar(
                weaponIcon(type) + " " + displayLabel(type) + " Ritual", BarColor.RED, BarStyle.SOLID);
        ritual.bossBar = bossBar;
        ritual.totalSeconds = ritualSeconds;
        ritual.remainingSeconds = ritualSeconds;

        spawnBossEffects(ritual.craftLocation);

        ritual.tickTask = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> tickRitual(ritual), 0L, 20L);
    }

    private void tickRitual(ActiveRitual ritual) {
        if (ritual.remainingSeconds <= 0) {
            failRitual(ritual);
            return;
        }

        boolean allBossesDead = ritual.bossUuids.stream().allMatch(id -> {
            var entity = plugin.getServer().getEntity(id);
            return entity == null || entity.isDead() || !entity.isValid();
        });

        if (allBossesDead) {
            succeedRitual(ritual);
            return;
        }

        int minutes = (int) (ritual.remainingSeconds / 60);
        int seconds = (int) (ritual.remainingSeconds % 60);
        ritual.bossBar.setTitle(weaponIcon(ritual.weaponType) + " " + displayLabel(ritual.weaponType)
                + " Ritual  •  " + String.format("%02d:%02d", minutes, seconds) + " Remaining");
        ritual.bossBar.setProgress(Math.max(0.0, (double) ritual.remainingSeconds / ritual.totalSeconds));

        ritual.remainingSeconds--;
    }

    private void succeedRitual(ActiveRitual ritual) {
        cleanupRitual(ritual);

        Player crafter = plugin.getServer().getPlayer(ritual.crafterUuid);
        if (crafter != null && crafter.isOnline()) {
            var weapon = plugin.getWeaponManager().createWeapon(ritual.weaponType);
            crafter.getInventory().addItem(weapon);
            crafter.sendMessage("§6⚔ LEGENDARY WEAPON FORGED");
        }

        plugin.getServer().broadcast(net.kyori.adventure.text.Component.text(
                "§6⚔ LEGENDARY WEAPON FORGED §r— " + crafterName(ritual.crafterUuid)
                        + " has forged the " + displayLabel(ritual.weaponType) + "."));
    }

    private void failRitual(ActiveRitual ritual) {
        cleanupRitual(ritual);

        plugin.getServer().broadcast(net.kyori.adventure.text.Component.text(
                "§c⚠ RITUAL FAILED §r— The legendary forging ritual has collapsed."));
    }

    private void cleanupRitual(ActiveRitual ritual) {
        if (ritual.tickTask != null) {
            ritual.tickTask.cancel();
        }
        for (UUID bossId : ritual.bossUuids) {
            var entity = plugin.getServer().getEntity(bossId);
            if (entity != null && !entity.isDead()) {
                entity.remove();
            }
        }
        if (ritual.bossBar != null) {
            bossBarManager.removeBar(ritual.bossBar);
        }
        arenaManager.closeArena();
        activeRitual = null;
    }

    /** Called when a crafter dies mid-ritual — per spec, the ritual CONTINUES. */
    public void onCrafterDeath(UUID crafterUuid) {
        // Intentionally a no-op: ritual continues regardless of crafter death.
    }

    private List<LivingEntity> spawnBosses(WeaponType type, Location center, ActiveRitual ritual) {
        List<LivingEntity> spawned = new ArrayList<>();
        var world = center.getWorld();
        if (world == null) return spawned;

        switch (type) {
            case SHADOW_BLADE -> {
                for (int i = 0; i < 2; i++) {
                    spawned.add((LivingEntity) world.spawnEntity(offset(center, i), EntityType.WARDEN));
                }
            }
            case DARK_HAMMER -> spawned.add((LivingEntity) world.spawnEntity(offset(center, 0), EntityType.WITHER));
            case SKY_HELL -> {
                Player crafter = plugin.getServer().getPlayer(ritual.crafterUuid);
                for (int i = 0; i < 3; i++) {
                    LivingEntity ravager = (LivingEntity) world.spawnEntity(offset(center, i), EntityType.RAVAGER);
                    // "3 spawn ravager angry on player" — aggro toward the crafter on spawn.
                    if (crafter != null && ravager instanceof org.bukkit.entity.Mob mob) {
                        mob.setTarget(crafter);
                    }
                    spawned.add(ravager);
                }
            }
        }
        return spawned;
    }

    private Location offset(Location center, int index) {
        double angle = (2 * Math.PI / 3) * index;
        return center.clone().add(Math.cos(angle) * 5, 0, Math.sin(angle) * 5);
    }

    private void spawnBossEffects(Location loc) {
        var world = loc.getWorld();
        if (world == null) return;
        world.spawnParticle(Particle.EXPLOSION_EMITTER, loc, 5);
        world.spawnParticle(Particle.FLASH, loc, 5);
        world.spawnParticle(Particle.SOUL, loc, 20, 2, 2, 2);
        world.spawnParticle(Particle.DRAGON_BREATH, loc, 20, 2, 2, 2);
        world.spawnParticle(Particle.FLAME, loc, 20, 2, 2, 2);
        world.spawnParticle(Particle.TRIAL_OMEN, loc, 10, 2, 2, 2);
        world.playSound(loc, Sound.ENTITY_WITHER_SPAWN, 3f, 1f);
        world.playSound(loc, Sound.ENTITY_WARDEN_ROAR, 3f, 1f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 3f, 1f);
    }

    private String weaponIcon(WeaponType type) {
        return "⚔";
    }

    private String displayLabel(WeaponType type) {
        return switch (type) {
            case SHADOW_BLADE -> "Shadow Blade";
            case DARK_HAMMER -> "Dark Hammer";
            case SKY_HELL -> "Sky Hell";
        };
    }

    private String crafterName(UUID id) {
        Player p = plugin.getServer().getPlayer(id);
        return p != null ? p.getName() : "Someone";
    }

    /** Mutable state for the single currently-running ritual. */
    private static class ActiveRitual {
        final UUID crafterUuid;
        final WeaponType weaponType;
        final Location craftLocation;
        final List<UUID> bossUuids = new ArrayList<>();

        BossBar bossBar;
        long totalSeconds;
        long remainingSeconds;
        org.bukkit.scheduler.BukkitTask tickTask;

        ActiveRitual(UUID crafterUuid, WeaponType weaponType, Location craftLocation) {
            this.crafterUuid = crafterUuid;
            this.weaponType = weaponType;
            this.craftLocation = craftLocation;
        }
    }
}

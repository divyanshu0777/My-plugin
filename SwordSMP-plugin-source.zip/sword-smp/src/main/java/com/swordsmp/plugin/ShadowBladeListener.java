package com.swordsmp.plugin;

import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

/**
 * Handles activation of Shadow Blade's "Shadow Legion" ability.
 * Triggered exclusively by ActivationListener (Shift + X while holding a
 * Shadow Blade). All normal sword swings bypass this class entirely and
 * behave as plain vanilla Netherite Sword hits.
 */
public class ShadowBladeListener implements Listener {

    private final SwordSMPPlugin plugin;

    public ShadowBladeListener(SwordSMPPlugin plugin) {
        this.plugin = plugin;
    }

    public void activate(Player player) {
        var cooldowns = plugin.getCooldownManager();
        long cooldownSeconds = plugin.getPluginConfig().getLong("cooldowns.shadow_blade_seconds", 35);

        if (cooldowns.isOnCooldown(WeaponType.SHADOW_BLADE, player.getUniqueId())) {
            long remaining = cooldowns.remainingSeconds(WeaponType.SHADOW_BLADE, player.getUniqueId());
            player.sendMessage("§cShadow Legion is on cooldown: " + remaining + "s remaining.");
            return;
        }

        int count = plugin.getPluginConfig().getInt("clones.count", 10);
        double damage = plugin.getPluginConfig().getDouble("clones.damage", 6.0);
        long duration = plugin.getPluginConfig().getLong("clones.duration_seconds", 30);

        plugin.getCloneManager().summonClones(player, count, damage, duration);
        spawnActivationParticles(player);

        cooldowns.startCooldown(WeaponType.SHADOW_BLADE, player.getUniqueId(), cooldownSeconds);
        player.sendMessage("§5§lShadow Legion §rsummoned!");
    }

    private void spawnActivationParticles(Player player) {
        var loc = player.getLocation();
        var world = loc.getWorld();
        if (world == null) return;

        world.spawnParticle(Particle.DRAGON_BREATH, loc, 30, 1, 1, 1);
        world.spawnParticle(Particle.SOUL, loc, 30, 1, 1, 1);
        world.spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 20, 1, 1, 1);
        world.spawnParticle(Particle.LARGE_SMOKE, loc, 20, 1, 1, 1);
        world.spawnParticle(Particle.WITCH, loc, 15, 1, 1, 1);
        world.spawnParticle(Particle.REVERSE_PORTAL, loc, 25, 1, 1, 1);
        world.spawnParticle(Particle.PORTAL, loc, 25, 1, 1, 1);
        world.spawnParticle(Particle.ENCHANT, loc, 20, 1, 1, 1);
    }

    @EventHandler
    public void onOwnerDeath(PlayerDeathEvent event) {
        plugin.getCloneManager().onOwnerDeath(event.getEntity().getUniqueId());
    }
}

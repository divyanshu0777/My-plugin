package com.swordsmp.plugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /swordsmp                       — opens GUI (stub: lists weapons in chat)
 * /swordsmp give <item> <player>  — gives a legendary weapon directly
 * /swordsmp reload                — reloads config.yml
 */
public class SwordSMPCommand implements CommandExecutor {

    private final SwordSMPPlugin plugin;

    public SwordSMPCommand(SwordSMPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            openGui(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "give" -> handleGive(sender, args);
            case "reload" -> handleReload(sender);
            default -> sender.sendMessage("§cUsage: /swordsmp [give <item> <player>|reload]");
        }
        return true;
    }

    private void openGui(CommandSender sender) {
        sender.sendMessage("§6§l=== SwordSMP Legendary Weapons ===");
        for (WeaponType type : WeaponType.values()) {
            sender.sendMessage("§7- " + type.displayName() + " §8(" + type.baseItem() + ")");
        }
    }

    private void handleGive(CommandSender sender, String[] args) {
        if (!sender.hasPermission("swordsmp.give")) {
            sender.sendMessage("§cYou do not have permission to do that.");
            return;
        }
        if (args.length < 3) {
            sender.sendMessage("§cUsage: /swordsmp give <item name> <player>");
            return;
        }

        String itemArg = args[1].toLowerCase().replace(" ", "_");
        WeaponType type = WeaponType.byId(itemArg);
        if (type == null) {
            sender.sendMessage("§cUnknown weapon. Valid options: shadow_blade, dark_hammer, sky_hell");
            return;
        }

        Player target = plugin.getServer().getPlayer(args[2]);
        if (target == null) {
            sender.sendMessage("§cPlayer not found or not online: " + args[2]);
            return;
        }

        target.getInventory().addItem(plugin.getWeaponManager().createWeapon(type));
        sender.sendMessage("§aGave " + type.displayName() + " §ato " + target.getName());
    }

    private void handleReload(CommandSender sender) {
        if (!sender.hasPermission("swordsmp.reload")) {
            sender.sendMessage("§cYou do not have permission to do that.");
            return;
        }
        plugin.reloadConfig();
        sender.sendMessage("§aSwordSMP config reloaded.");
    }
}

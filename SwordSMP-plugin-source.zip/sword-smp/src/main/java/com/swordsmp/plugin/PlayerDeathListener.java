package com.swordsmp.plugin;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

/**
 * Wires player death into the rest of the systems:
 *   - Shadow Legion clones despawn on owner death.
 *   - If the dead player happens to be the current ritual's crafter, per
 *     spec the ritual CONTINUES (RitualManager#onCrafterDeath is a no-op,
 *     documented there for clarity).
 */
public class PlayerDeathListener implements Listener {

    private final SwordSMPPlugin plugin;

    public PlayerDeathListener(SwordSMPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        var playerId = event.getEntity().getUniqueId();
        plugin.getCloneManager().onOwnerDeath(playerId);
        plugin.getRitualManager().onCrafterDeath(playerId);
    }
}

package com.swordsmp.plugin;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Handles Sky Hell's "Fire Prison" ability (Shift + X only).
 * Traps the target in a burning cage for a fixed duration. The owner is
 * immune to their own prison fire damage. Outside of this activation, a Sky
 * Hell behaves as a 100% vanilla Netherite Spear (normal melee + the
 * vanilla spear lunge mechanic both work completely untouched).
 */
public class SkyHellListener {

    private final SwordSMPPlugin plugin;
    private final Set<UUID> ownerImmuneToOwnPrison = new HashSet<>();

    public SkyHellListener(SwordSMPPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isImmuneToOwnPrison(UUID playerId) {
        return ownerImmuneToOwnPrison.contains(playerId);
    }

    public void activate(Player player) {
        var cooldowns = plugin.getCooldownManager();
        long cooldownSeconds = plugin.getPluginConfig().getLong("cooldowns.sky_hell_seconds", 35);

        if (cooldowns.isOnCooldown(WeaponType.SKY_HELL, player.getUniqueId())) {
            long remaining = cooldowns.remainingSeconds(WeaponType.SKY_HELL, player.getUniqueId());
            player.sendMessage("§cFire Prison is on cooldown: " + remaining + "s remaining.");
            return;
        }

        LivingEntity target = findTarget(player, 30);
        if (target == null) {
            player.sendMessage("§7Fire Prison cancelled — no target in sight.");
            return;
        }

        int prisonSize = plugin.getPluginConfig().getInt("sky_hell.prison_size", 10);
        long durationSeconds = plugin.getPluginConfig().getLong("sky_hell.prison_duration_seconds", 30);
        double burnDamagePerSecond = plugin.getPluginConfig().getDouble("sky_hell.burn_damage_per_second", 2.0);

        UUID ownerId = player.getUniqueId();
        ownerImmuneToOwnPrison.add(ownerId);

        spawnWarningParticles(target.getLocation());

        Location center = target.getLocation();
        World world = center.getWorld();

        // Tick-based prison: each second, trap the target in place and apply
        // burn damage, then clean up on expiry.
        final int totalTicks = (int) (durationSeconds * 20L);
        final int[] elapsed = {0};

        plugin.getServer().getScheduler().runTaskTimer(plugin, task -> {
            if (elapsed[0] >= totalTicks || target.isDead() || !target.isValid()) {
                ownerImmuneToOwnPrison.remove(ownerId);
                cooldowns.startCooldown(WeaponType.SKY_HELL, ownerId, cooldownSeconds);
                task.cancel();
                return;
            }

            // Keep target trapped (cannot escape prison): clamp position to cage center.
            if (elapsed[0] % 2 == 0) {
                Location loc = target.getLocation();
                double dx = loc.getX() - center.getX();
                double dz = loc.getZ() - center.getZ();
                double maxRadius = prisonSize / 2.0;
                if (Math.abs(dx) > maxRadius || Math.abs(dz) > maxRadius) {
                    target.teleport(center);
                }
            }

            // Burn damage once per second (every 20 ticks).
            if (elapsed[0] % 20 == 0) {
                target.damage(burnDamagePerSecond, player);
            }

            if (elapsed[0] % 10 == 0) {
                spawnCageParticles(center, prisonSize, world);
            }

            elapsed[0] += 1;
        }, 0L, 1L);

        player.sendMessage("§b§lFire Prison §rcast on " + target.getName() + "!");
    }

    private LivingEntity findTarget(Player player, double range) {
        RayTraceResult result = player.getWorld().rayTraceEntities(
                player.getEyeLocation(),
                player.getEyeLocation().getDirection(),
                range,
                entity -> entity instanceof LivingEntity && entity != player
        );
        if (result == null || result.getHitEntity() == null) {
            return null;
        }
        if (result.getHitEntity() instanceof LivingEntity living) {
            return living;
        }
        return null;
    }

    private void spawnWarningParticles(Location loc) {
        World world = loc.getWorld();
        if (world == null) return;
        world.spawnParticle(Particle.FLASH, loc, 1);
        world.spawnParticle(Particle.EXPLOSION, loc, 1);
    }

    private void spawnCageParticles(Location center, int size, World world) {
        if (world == null) return;
        double half = size / 2.0;
        for (int i = 0; i < 12; i++) {
            double angle = (2 * Math.PI / 12) * i;
            double x = center.getX() + Math.cos(angle) * half;
            double z = center.getZ() + Math.sin(angle) * half;
            for (int y = 0; y <= size; y += 2) {
                Location particleLoc = new Location(world, x, center.getY() + y, z);
                world.spawnParticle(Particle.FLAME, particleLoc, 1, 0, 0, 0, 0.01);
                world.spawnParticle(Particle.LAVA, particleLoc, 1);
            }
        }
        world.spawnParticle(Particle.SMALL_FLAME, center, 10, half, 1, half);
        world.spawnParticle(Particle.WHITE_SMOKE, center, 5, half, 1, half);
    }
}

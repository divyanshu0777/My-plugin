package com.swordsmp.plugin;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.util.Vector;

/**
 * Manages the ritual arena boundary:
 *   - Size: 100x100 blocks, centered on the crafting location.
 *   - Any player can enter.
 *   - No player can leave while the arena is active.
 *   - Bosses cannot leave (left to natural AI pathing + the same push-back
 *     logic could be extended to mobs if desired).
 *   - Border particles render along the boundary.
 *   - Players who try to leave are pushed back toward center with a warning.
 */
public class ArenaManager implements Listener {

    private Location center;
    private double halfSize;
    private boolean active = false;

    public void openArena(Location center, int size) {
        this.center = center.clone();
        this.halfSize = size / 2.0;
        this.active = true;
    }

    public void closeArena() {
        this.active = false;
        this.center = null;
    }

    public boolean isActive() {
        return active;
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (!active || center == null) {
            return;
        }
        Location to = event.getTo();
        if (to == null || to.getWorld() == null || !to.getWorld().equals(center.getWorld())) {
            return;
        }

        double dx = to.getX() - center.getX();
        double dz = to.getZ() - center.getZ();

        boolean outOfBounds = Math.abs(dx) > halfSize || Math.abs(dz) > halfSize;
        if (!outOfBounds) {
            return;
        }

        Player player = event.getPlayer();
        player.sendMessage("§cYou cannot leave the ritual arena!");

        // Push player back toward center.
        Vector direction = center.toVector().subtract(to.toVector()).normalize();
        player.setVelocity(direction.multiply(0.8));

        event.setCancelled(true);
    }

    /** Renders particles along the arena's vertical boundary walls. */
    public void renderBorderParticles() {
        if (!active || center == null) {
            return;
        }
        var world = center.getWorld();
        if (world == null) return;

        int step = 5;
        for (double offset = -halfSize; offset <= halfSize; offset += step) {
            spawnBorderColumn(world, center.getX() + offset, center.getZ() - halfSize);
            spawnBorderColumn(world, center.getX() + offset, center.getZ() + halfSize);
            spawnBorderColumn(world, center.getX() - halfSize, center.getZ() + offset);
            spawnBorderColumn(world, center.getX() + halfSize, center.getZ() + offset);
        }
    }

    private void spawnBorderColumn(org.bukkit.World world, double x, double z) {
        double y = center.getY();
        Location loc = new Location(world, x, y, z);
        world.spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 1, 0, 1, 0);
        world.spawnParticle(Particle.END_ROD, loc, 1, 0, 1, 0);
        world.spawnParticle(Particle.ENCHANT, loc, 1, 0, 1, 0);
        world.spawnParticle(Particle.FLASH, loc, 0);
    }
}

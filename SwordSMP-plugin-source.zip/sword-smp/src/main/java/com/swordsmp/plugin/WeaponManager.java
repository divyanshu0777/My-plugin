package com.swordsmp.plugin;

import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/**
 * Creates and identifies legendary weapon ItemStacks.
 *
 * IMPORTANT: createWeapon() deliberately does NOT touch attack damage,
 * attack speed, durability, enchantments, or any vanilla attribute.
 * The item is the vanilla Material with:
 *   - a display name / lore (cosmetic only)
 *   - CustomModelData (cosmetic only, for the resource pack)
 *   - a PDC tag identifying which legendary weapon it is
 * Nothing here changes combat behavior. Combat behavior changes only
 * happen inside the ability listeners (ShadowBladeListener,
 * DarkHammerListener, SkyHellListener), which check the PDC tag and the
 * activation condition (Shift + X) before doing anything custom.
 */
public class WeaponManager {

    private final SwordSMPPlugin plugin;
    private final Keys keys;

    public WeaponManager(SwordSMPPlugin plugin) {
        this.plugin = plugin;
        this.keys = plugin.getKeys();
    }

    /**
     * Builds a finished legendary weapon ItemStack from its vanilla base item.
     * This is given to the player only after a successful ritual (see
     * RitualManager), never instantly on craft.
     */
    public ItemStack createWeapon(WeaponType type) {
        ItemStack item = new ItemStack(type.baseItem());
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }

        meta.setDisplayName(type.displayName());
        // NOTE: ItemMeta#setCustomModelData(int) is deprecated in 1.21.11 in
        // favor of setCustomModelDataComponent(...), but it is NOT removed
        // and still works exactly as before. Kept here for simplicity since
        // it matches the design doc's flat "CustomModelData: 1001" values.
        meta.setCustomModelData(type.customModelData());

        meta.getPersistentDataContainer().set(keys.weaponId, PersistentDataType.STRING, type.id());

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Returns the WeaponType of this item if it is a legendary weapon,
     * or null if it is a plain vanilla item (or anything else).
     * This is the single source of truth used by every ability listener
     * to decide whether an item should get custom behavior at all.
     */
    public WeaponType identify(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        String id = meta.getPersistentDataContainer().get(keys.weaponId, PersistentDataType.STRING);
        if (id == null) {
            return null;
        }
        return WeaponType.byId(id);
    }

    public boolean isLegendary(ItemStack item) {
        return identify(item) != null;
    }

    public NamespacedKey weaponIdKey() {
        return keys.weaponId;
    }
}

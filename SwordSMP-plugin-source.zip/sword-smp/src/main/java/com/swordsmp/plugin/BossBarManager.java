package com.swordsmp.plugin;

import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;

/**
 * Manages the global ritual boss bar — visible to every online player,
 * showing the weapon name and remaining ritual time.
 */
public class BossBarManager {

    public BossBar createRitualBar(String title, BarColor color, BarStyle style) {
        BossBar bar = Bukkit.createBossBar(title, color, style);
        for (Player player : Bukkit.getOnlinePlayers()) {
            bar.addPlayer(player);
        }
        bar.setVisible(true);
        return bar;
    }

    /** Call this from a PlayerJoinEvent listener so the bar stays visible to everyone. */
    public void addPlayerToActiveBars(Player player, BossBar bar) {
        if (bar != null) {
            bar.addPlayer(player);
        }
    }

    public void removeBar(BossBar bar) {
        if (bar != null) {
            bar.removeAll();
            bar.setVisible(false);
        }
    }
}

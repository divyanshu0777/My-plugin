package com.swordsmp.plugin;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * Tracks per-player, per-weapon ability cooldowns in memory.
 * Cooldowns are NOT persisted across restarts (matches typical
 * "Cooldown : 35 Seconds" style specs that reset on reload/restart).
 */
public class CooldownManager {

    // key: weaponId + ":" + playerUUID -> expiry epoch millis
    private final Map<String, Long> cooldowns = new ConcurrentHashMap<>();

    private String key(WeaponType type, UUID playerId) {
        return type.id() + ":" + playerId;
    }

    public boolean isOnCooldown(WeaponType type, UUID playerId) {
        Long expiry = cooldowns.get(key(type, playerId));
        if (expiry == null) {
            return false;
        }
        if (System.currentTimeMillis() >= expiry) {
            cooldowns.remove(key(type, playerId));
            return false;
        }
        return true;
    }

    public long remainingSeconds(WeaponType type, UUID playerId) {
        Long expiry = cooldowns.get(key(type, playerId));
        if (expiry == null) {
            return 0;
        }
        long remainingMs = expiry - System.currentTimeMillis();
        return Math.max(0, remainingMs / 1000);
    }

    public void startCooldown(WeaponType type, UUID playerId, long seconds) {
        cooldowns.put(key(type, playerId), System.currentTimeMillis() + (seconds * 1000));
    }

    /** Used by Death Drop on success: cooldown resets immediately. */
    public void clearCooldown(WeaponType type, UUID playerId) {
        cooldowns.remove(key(type, playerId));
    }
}

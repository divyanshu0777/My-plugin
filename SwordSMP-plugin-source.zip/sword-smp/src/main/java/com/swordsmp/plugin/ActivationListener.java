package com.swordsmp.plugin;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Detects the "Shift + X" activation combo and routes to the correct ability.
 *
 * On vanilla Java Edition, the default keybind for "Swap Item In Hand" is X.
 * Bukkit/Paper exposes that key press as PlayerSwapHandItemsEvent. We treat
 * "Shift + X" as: the event fires AND the player is currently sneaking.
 *
 * Critically: this listener does nothing at all unless
 *   1) the player is sneaking, AND
 *   2) the item in main hand is identified as a legendary weapon by
 *      WeaponManager#identify (i.e. it has the plugin's PDC tag).
 * A plain vanilla Netherite Sword / Mace / Netherite Spear will never reach
 * the ability logic, and a legendary weapon's normal attacks (this event
 * not firing) are completely untouched — that is what keeps "no ability
 * active" behavior 100% vanilla.
 */
public class ActivationListener implements Listener {

    private final SwordSMPPlugin plugin;

    public ActivationListener(SwordSMPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onSwapHandItems(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();

        if (!player.isSneaking()) {
            return; // not Shift + X, just a normal swap-hands press
        }

        ItemStack mainHand = player.getInventory().getItemInMainHand();
        WeaponType type = plugin.getWeaponManager().identify(mainHand);
        if (type == null) {
            return; // not a legendary weapon — never intercept vanilla swap-hands
        }

        // Cancel the vanilla swap-hands action since we are repurposing this
        // input combo as the ability trigger for legendary weapons only.
        event.setCancelled(true);

        switch (type) {
            case SHADOW_BLADE -> plugin.getShadowBladeListener().activate(player);
            case DARK_HAMMER -> plugin.getDarkHammerListener().activate(player);
            case SKY_HELL -> plugin.getSkyHellListener().activate(player);
        }
    }
}

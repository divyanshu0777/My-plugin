package com.swordsmp.plugin;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

/**
 * Central registry of NamespacedKeys used to tag legendary weapons via the
 * PersistentDataContainer (PDC). These tags are how the plugin tells a
 * legendary weapon apart from a plain vanilla item of the same Material,
 * WITHOUT changing how the item behaves outside of ability activation.
 */
public final class Keys {

    public final NamespacedKey weaponId; // e.g. "shadow_blade" / "dark_hammer" / "sky_hell"

    public Keys(Plugin plugin) {
        this.weaponId = new NamespacedKey(plugin, "weapon_id");
    }
}

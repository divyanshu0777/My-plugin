package com.swordsmp.plugin;

import org.bukkit.Material;

/**
 * The three legendary weapons. Each one wraps a 100% vanilla base Material.
 * Outside of ability activation (Shift + Swap-hands, see ActivationListener),
 * the item IS that vanilla item — same damage, same durability, same attack
 * speed, same everything. The only things that make it "legendary" are:
 *   1. A PDC tag (Keys.weaponId) identifying it for plugin logic.
 *   2. A CustomModelData value for the resource pack to re-texture it.
 *   3. The ability triggered on Shift + X.
 *   4. (Dark Hammer only) a flat bonus to charged smash-attack damage.
 */
public enum WeaponType {

    SHADOW_BLADE(
            "shadow_blade",
            "§5§lShadow blade",
            Material.NETHERITE_SWORD,
            1001
    ),
    DARK_HAMMER(
            "dark_hammer",
            "§4§lDark Hammer",
            Material.MACE,
            1002
    ),
    SKY_HELL(
            "sky_hell",
            "§b§lSky Hell",
            Material.NETHERITE_SPEAR,
            1003
    );

    private final String id;
    private final String displayName;
    private final Material baseItem;
    private final int customModelData;

    WeaponType(String id, String displayName, Material baseItem, int customModelData) {
        this.id = id;
        this.displayName = displayName;
        this.baseItem = baseItem;
        this.customModelData = customModelData;
    }

    public String id() {
        return id;
    }

    public String displayName() {
        return displayName;
    }

    public Material baseItem() {
        return baseItem;
    }

    public int customModelData() {
        return customModelData;
    }

    public static WeaponType byId(String id) {
        for (WeaponType type : values()) {
            if (type.id.equalsIgnoreCase(id)) {
                return type;
            }
        }
        return null;
    }
}

package com.swordsmp.plugin;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Grants the Dark Hammer owner full fall-damage immunity while a Death Drop
 * is in progress ("Owner Effects: Full fall damage immunity").
 */
public class FallImmunityManager implements Listener {

    private final Set<UUID> immune = ConcurrentHashMap.newKeySet();

    public void grant(UUID playerId) {
        immune.add(playerId);
    }

    public void revoke(UUID playerId) {
        immune.remove(playerId);
    }

    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) {
            return;
        }
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        if (immune.contains(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }
}

package com.swordsmp.plugin;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Intercepts the player taking the legendary weapon "trigger" item out of
 * the crafting table result slot. Instead of letting them receive that
 * item, we cancel the craft, consume nothing extra (Bukkit already consumed
 * the ingredients when the craft fired), and start the ritual via
 * RitualManager. The actual weapon is only granted later, on ritual success.
 */
public class CraftListener implements Listener {

    private final SwordSMPPlugin plugin;

    public CraftListener(SwordSMPPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onCraft(CraftItemEvent event) {
        ItemStack result = event.getInventory().getResult();
        WeaponType type = plugin.getRecipeManager().identifyTrigger(result);
        if (type == null) {
            return; // not one of our ritual recipes
        }

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        if (plugin.getRitualManager().isRitualActive()) {
            player.sendMessage("§cAnother legendary ritual is already in progress. Try again later.");
            event.setCancelled(true);
            return;
        }

        // Cancel taking the trigger item — the player gets nothing right now.
        event.setCancelled(true);

        boolean started = plugin.getRitualManager().startRitual(player, type, player.getLocation());
        if (started) {
            // Now that the ritual has accepted the craft, consume the
            // ingredients from the crafting grid for real.
            event.getInventory().setMatrix(new ItemStack[event.getInventory().getMatrix().length]);
            player.updateInventory();
        }
    }
}

package com.swordsmp.plugin;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/**
 * Handles Dark Hammer's two distinct behaviors:
 *
 * 1) CHARGED HIT BONUS (always active, no activation needed):
 *    Vanilla Mace already deals bonus "smash attack" damage when the player
 *    falls/glides into a hit (EntityDamageEvent cause SMASH_DAMAGE on 1.21+).
 *    We add a flat +10 damage (5 hearts) ON TOP of whatever vanilla smash
 *    damage already applied — we never replace or reduce the vanilla value.
 *    Every other hit (a plain, non-charged mace swing) is left completely
 *    untouched and behaves exactly like a vanilla Mace.
 *
 * 2) "Death Drop" ABILITY (Shift + X only):
 *    Locks onto whoever the player is looking at within range, teleports the
 *    player above them, and drops them onto the target. Success = instant
 *    kill + cooldown reset. Failure (timeout / target lost) = cooldown
 *    starts normally. The owner is immune to their own fall damage during
 *    this sequence.
 */
public class DarkHammerListener implements Listener {

    private final SwordSMPPlugin plugin;

    public DarkHammerListener(SwordSMPPlugin plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // 1) Charged hit bonus damage — applies on every relevant hit,
    //    ability or not, exactly like a vanilla smash attack bonus.
    // ---------------------------------------------------------------
    @EventHandler
    public void onDarkHammerHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player attacker)) {
            return;
        }

        var mainHand = attacker.getInventory().getItemInMainHand();
        WeaponType type = plugin.getWeaponManager().identify(mainHand);
        if (type != WeaponType.DARK_HAMMER) {
            return; // not a Dark Hammer at all — leave completely vanilla
        }

        // Only EntityDamageEvent.DamageCause.ENTITY_ATTACK covers melee hits
        // (there is no dedicated DamageCause for the Mace's smash attack as
        // of 1.21.11 — vanilla folds the smash bonus into the same
        // ENTITY_ATTACK damage value before this event fires).
        if (event.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            return;
        }

        boolean isChargedSmash = isSmashAttack(attacker);
        if (!isChargedSmash) {
            return; // a plain mace swing — leave completely vanilla
        }

        double bonus = plugin.getPluginConfig().getDouble("dark_hammer.charged_hit_bonus_damage", 10.0);
        // Add on top of whatever vanilla already calculated — never replace it.
        event.setDamage(event.getDamage() + bonus);
    }

    /**
     * Detects whether the attacker is performing a vanilla Mace "smash
     * attack" — triggered by falling (or gliding/riding down) before
     * landing a hit. Vanilla's own smash-attack check is "the player has
     * fallen more than ~1.5 blocks and has not yet touched the ground at
     * the moment of the hit." We approximate that with the public API via
     * fallDistance + isOnGround, which covers the same window. This only
     * GATES the bonus — it never overrides or reduces the damage vanilla
     * itself already applied.
     */
    private boolean isSmashAttack(Player attacker) {
        return attacker.getFallDistance() > 1.5f && !attacker.isOnGround();
    }

    // ---------------------------------------------------------------
    // 2) Death Drop ability
    // ---------------------------------------------------------------
    public void activate(Player player) {
        var cooldowns = plugin.getCooldownManager();
        long cooldownSeconds = plugin.getPluginConfig().getLong("cooldowns.dark_hammer_seconds", 35);

        if (cooldowns.isOnCooldown(WeaponType.DARK_HAMMER, player.getUniqueId())) {
            long remaining = cooldowns.remainingSeconds(WeaponType.DARK_HAMMER, player.getUniqueId());
            player.sendMessage("§cDeath Drop is on cooldown: " + remaining + "s remaining.");
            return;
        }

        double range = plugin.getPluginConfig().getDouble("dark_hammer.lock_on_range", 30);
        LivingEntity target = findTarget(player, range);

        if (target == null) {
            // "If no player in sight: ability cancels, no cooldown"
            player.sendMessage("§7Death Drop cancelled — no target in sight.");
            return;
        }

        // Mark owner immune to their own fall damage for the duration of the drop.
        plugin.getFallImmunityManager().grant(player.getUniqueId());

        Location above = target.getLocation().clone().add(0, 15, 0);
        above.setWorld(target.getWorld());
        player.teleport(above);

        spawnLockOnParticles(target.getLocation());

        // Give the player a brief moment of hover, then launch them down onto
        // the target. We nudge their velocity downward; gravity does the rest.
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            player.setVelocity(new Vector(0, -3.5, 0));
        }, 5L);

        // Resolve success/failure shortly after the fall window.
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getFallImmunityManager().revoke(player.getUniqueId());

            if (!player.isOnline() || target.isDead() || !target.isValid()) {
                cooldowns.startCooldown(WeaponType.DARK_HAMMER, player.getUniqueId(), cooldownSeconds);
                return;
            }

            double distance = player.getLocation().distance(target.getLocation());
            if (distance <= 3.0) {
                // Success: instant kill + cooldown resets immediately.
                target.setHealth(0.0);
                spawnImpactParticles(player.getLocation());
                cooldowns.clearCooldown(WeaponType.DARK_HAMMER, player.getUniqueId());
                player.sendMessage("§4§lDeath Drop §rsuccessful!");
            } else {
                // Failure: cooldown starts normally.
                cooldowns.startCooldown(WeaponType.DARK_HAMMER, player.getUniqueId(), cooldownSeconds);
                player.sendMessage("§7Death Drop missed.");
            }
        }, 40L); // ~2 seconds after launch
    }

    private LivingEntity findTarget(Player player, double range) {
        RayTraceResult result = player.getWorld().rayTraceEntities(
                player.getEyeLocation(),
                player.getEyeLocation().getDirection(),
                range,
                entity -> entity instanceof LivingEntity && entity != player
        );
        if (result == null || result.getHitEntity() == null) {
            return null;
        }
        if (result.getHitEntity() instanceof LivingEntity living) {
            return living;
        }
        return null;
    }

    private void spawnLockOnParticles(Location loc) {
        var world = loc.getWorld();
        if (world == null) return;
        world.spawnParticle(Particle.SONIC_BOOM, loc, 1);
        world.spawnParticle(Particle.PORTAL, loc, 20, 0.5, 1, 0.5);
        world.spawnParticle(Particle.REVERSE_PORTAL, loc, 20, 0.5, 1, 0.5);
        world.spawnParticle(Particle.FLASH, loc, 1);
    }

    private void spawnImpactParticles(Location loc) {
        var world = loc.getWorld();
        if (world == null) return;
        world.spawnParticle(Particle.CRIT, loc, 30, 1, 1, 1);
        world.spawnParticle(Particle.ENCHANT, loc, 20, 1, 1, 1);
        world.spawnParticle(Particle.DUST_PLUME, loc, 30, 1, 0.5, 1);
    }
}

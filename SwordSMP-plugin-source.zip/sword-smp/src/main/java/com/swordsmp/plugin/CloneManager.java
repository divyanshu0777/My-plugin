package com.swordsmp.plugin;

import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Implements Shadow Blade's "Shadow Legion" ability:
 *   - Summons N clones (Zombies re-skinned via a marker PDC tag + tuned
 *     vanilla AI repurposed as simple melee attackers).
 *   - Clones auto-attack nearby enemies.
 *   - Clones never attack / cannot damage the owner.
 *   - Clones are effectively unkillable until the ability ends (handled via
 *     an EntityDamageEvent cancel while the marker tag is present).
 *   - Clones despawn on owner death or logout.
 *
 * Implementation note: real "invisible decoy clone" visuals (player skin
 * clones) require either packet manipulation (ProtocolLib) or a NPC library
 * (Citizens). To keep this plugin dependency-free and 1.21.11-safe, clones
 * are modeled as Zombies with AI tuned for pure melee aggression, silenced
 * sounds, and made ageless/silent. Swap to a player-skin NPC library here if
 * you want a true 1:1 player look.
 */
public class CloneManager implements Listener {

    private final SwordSMPPlugin plugin;
    private final NamespacedKey cloneOwnerKey;
    private final NamespacedKey cloneMarkerKey;

    // owner UUID -> set of clone entity UUIDs currently alive for that ability use
    private final Map<UUID, Set<UUID>> activeClones = new HashMap<>();
    private final Map<UUID, BukkitTask> expiryTasks = new HashMap<>();

    public CloneManager(SwordSMPPlugin plugin) {
        this.plugin = plugin;
        this.cloneOwnerKey = new NamespacedKey(plugin, "clone_owner");
        this.cloneMarkerKey = new NamespacedKey(plugin, "shadow_clone");
    }

    public void summonClones(Player owner, int count, double damage, long durationSeconds) {
        Set<UUID> clones = new HashSet<>();
        Location base = owner.getLocation();

        for (int i = 0; i < count; i++) {
            double angle = (2 * Math.PI / count) * i;
            double x = base.getX() + Math.cos(angle) * 2.0;
            double z = base.getZ() + Math.sin(angle) * 2.0;
            Location spawnLoc = new Location(base.getWorld(), x, base.getY(), z, base.getYaw(), 0f);

            Zombie clone = base.getWorld().spawn(spawnLoc, Zombie.class, z2 -> {
                z2.setBaby(false);
                z2.setSilent(true);
                z2.setRemoveWhenFarAway(false);
                z2.setCanPickupItems(false);
                z2.setCustomNameVisible(false);
                z2.setShouldBurnInDay(false);
                z2.getPersistentDataContainer().set(cloneMarkerKey, PersistentDataType.BYTE, (byte) 1);
                z2.getPersistentDataContainer().set(cloneOwnerKey, PersistentDataType.STRING, owner.getUniqueId().toString());

                var attackAttr = z2.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
                if (attackAttr != null) {
                    attackAttr.setBaseValue(damage);
                }
                var maxHealthAttr = z2.getAttribute(Attribute.GENERIC_MAX_HEALTH);
                if (maxHealthAttr != null) {
                    maxHealthAttr.setBaseValue(20.0);
                }
                z2.setHealth(20.0);
            });

            clones.add(clone.getUniqueId());
        }

        activeClones.put(owner.getUniqueId(), clones);

        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> despawnClones(owner.getUniqueId()),
                durationSeconds * 20L);
        expiryTasks.put(owner.getUniqueId(), task);
    }

    public void despawnClones(UUID ownerId) {
        Set<UUID> clones = activeClones.remove(ownerId);
        if (clones != null) {
            for (UUID cloneId : clones) {
                var entity = plugin.getServer().getEntity(cloneId);
                if (entity != null) {
                    entity.remove();
                }
            }
        }
        BukkitTask task = expiryTasks.remove(ownerId);
        if (task != null) {
            task.cancel();
        }
    }

    private boolean isClone(org.bukkit.entity.Entity entity) {
        return entity.getPersistentDataContainer().has(cloneMarkerKey, PersistentDataType.BYTE);
    }

    private UUID cloneOwner(org.bukkit.entity.Entity entity) {
        String raw = entity.getPersistentDataContainer().get(cloneOwnerKey, PersistentDataType.STRING);
        return raw == null ? null : UUID.fromString(raw);
    }

    /** Clones cannot die until the ability ends. */
    @EventHandler
    public void onCloneDamaged(EntityDamageEvent event) {
        if (isClone(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    /** Clones never attack their owner / cannot damage their owner. */
    @EventHandler
    public void onCloneAttacks(EntityDamageByEntityEvent event) {
        if (!isClone(event.getDamager())) {
            return;
        }
        if (event.getEntity() instanceof Player victim) {
            UUID owner = cloneOwner(event.getDamager());
            if (owner != null && owner.equals(victim.getUniqueId())) {
                event.setCancelled(true);
            }
        }
    }

    /** Clones should never target their own owner. */
    @EventHandler
    public void onCloneTarget(EntityTargetEvent event) {
        if (!isClone(event.getEntity())) {
            return;
        }
        if (event.getTarget() instanceof Player target) {
            UUID owner = cloneOwner(event.getEntity());
            if (owner != null && owner.equals(target.getUniqueId())) {
                event.setCancelled(true);
            }
        }
    }

    /** Clones despawn on owner logout. */
    @EventHandler
    public void onOwnerQuit(PlayerQuitEvent event) {
        despawnClones(event.getPlayer().getUniqueId());
    }

    /** Clones despawn on owner death. Call this from a death listener as well. */
    public void onOwnerDeath(UUID ownerId) {
        despawnClones(ownerId);
    }
}

package com.swordsmp.plugin;

import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.wrappers.EnumWrappers;
import com.comphenix.protocol.wrappers.WrappedChatComponent;
import com.comphenix.protocol.wrappers.WrappedGameProfile;
import com.comphenix.protocol.wrappers.PlayerInfoData;

import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Implements Shadow Blade's "Shadow Legion" ability:
 *   - Summons N clones that LOOK like the owner (real player skin, fetched
 *     straight from the owner's cloud/Mojang game profile) using ProtocolLib
 *     fake-player packets layered on top of an invisible Zombie "body".
 *   - The Zombie body still drives the actual gameplay: melee AI, attack
 *     damage, health, targeting rules. ProtocolLib is purely cosmetic — it
 *     spawns a packet-only fake player at the same location and keeps it
 *     synced to the zombie every tick so it looks like a real player-skin
 *     clone walking/fighting around.
 *   - Clones never attack / cannot damage the owner.
 *   - Clones are effectively unkillable until the ability ends (handled via
 *     an EntityDamageEvent cancel while the marker tag is present).
 *   - Clones despawn on owner death or logout.
 *
 * Requires the ProtocolLib plugin to be installed on the server (declared as
 * a softdepend in plugin.yml). If ProtocolLib isn't present, clones silently
 * fall back to plain (visible) zombies so the ability still works.
 */
public class CloneManager implements Listener {

    private final SwordSMPPlugin plugin;
    private final NamespacedKey cloneOwnerKey;
    private final NamespacedKey cloneMarkerKey;
    private final boolean protocolLibAvailable;
    private final ProtocolManager protocolManager;

    // owner UUID -> set of clone entity UUIDs (zombie bodies) currently alive
    private final Map<UUID, Set<UUID>> activeClones = new HashMap<>();
    private final Map<UUID, BukkitTask> expiryTasks = new HashMap<>();

    // zombie body UUID -> fake-player packet clone data (only populated when ProtocolLib is present)
    private final Map<UUID, FakePlayerClone> fakePlayers = new HashMap<>();
    private BukkitTask syncTask;
    private int fakeEntityIdCounter = -2_000_000_000;

    public CloneManager(SwordSMPPlugin plugin) {
        this.plugin = plugin;
        this.cloneOwnerKey = new NamespacedKey(plugin, "clone_owner");
        this.cloneMarkerKey = new NamespacedKey(plugin, "shadow_clone");
        this.protocolLibAvailable = plugin.getServer().getPluginManager().getPlugin("ProtocolLib") != null;
        this.protocolManager = protocolLibAvailable ? ProtocolLibrary.getProtocolManager() : null;
    }

    public void summonClones(Player owner, int count, double damage, long durationSeconds) {
        Set<UUID> clones = new HashSet<>();
        Location base = owner.getLocation();

        for (int i = 0; i < count; i++) {
            double angle = (2 * Math.PI / count) * i;
            double x = base.getX() + Math.cos(angle) * 2.0;
            double z = base.getZ() + Math.sin(angle) * 2.0;
            Location spawnLoc = new Location(base.getWorld(), x, base.getY(), z, base.getYaw(), 0f);

            Zombie clone = base.getWorld().spawn(spawnLoc, Zombie.class, z2 -> {
                z2.setBaby(false);
                z2.setSilent(true);
                z2.setRemoveWhenFarAway(false);
                z2.setCanPickupItems(false);
                z2.setCustomNameVisible(false);
                z2.setShouldBurnInDay(false);
                z2.getPersistentDataContainer().set(cloneMarkerKey, PersistentDataType.BYTE, (byte) 1);
                z2.getPersistentDataContainer().set(cloneOwnerKey, PersistentDataType.STRING, owner.getUniqueId().toString());

                var attackAttr = z2.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
                if (attackAttr != null) {
                    attackAttr.setBaseValue(damage);
                }
                var maxHealthAttr = z2.getAttribute(Attribute.GENERIC_MAX_HEALTH);
                if (maxHealthAttr != null) {
                    maxHealthAttr.setBaseValue(20.0);
                }
                z2.setHealth(20.0);

                // The zombie body itself is invisible whenever ProtocolLib is
                // present; the visible part of the clone is then the
                // packet-only fake player skinned as the owner (spawned
                // right below). Without ProtocolLib the zombie stays visible
                // as a fallback.
                z2.setInvisible(protocolLibAvailable);
            });

            clones.add(clone.getUniqueId());

            if (protocolLibAvailable) {
                spawnFakePlayerClone(owner, clone);
            }
        }

        activeClones.put(owner.getUniqueId(), clones);

        if (protocolLibAvailable && syncTask == null) {
            startSyncTask();
        }

        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> despawnClones(owner.getUniqueId()),
                durationSeconds * 20L);
        expiryTasks.put(owner.getUniqueId(), task);
    }

    // ---------------------------------------------------------------
    // ProtocolLib fake-player rendering
    // ---------------------------------------------------------------

    private static final class FakePlayerClone {
        final WrappedGameProfile profile;
        final int entityId;

        FakePlayerClone(WrappedGameProfile profile, int entityId) {
            this.profile = profile;
            this.entityId = entityId;
        }
    }

    /**
     * Builds a fake GameProfile that reuses the owner's real skin (the
     * "textures" property on their profile, fetched from Mojang's session
     * servers / the cloud when they joined) but with a fresh random UUID and
     * name so it renders as a distinct entity rather than the real player.
     */
    private WrappedGameProfile buildCloneProfile(Player owner) {
        WrappedGameProfile ownerProfile = WrappedGameProfile.fromPlayer(owner);
        UUID fakeId = UUID.randomUUID();
        String fakeName = "clone_" + Integer.toHexString(fakeId.hashCode());
        if (fakeName.length() > 16) {
            fakeName = fakeName.substring(0, 16);
        }
        WrappedGameProfile cloneProfile = new WrappedGameProfile(fakeId, fakeName);
        // Copy every property (most importantly "textures", which is the
        // owner's actual skin/cape as served by Mojang's session servers, i.e.
        // fetched from the cloud) straight onto the clone's profile.
        ownerProfile.getProperties().asMap().forEach((key, values) ->
                values.forEach(value -> cloneProfile.getProperties().put(key, value)));
        return cloneProfile;
    }

    private void spawnFakePlayerClone(Player owner, Zombie body) {
        try {
            WrappedGameProfile profile = buildCloneProfile(owner);
            int entityId = generateFakeEntityId();

            // 1. Announce the fake player via PLAYER_INFO so clients resolve
            //    its skin from the cloud-sourced texture property attached above.
            PacketContainer playerInfo = protocolManager.createPacket(PacketType.Play.Server.PLAYER_INFO);
            playerInfo.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.ADD_PLAYER);
            PlayerInfoData infoData = new PlayerInfoData(
                    profile, 0, EnumWrappers.NativeGameMode.SURVIVAL, WrappedChatComponent.fromText(profile.getName()));
            playerInfo.getPlayerInfoDataLists().write(1, Collections.singletonList(infoData));

            // 2. Spawn the named entity at the body's current location.
            Location loc = body.getLocation();
            PacketContainer spawn = protocolManager.createPacket(PacketType.Play.Server.NAMED_ENTITY_SPAWN);
            spawn.getIntegers().write(0, entityId);
            spawn.getUUIDs().write(0, profile.getUUID());
            spawn.getDoubles().write(0, loc.getX());
            spawn.getDoubles().write(1, loc.getY());
            spawn.getDoubles().write(2, loc.getZ());
            spawn.getBytes().write(0, (byte) (loc.getYaw() * 256.0F / 360.0F));
            spawn.getBytes().write(1, (byte) (loc.getPitch() * 256.0F / 360.0F));

            for (Player viewer : plugin.getServer().getOnlinePlayers()) {
                protocolManager.sendServerPacket(viewer, playerInfo);
                protocolManager.sendServerPacket(viewer, spawn);
            }

            // 3. The PLAYER_INFO "add" entry is only needed long enough for
            //    clients to cache the skin; remove it shortly after so it
            //    doesn't clutter the tab list.
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                PacketContainer remove = protocolManager.createPacket(PacketType.Play.Server.PLAYER_INFO_REMOVE);
                remove.getUUIDLists().write(0, Collections.singletonList(profile.getUUID()));
                for (Player viewer : plugin.getServer().getOnlinePlayers()) {
                    protocolManager.sendServerPacket(viewer, remove);
                }
            }, 40L);

            fakePlayers.put(body.getUniqueId(), new FakePlayerClone(profile, entityId));
        } catch (Exception ex) {
            plugin.getLogger().warning("Failed to render ProtocolLib player-skin clone, falling back to plain zombie: " + ex.getMessage());
            body.setInvisible(false);
        }
    }

    private int generateFakeEntityId() {
        return fakeEntityIdCounter++;
    }

    /** Keeps every fake-player overlay glued to its zombie body's position/rotation. */
    private void startSyncTask() {
        syncTask = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (fakePlayers.isEmpty()) {
                return;
            }
            for (Map.Entry<UUID, FakePlayerClone> entry : new HashMap<>(fakePlayers).entrySet()) {
                var entity = plugin.getServer().getEntity(entry.getKey());
                if (!(entity instanceof Zombie body) || body.isDead()) {
                    continue;
                }
                Location loc = body.getLocation();
                FakePlayerClone fake = entry.getValue();

                PacketContainer teleport = protocolManager.createPacket(PacketType.Play.Server.ENTITY_TELEPORT);
                teleport.getIntegers().write(0, fake.entityId);
                teleport.getDoubles().write(0, loc.getX());
                teleport.getDoubles().write(1, loc.getY());
                teleport.getDoubles().write(2, loc.getZ());
                teleport.getBytes().write(0, (byte) (loc.getYaw() * 256.0F / 360.0F));
                teleport.getBytes().write(1, (byte) (loc.getPitch() * 256.0F / 360.0F));

                PacketContainer headRotation = protocolManager.createPacket(PacketType.Play.Server.ENTITY_HEAD_ROTATION);
                headRotation.getIntegers().write(0, fake.entityId);
                headRotation.getBytes().write(0, (byte) (loc.getYaw() * 256.0F / 360.0F));

                for (Player viewer : plugin.getServer().getOnlinePlayers()) {
                    protocolManager.sendServerPacket(viewer, teleport);
                    protocolManager.sendServerPacket(viewer, headRotation);
                }
            }
        }, 1L, 1L);
    }

    private void removeFakePlayerClone(UUID bodyId) {
        FakePlayerClone fake = fakePlayers.remove(bodyId);
        if (fake == null || protocolManager == null) {
            return;
        }
        PacketContainer destroy = protocolManager.createPacket(PacketType.Play.Server.ENTITY_DESTROY);
        destroy.getIntLists().write(0, Collections.singletonList(fake.entityId));

        PacketContainer removeInfo = protocolManager.createPacket(PacketType.Play.Server.PLAYER_INFO_REMOVE);
        removeInfo.getUUIDLists().write(0, Collections.singletonList(fake.profile.getUUID()));

        for (Player viewer : plugin.getServer().getOnlinePlayers()) {
            protocolManager.sendServerPacket(viewer, destroy);
            protocolManager.sendServerPacket(viewer, removeInfo);
        }
    }

    // ---------------------------------------------------------------
    // Lifecycle / combat rules (unchanged behaviour)
    // ---------------------------------------------------------------

    public void despawnClones(UUID ownerId) {
        Set<UUID> clones = activeClones.remove(ownerId);
        if (clones != null) {
            for (UUID cloneId : clones) {
                removeFakePlayerClone(cloneId);
                var entity = plugin.getServer().getEntity(cloneId);
                if (entity != null) {
                    entity.remove();
                }
            }
        }
        BukkitTask task = expiryTasks.remove(ownerId);
        if (task != null) {
            task.cancel();
        }
        if (fakePlayers.isEmpty() && syncTask != null) {
            syncTask.cancel();
            syncTask = null;
        }
    }

    private boolean isClone(org.bukkit.entity.Entity entity) {
        return entity.getPersistentDataContainer().has(cloneMarkerKey, PersistentDataType.BYTE);
    }

    private UUID cloneOwner(org.bukkit.entity.Entity entity) {
        String raw = entity.getPersistentDataContainer().get(cloneOwnerKey, PersistentDataType.STRING);
        return raw == null ? null : UUID.fromString(raw);
    }

    /** Clones cannot die until the ability ends. */
    @EventHandler
    public void onCloneDamaged(EntityDamageEvent event) {
        if (isClone(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    /** Clones never attack their owner / cannot damage their owner. */
    @EventHandler
    public void onCloneAttacks(EntityDamageByEntityEvent event) {
        if (!isClone(event.getDamager())) {
            return;
        }
        if (event.getEntity() instanceof Player victim) {
            UUID owner = cloneOwner(event.getDamager());
            if (owner != null && owner.equals(victim.getUniqueId())) {
                event.setCancelled(true);
            }
        }
    }

    /** Clones should never target their own owner. */
    @EventHandler
    public void onCloneTarget(EntityTargetEvent event) {
        if (!isClone(event.getEntity())) {
            return;
        }
        if (event.getTarget() instanceof Player target) {
            UUID owner = cloneOwner(event.getEntity());
            if (owner != null && owner.equals(target.getUniqueId())) {
                event.setCancelled(true);
            }
        }
    }

    /** Clones despawn on owner logout. */
    @EventHandler
    public void onOwnerQuit(PlayerQuitEvent event) {
        despawnClones(event.getPlayer().getUniqueId());
    }

    /** Clones despawn on owner death. Call this from a death listener as well. */
    public void onOwnerDeath(UUID ownerId) {
        despawnClones(ownerId);
    }
}

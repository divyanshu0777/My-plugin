# SwordSMP — Legendary Weapon Ritual Plugin (Paper 1.21.11)

Implements three legendary weapons crafted via vanilla-only recipes + a
boss-ritual system, per the SwordSMP design spec:

- **Shadow Blade** (base: Netherite Sword) — "Shadow Legion" ability
- **Dark Hammer** (base: Mace) — "Death Drop" ability + always-on +10
  bonus damage on charged smash hits
- **Sky Hell** (base: Netherite Spear, new in 1.21.11) — "Fire Prison" ability

Outside of ability activation (**Shift + X**, i.e. Shift + swap-hand-items),
every legendary weapon behaves as a 100% vanilla version of its base item —
same damage, same durability, same everything. No custom item types exist
anywhere in this plugin; legendary weapons are vanilla ItemStacks tagged
with a PersistentDataContainer key plus CustomModelData for re-texturing.

## Building

Requires Java 21 and Maven, with network access to PaperMC's repository.

```bash
cd sword-smp
mvn clean package
```

Output jar: `target/SwordSMP-1.0.0.jar`. Drop it into your server's `plugins/`
folder.

**IMPORTANT — I could not run this build myself.** My sandbox has no
network access to Maven Central / repo.papermc.io and no local copy of the
Paper API jar, so this project has never actually been compiled. I read
through the PaperMC 1.21.11 javadocs to verify the specific API calls used
(method signatures, enum constant names, etc. — see "API verification
notes" below) and fixed two real mistakes I found that way, but that is not
a substitute for a real `mvn package` run. **Please build it yourself and
read the compiler output before trusting it on a live server.** If
`pom.xml`'s pinned `1.21.11-R0.1-SNAPSHOT` isn't resolvable from your Paper
repo mirror, bump it to whatever 1.21.x version your repo has cached —
nothing else in the code depends on a version-specific internal.

## What's implemented

- **Recipes**: all three use a 3x3 shaped grid (`A B A / C D C / A B A`)
  with only vanilla items — the weapon's own vanilla base item sits in
  slot C. No custom items required.
- **Ritual system**: clicking the recipe result doesn't give the weapon —
  it starts a 3-second lightning/thunder sequence, then spawns the
  bosses (2x Warden / 1x Wither / 3x Ravager) inside a 100x100 arena with
  a global boss bar countdown. Kill all bosses before the timer runs out
  to get the weapon; otherwise the ritual fails and nothing is granted.
  Only one ritual can run at a time, server-wide. A crafter's death does
  NOT cancel their ritual.
- **Shadow Legion**: summons 10 temporary allies (modeled as tuned
  Zombies — see note below) that fight nearby enemies, can't hurt or
  target the owner, and can't die until the ability ends.
- **Death Drop**: locks onto whoever you're looking at within 30 blocks,
  yanks you above them, drops you onto them. Hit = instant kill + instant
  cooldown reset. Miss/no-target = no penalty or normal cooldown,
  matching the spec.
- **Dark Hammer charged-hit bonus**: detected via fall distance (vanilla
  has no dedicated "smash attack" DamageCause — see notes below), adds
  +10 on top of whatever vanilla already calculated. Every plain mace
  swing is untouched.
- **Fire Prison**: traps the look-at target in a shrinking-escape-proof
  cage for 30s, burns them for 2/s, owner takes no self-burn damage.
- **/swordsmp give|reload** commands, permissions, and a `config.yml` with
  every tunable number from the spec (cooldowns, ritual durations, clone
  stats, bonus damage, etc).

## Known simplifications / things to double check on your server

1. **Shadow clones are vanilla Zombies, not player-look-alikes.** A true
   "looks like the player" decoy needs either ProtocolLib or an NPC
   library like Citizens — neither is in this build, to keep it
   dependency-free. The clones fight, can't be killed early, and can't
   hurt the owner, but they look like zombies. Swap `CloneManager` to spawn
   NPCs from your library of choice if you want the visual to match.

2. **Dark Hammer's "charged hit" detection uses fall distance, not a
   dedicated event.** I initially wrote this against an
   `EntityDamageEvent.DamageCause.MACE_SMASH` constant — I checked the
   actual 1.21.11 javadocs afterward and that constant doesn't exist, so
   I rewrote it to check `player.getFallDistance() > 1.5 && !isOnGround()`
   at hit time instead, which is functionally the same gate vanilla itself
   uses. This is the part of the plugin I'd test most carefully — try a
   plain mace swing on flat ground (should NOT get +10) vs. an
   elytra/fall-into-hit (should get +10 on top of vanilla's own smash
   bonus).

3. **The "Spear" base item** is treated as `Material.NETHERITE_SPEAR`,
   which the public 1.21.11 javadocs do list, alongside iron/diamond/gold/
   copper spear variants. I didn't have a live server to confirm the
   recipe accepts it or that ability code referencing it compiles — that's
   on the very edge of my knowledge cutoff for a feature this new.

4. **Recipe ingredient counts vs. grid slots**: a shaped recipe slot is
   either filled or empty, it doesn't carry an "x4" quantity — the "x4 / x2
   / x1 / x1" amounts from the design doc are expressed by how many grid
   cells use that letter (A appears 4 times, B appears 2 times, C and D
   once each), which is the standard way Minecraft shaped recipes work.

5. **Boss bar avoids `getOnlinePlayers()` race conditions** by adding all
   currently-online players when the bar is created; players who join
   mid-ritual won't auto-see it. If you want that, hook a
   `PlayerJoinEvent` listener that calls
   `BossBarManager#addPlayerToActiveBars`.

## API verification notes (for transparency)

I don't have a compiler in my environment that can link against the real
Paper API, so I cross-checked every non-trivial call against PaperMC's
published 1.21.11 javadocs via web search before finalizing the code. Two
mistakes were caught and fixed this way:
- `EntityDamageEvent.DamageCause.MACE_SMASH` — doesn't exist; replaced with
  fall-distance detection (see #2 above).
- `Attribute.ATTACK_DAMAGE` / `Attribute.MAX_HEALTH` — wrong names; the
  real constants are `Attribute.GENERIC_ATTACK_DAMAGE` /
  `Attribute.GENERIC_MAX_HEALTH`, now fixed in `CloneManager`.

Confirmed correct via the same javadocs: `Material.NETHERITE_SPEAR`,
`Entity#isOnGround()` / `getFallDistance()`, `World#rayTraceEntities(...)`,
`World#spawn(Location, Class, Consumer)`, `Bukkit.createBossBar(...)`,
`Server#broadcast(Component)`, and `ItemMeta#setCustomModelData(int)`
(deprecated but functional).

I was not able to verify `EntityTargetEvent`'s exact method signatures or
`PlayerSwapHandItemsEvent`'s cancel behavior against 1.21.11 specifically —
both are long-stable APIs so I'm fairly confident, but please watch the
console for deprecation/removal warnings on first boot.

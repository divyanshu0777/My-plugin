package com.ascendantaqua.util;

import com.ascendantaqua.AscendantAquaPlugin;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/**
 * Utility class responsible for constructing the Ascendant Elixir item and
 * providing the NamespacedKey / PDC value constants used across the plugin.
 */
public final class AscendantAquaItemFactory {

    // ── PDC constants ─────────────────────────────────────────────────────────
    /** The key stored inside PersistentDataContainer on the Ascendant Elixir. */
    public static final String PDC_KEY_NAME  = "ascendant_aqua_item";
    /** The value stored alongside PDC_KEY_NAME to identify this as the real item. */
    public static final String PDC_VALUE     = "ultimate_ability";

    // ── Singleton key (created once, reused) ─────────────────────────────────
    private static NamespacedKey namespacedKey;

    private AscendantAquaItemFactory() { /* utility – no instances */ }

    // ─────────────────────────────────────────────────────────────────────────
    // Key accessor
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns (creating on first call) the NamespacedKey used to tag the item.
     * Must be called after the plugin is fully enabled.
     */
    public static NamespacedKey getKey() {
        if (namespacedKey == null) {
            namespacedKey = new NamespacedKey(AscendantAquaPlugin.getInstance(), PDC_KEY_NAME);
        }
        return namespacedKey;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Item construction
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Constructs a fresh Ascendant Elixir item with:
     * <ul>
     *   <li>Material: POTION</li>
     *   <li>Display name: §b§lAscendant Elixir</li>
     *   <li>Custom lore describing the ability</li>
     *   <li>Glowing texture via a dummy enchant hidden behind ItemFlag.HIDE_ENCHANTS</li>
     *   <li>PersistentDataContainer entry: ascendant_aqua_item = ultimate_ability</li>
     * </ul>
     */
    public static ItemStack createAscendantElixir() {
        ItemStack item = new ItemStack(Material.POTION, 1);
        PotionMeta meta = (PotionMeta) item.getItemMeta();

        if (meta == null) {
            // Defensive: should never happen for POTION on a Paper server.
            throw new IllegalStateException("Could not obtain PotionMeta for POTION item.");
        }

        // ── Display name ──────────────────────────────────────────────────────
        meta.setDisplayName("§b§lAscendant Elixir");

        // ── Lore ──────────────────────────────────────────────────────────────
        meta.setLore(List.of(
                "§7§oA relic of the ancient seas,",
                "§7§oforged from the tears of Poseidon.",
                "",
                "§b▶ §fShift + Right-Click §7to unleash",
                "§b  Poseidon's Wrath §7for §e20 seconds§7.",
                "",
                "§3❈ §fAbyssal Trident§7: Piercing, instant return,",
                "§3  §7lightning & water explosion on hit.",
                "§3❈ §fOcean Domain§7: 20-block storm zone.",
                "§3❈ §fCrushing Vortex§7: True damage every 1.5s.",
                "§3❈ §fDepths Judgment§7: Execute at 40% HP.",
                "",
                "§8Cooldown: §e240 seconds"
        ));

        // ── Glowing texture (hidden enchant) ──────────────────────────────────
        // We use LUCK_OF_THE_SEA thematically but any enchant works.
        meta.addEnchant(Enchantment.LUCK_OF_THE_SEA, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        // Also hide potion effects that would be listed from the PotionMeta
        meta.addItemFlags(ItemFlag.HIDE_ADDITIONAL_TOOLTIP);

        // ── PersistentDataContainer ───────────────────────────────────────────
        meta.getPersistentDataContainer()
            .set(getKey(), PersistentDataType.STRING, PDC_VALUE);

        item.setItemMeta(meta);
        return item;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Validation helper
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns {@code true} if and only if the given {@link ItemStack} is the
     * legitimate Ascendant Elixir (has the correct PDC entry).
     * Regular potions, renamed anvil potions, or crafted potions will all fail
     * this check because they lack the PersistentDataContainer entry.
     *
     * @param item the item to inspect – may be {@code null}.
     * @return whether this is the real Ascendant Elixir.
     */
    public static boolean isAscendantElixir(ItemStack item) {
        if (item == null || item.getType() != Material.POTION) {
            return false;
        }
        if (!item.hasItemMeta()) {
            return false;
        }
        String value = item.getItemMeta()
                          .getPersistentDataContainer()
                          .get(getKey(), PersistentDataType.STRING);
        return PDC_VALUE.equals(value);
    }
}

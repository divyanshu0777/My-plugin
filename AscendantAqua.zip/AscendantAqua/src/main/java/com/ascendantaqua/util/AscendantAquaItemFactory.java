package com.ascendantaqua.util;

import com.ascendantaqua.AscendantAquaPlugin;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionType;

import java.util.List;

/**
 * Builds and validates the Ascendant Elixir item.
 *
 * FIXED: Removed HIDE_ADDITIONAL_TOOLTIP (does not exist in Paper 1.21).
 *        Using HIDE_ATTRIBUTES + HIDE_POTION_EFFECTS instead.
 */
public final class AscendantAquaItemFactory {

    public static final String PDC_KEY_NAME = "ascendant_aqua_item";
    public static final String PDC_VALUE    = "ultimate_ability";

    private static NamespacedKey namespacedKey;

    private AscendantAquaItemFactory() {}

    public static NamespacedKey getKey() {
        if (namespacedKey == null) {
            namespacedKey = new NamespacedKey(AscendantAquaPlugin.getInstance(), PDC_KEY_NAME);
        }
        return namespacedKey;
    }

    /**
     * Creates the Ascendant Elixir with:
     *  - Material: POTION
     *  - Custom display name and lore
     *  - Cyan potion color via PotionMeta.setColor()
     *  - Glowing via hidden LUCK_OF_THE_SEA enchant
     *  - PersistentDataContainer: ascendant_aqua_item = ultimate_ability
     */
    public static ItemStack createAscendantElixir() {
        ItemStack item = new ItemStack(Material.POTION, 1);
        PotionMeta meta = (PotionMeta) item.getItemMeta();

        if (meta == null) {
            throw new IllegalStateException("PotionMeta was null for POTION material.");
        }

        // Display name
        meta.setDisplayName("§b§lAscendant Elixir");

        // Lore
        meta.setLore(List.of(
                "§7§oA relic of the ancient seas,",
                "§7§oforged from the tears of Poseidon.",
                "",
                "§b▶ §fShift + Right-Click §7to unleash",
                "§b  Poseidon's Wrath §7for §e20 seconds§7.",
                "",
                "§3❈ §fAbyssal Trident§7: Piercing, instant return,",
                "§3  §7lightning & water explosion on hit.",
                "§3❈ §fOcean Domain§7: 20-block storm zone.",
                "§3❈ §fCrushing Vortex§7: True damage every 1.5s.",
                "§3❈ §fDepths Judgment§7: Execute at 40% HP.",
                "",
                "§8Cooldown: §e240 seconds"
        ));

        // Custom cyan color so it looks distinct
        meta.setColor(Color.fromRGB(0, 210, 255));

        // Glowing texture: hidden enchant
        meta.addEnchant(Enchantment.LUCK_OF_THE_SEA, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        // Hide vanilla potion effect tooltip lines (valid in 1.21)
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);

        // PDC marker — this is the ONLY thing isAscendantElixir() checks
        meta.getPersistentDataContainer()
            .set(getKey(), PersistentDataType.STRING, PDC_VALUE);

        item.setItemMeta(meta);
        return item;
    }

    /**
     * Validates an item is the real Ascendant Elixir via PDC.
     * Renamed anvil potions and regular potions will return false.
     */
    public static boolean isAscendantElixir(ItemStack item) {
        if (item == null || item.getType() != Material.POTION) return false;
        if (!item.hasItemMeta()) return false;

        String value = item.getItemMeta()
                          .getPersistentDataContainer()
                          .get(getKey(), PersistentDataType.STRING);
        return PDC_VALUE.equals(value);
    }
}

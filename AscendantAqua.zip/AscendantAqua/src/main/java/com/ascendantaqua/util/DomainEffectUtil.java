package com.ascendantaqua.util;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * Shared combat helpers used across domain logic and event listeners.
 *
 * True Damage is implemented by directly calling entity.damage() with a very
 * large value after temporarily setting absorption to 0, OR by using setHealth()
 * directly — we use setHealth() to bypass armour and enchantments completely.
 *
 * Particle NOTE: WATER_WAKE does NOT exist in 1.21. Replaced with SPLASH everywhere.
 */
public final class DomainEffectUtil {

    private DomainEffectUtil() {}

    // ─────────────────────────────────────────────────────────────────────────
    // True Damage (bypasses armour via setHealth)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Deals flat true damage in hearts. 1 heart = 2.0 HP.
     * Owner is always immune — method returns silently if target == owner.
     */
    public static void dealTrueDamage(LivingEntity target, double hearts, Player owner) {
        if (target instanceof Player p && p.equals(owner)) return;
        if (target.isDead()) return;

        double dmgHP     = hearts * 2.0;
        double newHealth = Math.max(0.0, target.getHealth() - dmgHP);
        target.setHealth(newHealth);

        target.getWorld().playSound(
                target.getLocation(),
                Sound.ENTITY_PLAYER_HURT,
                1.0f, 0.8f
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Pull toward a point
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Applies an instant velocity impulse pulling {@code target} toward {@code center}.
     * Owner is always skipped.
     */
    public static void pullToward(Entity target, Location center, double blocks, Player owner) {
        if (target instanceof Player p && p.equals(owner)) return;

        Vector toCenter  = center.toVector().subtract(target.getLocation().toVector());
        double distance  = toCenter.length();
        if (distance < 0.5) return;

        double magnitude = Math.min(blocks, distance);
        Vector velocity  = toCenter.normalize().multiply(magnitude / 10.0);
        target.setVelocity(velocity);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Particle effects  (NO WATER_WAKE — replaced with SPLASH)
    // ─────────────────────────────────────────────────────────────────────────

    /** Water explosion burst — Tidal Surge & trident impact. */
    public static void spawnWaterExplosion(Location loc) {
        World world = loc.getWorld();
        if (world == null) return;

        world.spawnParticle(Particle.SPLASH,     loc, 80, 2.0, 1.0, 2.0, 0.3);
        world.spawnParticle(Particle.BUBBLE_POP, loc, 60, 1.5, 0.8, 1.5, 0.2);
        world.spawnParticle(Particle.EXPLOSION,  loc,  3, 0.5, 0.3, 0.5, 0.0);
        world.spawnParticle(Particle.SPLASH,     loc, 40, 2.0, 0.5, 2.0, 0.1);

        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.7f);
        world.playSound(loc, Sound.BLOCK_WATER_AMBIENT,    1.5f, 0.5f);
    }

    /** Heavy vortex swirl — Crushing Vortex. */
    public static void spawnVortexEffect(Location loc) {
        World world = loc.getWorld();
        if (world == null) return;

        for (int i = 0; i < 24; i++) {
            double angle   = (2 * Math.PI / 24) * i;
            double radius  = 1.2;
            double x       = loc.getX() + radius * Math.cos(angle);
            double z       = loc.getZ() + radius * Math.sin(angle);
            Location ring  = new Location(world, x, loc.getY() + 0.1, z);
            world.spawnParticle(Particle.BUBBLE_COLUMN_UP, ring, 3, 0.05, 0.3, 0.05, 0.02);
        }

        world.spawnParticle(Particle.SPLASH,         loc, 50, 0.5, 1.5, 0.5, 0.2);
        world.spawnParticle(Particle.BUBBLE_POP,     loc, 30, 0.3, 1.0, 0.3, 0.1);
        world.spawnParticle(Particle.DRIPPING_WATER, loc, 20, 0.4, 1.0, 0.4, 0.0);

        world.playSound(loc, Sound.BLOCK_BUBBLE_COLUMN_UPWARDS_AMBIENT, 1.5f, 0.6f);
        world.playSound(loc, Sound.ENTITY_ELDER_GUARDIAN_CURSE,         0.6f, 1.4f);
    }

    /** Ambient domain border ring — called every domain loop tick. */
    public static void spawnDomainAmbient(Location center) {
        World world = center.getWorld();
        if (world == null) return;

        for (int i = 0; i < 16; i++) {
            double angle   = (2 * Math.PI / 16) * i;
            double x       = center.getX() + 20.0 * Math.cos(angle);
            double z       = center.getZ() + 20.0 * Math.sin(angle);
            Location edge  = new Location(world, x, center.getY() + 1.0, z);
            world.spawnParticle(Particle.SPLASH, edge, 2, 0.2, 0.5, 0.2, 0.05);
        }

        for (int i = 0; i < 8; i++) {
            double rx = (Math.random() - 0.5) * 10;
            double ry = 3.0 + Math.random() * 5.0;
            double rz = (Math.random() - 0.5) * 10;
            world.spawnParticle(Particle.DRIPPING_WATER,
                    center.clone().add(rx, ry, rz), 1, 0.1, 0.1, 0.1, 0.0);
        }

        world.playSound(center, Sound.WEATHER_RAIN,        0.3f, 0.8f);
        world.playSound(center, Sound.BLOCK_WATER_AMBIENT, 0.4f, 0.6f);
    }

    /** Lightning + water burst at trident impact point. */
    public static void spawnTridentImpact(Location loc) {
        World world = loc.getWorld();
        if (world == null) return;

        world.spawnParticle(Particle.SPLASH,         loc, 60, 1.0, 0.5, 1.0, 0.4);
        world.spawnParticle(Particle.BUBBLE_POP,     loc, 40, 0.8, 0.4, 0.8, 0.2);
        world.spawnParticle(Particle.ELECTRIC_SPARK, loc, 20, 0.5, 0.5, 0.5, 0.1);

        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 1.1f);
        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE,        0.8f, 1.3f);
    }

    /** Zero velocity stun. Owner is always skipped. */
    public static void applyStun(LivingEntity target, Player owner) {
        if (target instanceof Player p && p.equals(owner)) return;
        target.setVelocity(new Vector(0, 0, 0));
    }

    /**
     * Returns true if entity is a valid non-owner living target.
     */
    public static boolean isValidTarget(Entity entity, Player owner) {
        if (!(entity instanceof LivingEntity living)) return false;
        if (entity instanceof Player p && p.equals(owner)) return false;
        if (!living.isValid() || living.isDead()) return false;
        return true;
    }
}

package com.ascendantaqua.util;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * Shared combat helpers used across domain logic and event listeners.
 *
 * <p><b>True Damage</b> is implemented by directly setting
 * {@code entity.setHealth(max(0, currentHealth – amount))}.
 * This bypasses armour, enchantments, and damage-reduction effects, exactly
 * matching the "flat true damage" specification.
 */
public final class DomainEffectUtil {

    private DomainEffectUtil() { /* utility */ }

    // ─────────────────────────────────────────────────────────────────────────
    // True Damage
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Deals {@code hearts} hearts of true damage to a {@link LivingEntity},
     * bypassing all armour and damage reduction.
     *
     * <p>1 heart = 2.0 health points (the Bukkit scale).
     *
     * @param target the entity receiving damage.
     * @param hearts how many hearts of health to remove.
     * @param owner  the owner of the ability; if {@code target.equals(owner)}
     *               the call is silently skipped to guarantee owner immunity.
     */
    public static void dealTrueDamage(LivingEntity target, double hearts, Player owner) {
        // ── Owner immunity (CRITICAL) ─────────────────────────────────────────
        if (target instanceof Player p && p.equals(owner)) {
            return; // owner is immune to self-inflicted true damage
        }

        double damagePts = hearts * 2.0; // convert hearts → HP
        double newHealth = Math.max(0.0, target.getHealth() - damagePts);
        target.setHealth(newHealth);

        // Play a hit sound so the damage feels impactful
        target.getWorld().playSound(
                target.getLocation(),
                Sound.ENTITY_PLAYER_HURT,
                1.0f,
                0.8f
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Pull vector
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Pulls {@code target} {@code blocks} blocks toward {@code center}.
     *
     * <p>If the entity is already within 0.5 blocks of the center the call is
     * a no-op to avoid jitter.
     *
     * @param target  entity to move.
     * @param center  point to pull toward.
     * @param blocks  desired pull distance (capped at the actual distance).
     * @param owner   owner of the ability; skipped if target equals owner.
     */
    public static void pullToward(Entity target, Location center, double blocks, Player owner) {
        // ── Owner immunity (CRITICAL) ─────────────────────────────────────────
        if (target instanceof Player p && p.equals(owner)) {
            return;
        }

        Vector toCenter = center.toVector().subtract(target.getLocation().toVector());
        double distance = toCenter.length();
        if (distance < 0.5) {
            return; // already at the center – nothing to do
        }

        double pullMagnitude = Math.min(blocks, distance);
        Vector velocity = toCenter.normalize().multiply(pullMagnitude / 10.0);
        // Divide by 10 to spread the impulse realistically across ticks;
        // the actual displacement per tick is velocity (1 tick = 50 ms).
        target.setVelocity(velocity);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Particle effects
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Spawns a "water explosion" particle burst at the given location:
     * WATER_SPLASH + BUBBLE_POP rings to simulate a hydraulic detonation.
     */
    public static void spawnWaterExplosion(Location loc) {
        World world = loc.getWorld();
        if (world == null) return;

        world.spawnParticle(Particle.SPLASH,      loc, 80, 2.0, 1.0, 2.0, 0.3);
        world.spawnParticle(Particle.BUBBLE_POP,  loc, 60, 1.5, 0.8, 1.5, 0.2);
        world.spawnParticle(Particle.EXPLOSION,   loc,  3, 0.5, 0.3, 0.5, 0.0);
        world.spawnParticle(Particle.WATER_WAKE,  loc, 40, 2.0, 0.5, 2.0, 0.1);

        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE,  1.2f, 0.7f);
        world.playSound(loc, Sound.BLOCK_WATER_AMBIENT,     1.5f, 0.5f);
    }

    /**
     * Spawns the "heavy water vortex" particle effect used by Crushing Vortex.
     * Creates a swirling pillar of bubbles and water around the target.
     */
    public static void spawnVortexEffect(Location loc) {
        World world = loc.getWorld();
        if (world == null) return;

        // Swirling base ring
        for (int i = 0; i < 24; i++) {
            double angle  = (2 * Math.PI / 24) * i;
            double radius = 1.2;
            double x      = loc.getX() + radius * Math.cos(angle);
            double z      = loc.getZ() + radius * Math.sin(angle);
            Location ringLoc = new Location(world, x, loc.getY() + 0.1, z);
            world.spawnParticle(Particle.BUBBLE_COLUMN_UP, ringLoc, 3, 0.05, 0.3, 0.05, 0.02);
        }

        // Vertical column
        world.spawnParticle(Particle.SPLASH,      loc, 50, 0.5, 1.5, 0.5, 0.2);
        world.spawnParticle(Particle.BUBBLE_POP,  loc, 30, 0.3, 1.0, 0.3, 0.1);
        world.spawnParticle(Particle.DRIPPING_WATER, loc, 20, 0.4, 1.0, 0.4, 0.0);

        world.playSound(loc, Sound.BLOCK_BUBBLE_COLUMN_UPWARDS_AMBIENT, 1.5f, 0.6f);
        world.playSound(loc, Sound.ENTITY_ELDER_GUARDIAN_CURSE,         0.6f, 1.4f);
    }

    /**
     * Spawns the ambient ocean domain storm particles around the owner
     * (called every domain loop iteration from DomainRunner).
     */
    public static void spawnDomainAmbient(Location center) {
        World world = center.getWorld();
        if (world == null) return;

        // Rotating outer ring every loop gives a "churning sea" feel
        for (int i = 0; i < 16; i++) {
            double angle  = (2 * Math.PI / 16) * i;
            double radius = 20.0;
            double x      = center.getX() + radius * Math.cos(angle);
            double z      = center.getZ() + radius * Math.sin(angle);
            Location edgeLoc = new Location(world, x, center.getY() + 1.0, z);
            world.spawnParticle(Particle.SPLASH, edgeLoc, 2, 0.2, 0.5, 0.2, 0.05);
        }

        // Rain of water particles over the owner
        for (int i = 0; i < 8; i++) {
            double rx = (Math.random() - 0.5) * 10;
            double ry = 3.0 + Math.random() * 5.0;
            double rz = (Math.random() - 0.5) * 10;
            Location rainLoc = center.clone().add(rx, ry, rz);
            world.spawnParticle(Particle.DRIPPING_WATER, rainLoc, 1, 0.1, 0.1, 0.1, 0.0);
        }

        world.playSound(center, Sound.WEATHER_RAIN,          0.3f, 0.8f);
        world.playSound(center, Sound.BLOCK_WATER_AMBIENT,   0.4f, 0.6f);
    }

    /**
     * Spawns a lightning-impact water effect at the given location
     * (used when the Abyssal Trident strikes an enemy).
     */
    public static void spawnTridentImpact(Location loc) {
        World world = loc.getWorld();
        if (world == null) return;

        world.spawnParticle(Particle.SPLASH,     loc, 60, 1.0, 0.5, 1.0, 0.4);
        world.spawnParticle(Particle.BUBBLE_POP, loc, 40, 0.8, 0.4, 0.8, 0.2);
        world.spawnParticle(Particle.ELECTRIC_SPARK, loc, 20, 0.5, 0.5, 0.5, 0.1);

        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 1.1f);
        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE,        0.8f, 1.3f);
    }

    /**
     * Applies a "stun" by zeroing the entity's velocity and (optionally)
     * teleporting it back to its current location to cancel any knockback.
     * The actual stun duration is managed by the caller via a delayed task.
     *
     * @param target entity to stun – owner is immune.
     * @param owner  the ability owner.
     */
    public static void applyStun(LivingEntity target, Player owner) {
        if (target instanceof Player p && p.equals(owner)) {
            return;
        }
        target.setVelocity(new Vector(0, 0, 0));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Utility
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns {@code true} if {@code entity} is a valid hostile target
     * (a LivingEntity that is not the owner).
     */
    public static boolean isValidTarget(Entity entity, Player owner) {
        if (!(entity instanceof LivingEntity living)) return false;
        if (entity instanceof Player p && p.equals(owner))  return false;
        if (!living.isValid() || living.isDead())            return false;
        return true;
    }
}

package com.ascendantaqua.util;

import com.ascendantaqua.AscendantAquaPlugin;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/**
 * Factory for the Abyssal Trident placed in the owner's main hand
 * during Poseidon's Wrath.
 *
 * FIXED: Removed HIDE_ADDITIONAL_TOOLTIP (does not exist in 1.21).
 */
public final class AbyssalTridentFactory {

    public static final String PDC_KEY_NAME = "abyssal_trident_item";
    public static final String PDC_VALUE    = "abyssal_trident";

    private static NamespacedKey namespacedKey;

    private AbyssalTridentFactory() {}

    public static NamespacedKey getKey() {
        if (namespacedKey == null) {
            namespacedKey = new NamespacedKey(AscendantAquaPlugin.getInstance(), PDC_KEY_NAME);
        }
        return namespacedKey;
    }

    public static ItemStack createAbyssalTrident() {
        ItemStack trident = new ItemStack(Material.TRIDENT, 1);
        ItemMeta  meta    = trident.getItemMeta();

        if (meta == null) throw new IllegalStateException("Null ItemMeta for TRIDENT.");

        meta.setDisplayName("§9§lAbyssal Trident");
        meta.setLore(List.of(
                "§7§oForged from the depths, returns to its master.",
                "",
                "§3✦ §fPierces through multiple enemies",
                "§3✦ §fSummons lightning on impact",
                "§3✦ §fDetonates a water explosion",
                "§3✦ §fPulls struck enemies toward you",
                "",
                "§8[Poseidon's Wrath Active Weapon]"
        ));

        meta.addEnchant(Enchantment.LOYALTY,    3, true);
        meta.addEnchant(Enchantment.CHANNELING, 1, true);
        meta.addEnchant(Enchantment.IMPALING,   5, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);

        meta.getPersistentDataContainer()
            .set(getKey(), PersistentDataType.STRING, PDC_VALUE);

        trident.setItemMeta(meta);
        return trident;
    }

    public static boolean isAbyssalTrident(ItemStack item) {
        if (item == null || item.getType() != Material.TRIDENT) return false;
        if (!item.hasItemMeta()) return false;
        String val = item.getItemMeta()
                         .getPersistentDataContainer()
                         .get(getKey(), PersistentDataType.STRING);
        return PDC_VALUE.equals(val);
    }
}

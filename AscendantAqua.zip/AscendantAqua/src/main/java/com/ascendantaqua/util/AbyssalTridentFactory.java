package com.ascendantaqua.util;

import com.ascendantaqua.AscendantAquaPlugin;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/**
 * Utility class for the Abyssal Trident – the active weapon that replaces the
 * owner's main hand during Poseidon's Wrath.
 */
public final class AbyssalTridentFactory {

    public static final String PDC_KEY_NAME = "abyssal_trident_item";
    public static final String PDC_VALUE     = "abyssal_trident";

    private static NamespacedKey namespacedKey;

    private AbyssalTridentFactory() { /* utility */ }

    public static NamespacedKey getKey() {
        if (namespacedKey == null) {
            namespacedKey = new NamespacedKey(AscendantAquaPlugin.getInstance(), PDC_KEY_NAME);
        }
        return namespacedKey;
    }

    /**
     * Creates the Abyssal Trident ItemStack placed in the owner's main hand
     * during Poseidon's Wrath.
     *
     * <p>Enchantments applied:
     * <ul>
     *   <li>LOYALTY III  – instant return / infinite throws (handled in listener)</li>
     *   <li>CHANNELING I – summons lightning on hit (visual, enforced in listener)</li>
     *   <li>IMPALING V   – extra damage vs aquatic + piercing feel</li>
     *   <li>RIPTIDE is intentionally omitted to prevent self-launch</li>
     * </ul>
     */
    public static ItemStack createAbyssalTrident() {
        ItemStack trident = new ItemStack(Material.TRIDENT, 1);
        ItemMeta meta = trident.getItemMeta();

        if (meta == null) {
            throw new IllegalStateException("Could not obtain ItemMeta for TRIDENT.");
        }

        meta.setDisplayName("§9§lAbyssal Trident");
        meta.setLore(List.of(
                "§7§oForged from the depths, returns to its master.",
                "",
                "§3✦ §fPierces through multiple enemies",
                "§3✦ §fSummons lightning on impact",
                "§3✦ §fDetonates a water explosion",
                "§3✦ §fPulls struck enemies toward you",
                "",
                "§8[Poseidon's Wrath Active Weapon]"
        ));

        // Enchantments
        meta.addEnchant(Enchantment.LOYALTY,    3, true);
        meta.addEnchant(Enchantment.CHANNELING, 1, true);
        meta.addEnchant(Enchantment.IMPALING,   5, true);

        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);

        // PDC marker so we can identify it in event listeners
        meta.getPersistentDataContainer()
            .set(getKey(), PersistentDataType.STRING, PDC_VALUE);

        trident.setItemMeta(meta);
        return trident;
    }

    /** Returns true if this item is the plugin-generated Abyssal Trident. */
    public static boolean isAbyssalTrident(ItemStack item) {
        if (item == null || item.getType() != Material.TRIDENT) {
            return false;
        }
        if (!item.hasItemMeta()) {
            return false;
        }
        String val = item.getItemMeta()
                         .getPersistentDataContainer()
                         .get(getKey(), PersistentDataType.STRING);
        return PDC_VALUE.equals(val);
    }
}

package com.ascendantaqua.listeners;

import com.ascendantaqua.AscendantAquaPlugin;
import com.ascendantaqua.domain.DomainManager;
import com.ascendantaqua.state.AscendantAquaStateManager;
import com.ascendantaqua.util.AscendantAquaItemFactory;
import com.ascendantaqua.util.DomainEffectUtil;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;

import java.util.Collection;

/**
 * Central listener for the AscendantAqua plugin.
 *
 * <h2>Handled events</h2>
 * <ul>
 *   <li>{@link PlayerInteractEvent}       – SHIFT + RIGHT_CLICK to activate</li>
 *   <li>{@link EntityDamageByEntityEvent} – Tidal Surge counter (every 6th hit)
 *                                           + owner immunity guards</li>
 *   <li>{@link EntityDamageEvent}         – owner immunity for generic damage
 *                                           (explosions, etc.)</li>
 *   <li>{@link EntityPotionEffectEvent}   – prevent Slowness / Mining Fatigue
 *                                           from applying to the owner</li>
 *   <li>{@link PlayerQuitEvent}           – end domain on logout</li>
 *   <li>{@link PlayerDeathEvent}          – end domain on death</li>
 *   <li>{@link EntityDamageEvent}         – lightning strike immunity</li>
 * </ul>
 *
 * <p><b>Owner immunity</b> is explicitly checked on every relevant branch using
 * {@code target.equals(owner)} comparisons; no effect is applied to the owner.
 */
public class AscendantAquaListener implements Listener {

    /** Domain radius (must match DomainRunner's constant). */
    private static final double DOMAIN_RADIUS = 20.0;
    /** Tidal Surge: water explosion every Nth physical hit. */
    private static final int    TIDAL_SURGE_INTERVAL = 6;
    /** Tidal Surge: pull radius. */
    private static final double TIDAL_SURGE_RADIUS   = 8.0;
    /** Tidal Surge: pull distance. */
    private static final double TIDAL_SURGE_PULL     = 3.0;
    /** Tidal Surge: true damage in hearts. */
    private static final double TIDAL_SURGE_DAMAGE   = 4.0; // 4 hearts

    private final AscendantAquaPlugin       plugin;
    private final AscendantAquaStateManager stateManager;

    public AscendantAquaListener(AscendantAquaPlugin plugin) {
        this.plugin       = plugin;
        this.stateManager = AscendantAquaStateManager.getInstance();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Ability Activation – SHIFT + RIGHT_CLICK
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Fires when a player interacts with any item/block.
     *
     * <p>Activation requirements:
     * <ol>
     *   <li>Action must be RIGHT_CLICK_AIR or RIGHT_CLICK_BLOCK.</li>
     *   <li>Player must be sneaking (shift held).</li>
     *   <li>Main-hand item must be the Ascendant Elixir (validated via PDC).</li>
     *   <li>Player must not already have an active domain.</li>
     *   <li>Player must not be on cooldown.</li>
     * </ol>
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Action action = event.getAction();

        // ── Only right-clicks ─────────────────────────────────────────────────
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player player = event.getPlayer();

        // ── Must be sneaking ──────────────────────────────────────────────────
        if (!player.isSneaking()) {
            return;
        }

        // ── Check main-hand item is the Ascendant Elixir (PDC validated) ──────
        ItemStack mainHand = player.getInventory().getItemInMainHand();
        if (!AscendantAquaItemFactory.isAscendantElixir(mainHand)) {
            return;
        }

        // ── Prevent vanilla potion consumption ────────────────────────────────
        event.setCancelled(true);

        // ── Already active ────────────────────────────────────────────────────
        if (stateManager.hasDomain(player.getUniqueId())) {
            player.sendMessage("§9§l[Ascendant Aqua] §7Poseidon's Wrath is already active!");
            return;
        }

        // ── Cooldown check ────────────────────────────────────────────────────
        if (stateManager.isOnCooldown(player.getUniqueId())) {
            long remaining = stateManager.getRemainingCooldownSeconds(player.getUniqueId());
            player.sendMessage("§9§l[Ascendant Aqua] §7Ability on cooldown: §e" +
                    remaining + "s §7remaining.");
            return;
        }

        // ── All checks passed – activate Poseidon's Wrath ─────────────────────
        DomainManager.startDomain(player, plugin, stateManager);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Tidal Surge – every 6th physical hit
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Listens for entity-versus-entity damage to track the owner's physical hit
     * count for the Tidal Surge mechanic.
     *
     * <p>Only counts:
     * <ul>
     *   <li>Hits where the damager is the domain owner.</li>
     *   <li>The damage cause must be {@link EntityDamageEvent.DamageCause#ENTITY_ATTACK}
     *       (melee) or {@link EntityDamageEvent.DamageCause#PROJECTILE} if it is
     *       an arrow/trident belonging to the owner. For Tidal Surge the spec says
     *       "physical hit", so we include both melee and projectile.</li>
     *   <li>Target must not be the owner.</li>
     * </ul>
     *
     * <p>Also enforces owner immunity: if the damaged entity IS the owner and the
     * damager is the owner themselves (e.g. from a reflected explosion) the event
     * is cancelled.
     *
     * <p><b>This handler also acts as the universal owner-immunity guard
     * for EntityDamageByEntityEvent.</b>
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {

        // ── Case A: The OWNER is being damaged – enforce immunity ─────────────
        if (event.getEntity() instanceof Player victim
                && stateManager.hasDomain(victim.getUniqueId())) {

            // The victim has an active domain.
            // Determine if this damage could be self-inflicted by their own ability.
            Entity damager = event.getDamager();

            // Owner immunity: owner cannot be damaged by their own lightning,
            // trident explosions, or splash true-damage.
            // We cancel only if the damager chain traces back to the owner.
            if (isSelfDamage(victim, damager)) {
                event.setCancelled(true);
                return;
            }
        }

        // ── Case B: The OWNER is dealing damage – count for Tidal Surge ───────
        if (!(event.getDamager() instanceof Player owner)) {
            return;
        }
        if (!stateManager.hasDomain(owner.getUniqueId())) {
            return;
        }

        // The target must not be the owner themselves (sanity guard)
        Entity target = event.getEntity();
        if (target instanceof Player p && p.equals(owner)) {
            event.setCancelled(true);
            return;
        }

        // Only count attacks that are physical (melee or projectile)
        EntityDamageEvent.DamageCause cause = event.getCause();
        if (cause != EntityDamageEvent.DamageCause.ENTITY_ATTACK
                && cause != EntityDamageEvent.DamageCause.PROJECTILE) {
            return;
        }

        // Retrieve the active domain state to track hit count
        var domain = stateManager.getActiveDomain(owner.getUniqueId());
        if (domain == null) return;

        int hitCount = domain.incrementHitCount();

        if (hitCount % TIDAL_SURGE_INTERVAL == 0) {
            // ── Tidal Surge triggered ─────────────────────────────────────────
            triggerTidalSurge(owner, target.getLocation());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Tidal Surge implementation
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Activates the Tidal Surge water explosion centred on {@code epicentre}:
     * <ol>
     *   <li>Spawns a water explosion particle burst.</li>
     *   <li>For every enemy within {@value #TIDAL_SURGE_RADIUS} blocks:
     *       <ul>
     *         <li>Deals {@value #TIDAL_SURGE_DAMAGE} hearts of flat true damage.</li>
     *         <li>Pulls them {@value #TIDAL_SURGE_PULL} blocks closer to the owner.</li>
     *       </ul>
     *   </li>
     * </ol>
     *
     * <p>The owner is skipped at both the collection stage and inside the
     * utility methods.
     */
    private void triggerTidalSurge(Player owner, Location epicentre) {
        // Particle effect
        DomainEffectUtil.spawnWaterExplosion(epicentre);

        // Collect targets in radius
        Collection<Entity> nearby = owner.getWorld().getNearbyEntities(
                epicentre, TIDAL_SURGE_RADIUS, TIDAL_SURGE_RADIUS, TIDAL_SURGE_RADIUS);

        for (Entity entity : nearby) {
            if (!DomainEffectUtil.isValidTarget(entity, owner)) {
                continue; // skips owner and invalid entities
            }
            LivingEntity living = (LivingEntity) entity;

            // True damage
            DomainEffectUtil.dealTrueDamage(living, TIDAL_SURGE_DAMAGE, owner);

            // Pull toward owner
            DomainEffectUtil.pullToward(entity, owner.getLocation(), TIDAL_SURGE_PULL, owner);
        }

        // Notify owner
        owner.sendMessage("§b§l[Tidal Surge] §fWater explosion triggered!");
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Owner generic damage immunity (explosions, fire, etc.)
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Catches generic damage events (not entity-vs-entity) and cancels them
     * if the victim is the owner of an active domain AND the damage falls into
     * categories that could be self-inflicted by the ability:
     * <ul>
     *   <li>BLOCK_EXPLOSION</li>
     *   <li>ENTITY_EXPLOSION</li>
     *   <li>LIGHTNING</li>
     *   <li>MAGIC (e.g. splash potions from vortex)</li>
     * </ul>
     *
     * <p>This does NOT make the owner entirely invulnerable – only to the listed
     * ability-adjacent damage types.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player owner)) {
            return;
        }
        if (!stateManager.hasDomain(owner.getUniqueId())) {
            return;
        }

        EntityDamageEvent.DamageCause cause = event.getCause();
        switch (cause) {
            case BLOCK_EXPLOSION,
                 ENTITY_EXPLOSION,
                 LIGHTNING,
                 MAGIC -> event.setCancelled(true); // owner immune to ability-adjacent damage
            default -> { /* let other damage through */ }
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Owner immunity: Slowness and Mining Fatigue
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Prevents Slowness and Mining Fatigue from being applied to the owner
     * by any external source while Poseidon's Wrath is active.
     *
     * <p>The Ocean Domain intentionally applies these to enemies only; the domain
     * loop never applies them to the owner. This handler acts as a failsafe
     * against, e.g., a stray elder guardian curse or splash potion.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onOwnerPotionEffect(EntityPotionEffectEvent event) {
        if (!(event.getEntity() instanceof Player owner)) {
            return;
        }
        if (!stateManager.hasDomain(owner.getUniqueId())) {
            return;
        }

        // Only block incoming effects (ADD action); allow removal
        if (event.getAction() != EntityPotionEffectEvent.Action.ADDED
                && event.getAction() != EntityPotionEffectEvent.Action.CHANGED) {
            return;
        }

        PotionEffectType newType = event.getNewEffect() != null
                ? event.getNewEffect().getType()
                : null;

        if (newType == null) return;

        if (newType.equals(PotionEffectType.SLOWNESS)
                || newType.equals(PotionEffectType.MINING_FATIGUE)) {
            event.setCancelled(true);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Cleanup on quit / death
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Ends the domain cleanly if the owner disconnects.
     * Prevents orphaned tasks from running after the player is gone.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (stateManager.hasDomain(player.getUniqueId())) {
            DomainManager.endDomain(player, plugin, stateManager);
        }
    }

    /**
     * Ends the domain cleanly if the owner dies.
     * Restores their hand slot (to prevent losing the trident to drops).
     */
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (stateManager.hasDomain(player.getUniqueId())) {
            DomainManager.endDomain(player, plugin, stateManager);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Private utilities
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Determines whether the given damager can be traced back to the victim
     * themselves as a self-damage scenario.
     *
     * <p>Handles:
     * <ul>
     *   <li>Direct self-hit (damager == victim, rare but possible).</li>
     *   <li>Projectile fired by the victim.</li>
     *   <li>Area-of-effect from an explosion whose root source would be the victim.</li>
     * </ul>
     *
     * <p>For simplicity (and because the ability only creates lightning strikes and
     * water-splash explosions, not TNT), we consider any ENTITY_EXPLOSION or
     * LIGHTNING as potentially self-inflicted while a domain is active and rely on
     * {@link #onEntityDamage} for those causes instead.
     */
    private static boolean isSelfDamage(Player victim, Entity damager) {
        if (damager == null) return false;
        // Direct self-damage
        if (damager instanceof Player p && p.equals(victim)) {
            return true;
        }
        // Projectile shot by owner
        if (damager instanceof org.bukkit.entity.Projectile proj) {
            if (proj.getShooter() instanceof Player p && p.equals(victim)) {
                return true;
            }
        }
        return false;
    }
}

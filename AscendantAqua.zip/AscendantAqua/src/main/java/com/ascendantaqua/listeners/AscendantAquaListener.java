package com.ascendantaqua.listeners;

import com.ascendantaqua.AscendantAquaPlugin;
import com.ascendantaqua.domain.DomainManager;
import com.ascendantaqua.state.AscendantAquaStateManager;
import com.ascendantaqua.util.AscendantAquaItemFactory;
import com.ascendantaqua.util.DomainEffectUtil;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.player.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;

import java.util.Collection;

/**
 * Central event listener.
 *
 * FIXES applied vs previous version:
 * ──────────────────────────────────
 * 1. PlayerInteractEvent now checks getHand() == HAND to prevent the off-hand
 *    duplicate event from firing twice on Paper 1.21.
 * 2. event.setCancelled(true) is called BEFORE sneaking / item checks so that
 *    vanilla potion drinking is blocked as early as possible.
 * 3. Added null-guard on event.getItem() because Paper sometimes fires the event
 *    with a null item reference on RIGHT_CLICK_BLOCK.
 * 4. Extensive debug logging via plugin.getLogger() so server console shows
 *    exactly which check fails during activation.
 */
public class AscendantAquaListener implements Listener {

    private static final double DOMAIN_RADIUS       = 20.0;
    private static final int    TIDAL_SURGE_INTERVAL = 6;
    private static final double TIDAL_SURGE_RADIUS   = 8.0;
    private static final double TIDAL_SURGE_PULL     = 3.0;
    private static final double TIDAL_SURGE_DAMAGE   = 4.0;

    private final AscendantAquaPlugin       plugin;
    private final AscendantAquaStateManager stateManager;

    public AscendantAquaListener(AscendantAquaPlugin plugin) {
        this.plugin       = plugin;
        this.stateManager = AscendantAquaStateManager.getInstance();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // ACTIVATION — Shift + Right-Click
    // ═════════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerInteract(PlayerInteractEvent event) {

        // ── CRITICAL FIX: Paper fires this event for BOTH hands.
        //    We only want the main-hand event.
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }

        Action action = event.getAction();

        // Only right-click actions
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player player = event.getPlayer();

        // ── Cancel block interaction & item use early so potion won't drink ──
        event.setCancelled(true);

        // Must be sneaking
        if (!player.isSneaking()) {
            return;
        }

        // Fetch main-hand item directly from inventory (more reliable than event.getItem())
        ItemStack mainHand = player.getInventory().getItemInMainHand();

        // Debug log — visible in console if ability doesn't activate
        plugin.getLogger().info("[AA-DEBUG] " + player.getName()
                + " RClick+Sneak | item=" + mainHand.getType()
                + " | isElixir=" + AscendantAquaItemFactory.isAscendantElixir(mainHand));

        // PDC check
        if (!AscendantAquaItemFactory.isAscendantElixir(mainHand)) {
            return;
        }

        // Already active
        if (stateManager.hasDomain(player.getUniqueId())) {
            player.sendMessage("§9§l[Ascendant Aqua] §7Poseidon's Wrath is already active!");
            return;
        }

        // Cooldown check
        if (stateManager.isOnCooldown(player.getUniqueId())) {
            long remaining = stateManager.getRemainingCooldownSeconds(player.getUniqueId());
            player.sendMessage("§9§l[Ascendant Aqua] §7Cooldown: §e" + remaining + "s §7remaining.");
            return;
        }

        // ── ALL CHECKS PASSED — activate ──────────────────────────────────────
        plugin.getLogger().info("[AA-DEBUG] Starting domain for " + player.getName());
        DomainManager.startDomain(player, plugin, stateManager);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // TIDAL SURGE + OWNER IMMUNITY (EntityDamageByEntity)
    // ═════════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {

        // ── Case A: Owner is the VICTIM — self-damage immunity ────────────────
        if (event.getEntity() instanceof Player victim
                && stateManager.hasDomain(victim.getUniqueId())) {
            if (isSelfDamage(victim, event.getDamager())) {
                event.setCancelled(true);
                return;
            }
        }

        // ── Case B: Owner is the DAMAGER — Tidal Surge counter ────────────────
        if (!(event.getDamager() instanceof Player owner)) return;
        if (!stateManager.hasDomain(owner.getUniqueId())) return;

        Entity target = event.getEntity();

        // Owner cannot hit themselves
        if (target instanceof Player p && p.equals(owner)) {
            event.setCancelled(true);
            return;
        }

        // Count only physical hits
        EntityDamageEvent.DamageCause cause = event.getCause();
        if (cause != EntityDamageEvent.DamageCause.ENTITY_ATTACK
                && cause != EntityDamageEvent.DamageCause.PROJECTILE) {
            return;
        }

        var domain = stateManager.getActiveDomain(owner.getUniqueId());
        if (domain == null) return;

        int hitCount = domain.incrementHitCount();
        if (hitCount % TIDAL_SURGE_INTERVAL == 0) {
            triggerTidalSurge(owner, target.getLocation());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────

    private void triggerTidalSurge(Player owner, Location epicentre) {
        DomainEffectUtil.spawnWaterExplosion(epicentre);

        Collection<Entity> nearby = owner.getWorld().getNearbyEntities(
                epicentre, TIDAL_SURGE_RADIUS, TIDAL_SURGE_RADIUS, TIDAL_SURGE_RADIUS);

        for (Entity entity : nearby) {
            if (!DomainEffectUtil.isValidTarget(entity, owner)) continue;
            LivingEntity living = (LivingEntity) entity;
            DomainEffectUtil.dealTrueDamage(living, TIDAL_SURGE_DAMAGE, owner);
            DomainEffectUtil.pullToward(entity, owner.getLocation(), TIDAL_SURGE_PULL, owner);
        }

        owner.sendMessage("§b§l[Tidal Surge] §fWater explosion triggered!");
    }

    // ═════════════════════════════════════════════════════════════════════════
    // OWNER IMMUNITY — Generic damage (explosions, lightning, magic)
    // ═════════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player owner)) return;
        if (!stateManager.hasDomain(owner.getUniqueId())) return;

        EntityDamageEvent.DamageCause cause = event.getCause();
        switch (cause) {
            case BLOCK_EXPLOSION,
                 ENTITY_EXPLOSION,
                 LIGHTNING,
                 MAGIC -> event.setCancelled(true);
            default -> { /* other damage allowed */ }
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // OWNER IMMUNITY — Block Slowness & Mining Fatigue
    // ═════════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onOwnerPotionEffect(EntityPotionEffectEvent event) {
        if (!(event.getEntity() instanceof Player owner)) return;
        if (!stateManager.hasDomain(owner.getUniqueId())) return;

        if (event.getAction() != EntityPotionEffectEvent.Action.ADDED
                && event.getAction() != EntityPotionEffectEvent.Action.CHANGED) return;

        if (event.getNewEffect() == null) return;
        PotionEffectType type = event.getNewEffect().getType();

        if (type.equals(PotionEffectType.SLOWNESS)
                || type.equals(PotionEffectType.MINING_FATIGUE)) {
            event.setCancelled(true);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // CLEANUP — Logout & Death
    // ═════════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (stateManager.hasDomain(player.getUniqueId())) {
            DomainManager.endDomain(player, plugin, stateManager);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (stateManager.hasDomain(player.getUniqueId())) {
            DomainManager.endDomain(player, plugin, stateManager);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helper
    // ─────────────────────────────────────────────────────────────────────────

    private static boolean isSelfDamage(Player victim, Entity damager) {
        if (damager == null) return false;
        if (damager instanceof Player p && p.equals(victim)) return true;
        if (damager instanceof org.bukkit.entity.Projectile proj) {
            if (proj.getShooter() instanceof Player p && p.equals(victim)) return true;
        }
        return false;
    }
}

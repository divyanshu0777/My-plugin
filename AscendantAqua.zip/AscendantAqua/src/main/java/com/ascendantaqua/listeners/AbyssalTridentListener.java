package com.ascendantaqua.listeners;

import com.ascendantaqua.AscendantAquaPlugin;
import com.ascendantaqua.state.AscendantAquaStateManager;
import com.ascendantaqua.util.AbyssalTridentFactory;
import com.ascendantaqua.util.DomainEffectUtil;
import org.bukkit.Location;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Collection;
import java.util.UUID;

/**
 * Handles events fired when the Abyssal Trident projectile hits something.
 *
 * <h2>On trident impact (ProjectileHitEvent):</h2>
 * <ol>
 *   <li>Verifies the trident belongs to an active Poseidon's Wrath owner.</li>
 *   <li>Summons a lightning bolt at the impact location (visual; no fire).</li>
 *   <li>Spawns a water explosion particle burst.</li>
 *   <li>Pulls all nearby enemies within 6 blocks toward the owner.</li>
 *   <li>The trident is recalled instantly by Loyalty – no further action needed.</li>
 * </ol>
 *
 * <h2>On trident melee / projectile damage (EntityDamageByEntityEvent):</h2>
 * <ol>
 *   <li>Owner immunity: if the damaged entity is the owner, cancel damage.</li>
 *   <li>Depths Judgment: if the hit entity is execute-marked, multiply event
 *       damage by ×1.5 (50 % extra).</li>
 *   <li>Applies the trident piercing by not cancelling the event
 *       (Bukkit handles multi-entity pierce separately via Impaling).</li>
 * </ol>
 */
public class AbyssalTridentListener implements Listener {

    /** Blast radius for the water explosion on trident impact. */
    private static final double IMPACT_PULL_RADIUS = 6.0;

    private final AscendantAquaPlugin       plugin;
    private final AscendantAquaStateManager stateManager;

    public AbyssalTridentListener(AscendantAquaPlugin plugin,
                                  AscendantAquaStateManager stateManager) {
        this.plugin       = plugin;
        this.stateManager = stateManager;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Trident projectile hit
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Fires when any projectile (including tridents) hits a block or entity.
     *
     * <p>We specifically intercept Trident projectiles whose shooter is a Player
     * who (a) has an active domain and (b) is holding the Abyssal Trident.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTridentHit(ProjectileHitEvent event) {
        // ── Only interested in Trident projectiles ────────────────────────────
        if (!(event.getEntity() instanceof Trident trident)) {
            return;
        }

        // ── Shooter must be a Player ──────────────────────────────────────────
        if (!(trident.getShooter() instanceof Player owner)) {
            return;
        }

        // ── Owner must have an active domain ──────────────────────────────────
        if (!stateManager.hasDomain(owner.getUniqueId())) {
            return;
        }

        // ── Confirm the item is the Abyssal Trident via PDC ──────────────────
        ItemStack hand = owner.getInventory().getItemInMainHand();
        if (!AbyssalTridentFactory.isAbyssalTrident(hand)) {
            return;
        }

        Location impactLoc = trident.getLocation();

        // ── 1. Lightning (cosmetic – strikeLightningEffect = no fire, no damage) ──
        owner.getWorld().strikeLightningEffect(impactLoc);

        // ── 2. Water explosion particles ──────────────────────────────────────
        DomainEffectUtil.spawnTridentImpact(impactLoc);

        // ── 3. Pull all enemies within IMPACT_PULL_RADIUS toward the owner ────
        Collection<Entity> nearby = owner.getWorld().getNearbyEntities(
                impactLoc, IMPACT_PULL_RADIUS, IMPACT_PULL_RADIUS, IMPACT_PULL_RADIUS);

        for (Entity entity : nearby) {
            if (!DomainEffectUtil.isValidTarget(entity, owner)) {
                continue;
            }
            // Pull 3 blocks toward the owner (spec: "pulled directly toward the owner")
            DomainEffectUtil.pullToward(entity, owner.getLocation(), 3.0, owner);
        }

        // Trident recall is handled by Loyalty III enchantment on the item –
        // no custom recall logic is needed.
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Trident damage event (owner immunity + execute-mark damage amplification)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Intercepts damage dealt by entities wielding / throwing the Abyssal Trident.
     *
     * <p><b>Owner immunity (CRITICAL):</b> if the damaged entity IS the owner,
     * the event is cancelled unconditionally.
     *
     * <p><b>Depths Judgment:</b> if the hit entity is execute-marked, deal
     * +50 % of the base event damage on top (as true damage to avoid stacking
     * amplification in the Bukkit damage modifiers).
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAbyssalTridentDamage(EntityDamageByEntityEvent event) {

        // ── Determine who dealt the damage ────────────────────────────────────
        Player owner = resolveOwner(event.getDamager());
        if (owner == null) {
            return; // not from an Abyssal Trident owner
        }

        // ── Confirm owner has an active domain ────────────────────────────────
        if (!stateManager.hasDomain(owner.getUniqueId())) {
            return;
        }

        // ── Confirm the weapon is the Abyssal Trident ─────────────────────────
        ItemStack hand = owner.getInventory().getItemInMainHand();
        if (!AbyssalTridentFactory.isAbyssalTrident(hand)) {
            return;
        }

        Entity damagedEntity = event.getEntity();

        // ── OWNER IMMUNITY: cancel damage if owner hit themselves ─────────────
        if (damagedEntity instanceof Player p && p.equals(owner)) {
            event.setCancelled(true);
            return;
        }

        // ── Depths Judgment: +50 % true damage if execute-marked ─────────────
        UUID targetUUID = damagedEntity.getUniqueId();
        if (stateManager.isExecuteMarked(targetUUID)
                && damagedEntity instanceof LivingEntity living) {

            double baseDamage  = event.getDamage();
            double bonusDamage = baseDamage * 0.50; // 50 % extra, as true damage

            // Schedule the bonus damage 1 tick later so it applies AFTER the
            // normal damage event resolves (avoids double-killing edge cases).
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!living.isDead() && living.isValid()) {
                    DomainEffectUtil.dealTrueDamage(living, bonusDamage / 2.0, owner);
                    // divide by 2.0 because dealTrueDamage takes hearts (×2 HP internally)
                }
            }, 1L);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Given the damager entity from {@link EntityDamageByEntityEvent}, returns
     * the {@link Player} owner if:
     * <ul>
     *   <li>The damager is a Player directly (melee trident attack), or</li>
     *   <li>The damager is a Trident projectile whose shooter is a Player.</li>
     * </ul>
     * Returns {@code null} in all other cases.
     */
    private Player resolveOwner(Entity damager) {
        if (damager instanceof Player p) {
            return p;
        }
        if (damager instanceof Trident trident) {
            if (trident.getShooter() instanceof Player p) {
                return p;
            }
        }
        return null;
    }
}

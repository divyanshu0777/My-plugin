package com.ascendantaqua.listeners;

import com.ascendantaqua.AscendantAquaPlugin;
import com.ascendantaqua.state.AscendantAquaStateManager;
import com.ascendantaqua.util.AbyssalTridentFactory;
import com.ascendantaqua.util.DomainEffectUtil;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Collection;
import java.util.UUID;

/**
 * Handles Abyssal Trident projectile impact and damage amplification.
 *
 * FIXES vs previous version:
 * - getItem() on ProjectileHitEvent replaced with shooter's inventory check
 *   (more reliable in Paper 1.21).
 * - Execute-bonus damage calculation corrected: dealTrueDamage takes hearts,
 *   so bonus = baseDamageHP * 0.5 / 2.0 = baseDamageHP * 0.25 (in hearts).
 *   This gives exactly 50% extra damage on top of the normal hit.
 */
public class AbyssalTridentListener implements Listener {

    private static final double IMPACT_PULL_RADIUS = 6.0;

    private final AscendantAquaPlugin       plugin;
    private final AscendantAquaStateManager stateManager;

    public AbyssalTridentListener(AscendantAquaPlugin plugin,
                                  AscendantAquaStateManager stateManager) {
        this.plugin       = plugin;
        this.stateManager = stateManager;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Trident impact — lightning + water explosion + pull
    // ─────────────────────────────────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTridentHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Trident trident)) return;
        if (!(trident.getShooter() instanceof Player owner)) return;
        if (!stateManager.hasDomain(owner.getUniqueId())) return;

        // Confirm the trident in hand is the Abyssal Trident via PDC
        ItemStack hand = owner.getInventory().getItemInMainHand();
        if (!AbyssalTridentFactory.isAbyssalTrident(hand)) return;

        var impactLoc = trident.getLocation();

        // 1. Cosmetic lightning (no damage, no fire)
        owner.getWorld().strikeLightningEffect(impactLoc);

        // 2. Water explosion particles
        DomainEffectUtil.spawnTridentImpact(impactLoc);

        // 3. Pull all nearby enemies toward owner
        Collection<Entity> nearby = owner.getWorld().getNearbyEntities(
                impactLoc, IMPACT_PULL_RADIUS, IMPACT_PULL_RADIUS, IMPACT_PULL_RADIUS);

        for (Entity entity : nearby) {
            if (!DomainEffectUtil.isValidTarget(entity, owner)) continue;
            DomainEffectUtil.pullToward(entity, owner.getLocation(), 3.0, owner);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Trident damage — owner immunity + Depths Judgment +50%
    // ─────────────────────────────────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onAbyssalTridentDamage(EntityDamageByEntityEvent event) {

        Player owner = resolveOwner(event.getDamager());
        if (owner == null) return;
        if (!stateManager.hasDomain(owner.getUniqueId())) return;

        ItemStack hand = owner.getInventory().getItemInMainHand();
        if (!AbyssalTridentFactory.isAbyssalTrident(hand)) return;

        Entity damaged = event.getEntity();

        // OWNER IMMUNITY — cancel if owner somehow hit themselves
        if (damaged instanceof Player p && p.equals(owner)) {
            event.setCancelled(true);
            return;
        }

        // DEPTHS JUDGMENT — +50% true damage bonus
        UUID targetUUID = damaged.getUniqueId();
        if (stateManager.isExecuteMarked(targetUUID)
                && damaged instanceof LivingEntity living) {

            // baseDamage is in HP units; convert to hearts (÷2) for dealTrueDamage
            double baseDamageHP  = event.getDamage();        // Bukkit HP units
            double bonusHearts   = (baseDamageHP * 0.5) / 2.0; // 50% extra, in hearts

            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!living.isDead() && living.isValid()) {
                    DomainEffectUtil.dealTrueDamage(living, bonusHearts, owner);
                }
            }, 1L);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helper
    // ─────────────────────────────────────────────────────────────────────────

    private static Player resolveOwner(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Trident t && t.getShooter() instanceof Player p) return p;
        return null;
    }
}

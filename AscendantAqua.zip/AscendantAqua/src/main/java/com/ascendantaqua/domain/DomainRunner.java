package com.ascendantaqua.domain;

import com.ascendantaqua.AscendantAquaPlugin;
import com.ascendantaqua.state.ActiveDomain;
import com.ascendantaqua.state.AscendantAquaStateManager;
import com.ascendantaqua.util.DomainEffectUtil;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * The heartbeat of Poseidon's Wrath.
 *
 * <p>Runs every {@value #TICK_INTERVAL} ticks (4 ticks = 200 ms).
 *
 * <p>Each invocation:
 * <ol>
 *   <li>Reapplies passive owner buffs.</li>
 *   <li>Collects all valid enemies inside the 20-block radius.</li>
 *   <li>Applies Ocean Domain aura effects (Slowness III, Mining Fatigue II,
 *       fire extinguish, health-regen disable, pull toward center).</li>
 *   <li>Every 30 ticks executes the Crushing Vortex on a random enemy.</li>
 *   <li>Checks every enemy for the Depths Judgment execute threshold.</li>
 *   <li>Spawns ambient domain particles.</li>
 * </ol>
 *
 * <p><b>Owner immunity is enforced on every branch</b> by explicit
 * {@code target.equals(owner)} checks and by delegating all damage/pull
 * through {@link DomainEffectUtil}, which also checks the owner.
 */
public class DomainRunner extends BukkitRunnable {

    // ── Timing constants ──────────────────────────────────────────────────────
    /** How often this runnable fires (ticks). */
    private static final int TICK_INTERVAL  = 4;
    /** Ticks between Crushing Vortex activations (30 ticks = 1.5 seconds). */
    private static final int VORTEX_INTERVAL = 30;
    /** Domain radius (blocks). */
    private static final double DOMAIN_RADIUS = 20.0;
    /** Execute health threshold (40 % of max HP). */
    private static final double EXECUTE_THRESHOLD = 0.40;

    // ── Constants for potion durations ────────────────────────────────────────
    /** We re-apply short-duration effects every tick so they appear permanent. */
    private static final int EFFECT_DURATION_TICKS = 60; // 3 seconds – always refreshed

    // ── References ────────────────────────────────────────────────────────────
    private final AscendantAquaPlugin    plugin;
    private final AscendantAquaStateManager stateManager;
    private final ActiveDomain           domain;
    private final Player                 owner;
    private final Random                 rng = new Random();

    // ── Internal tick counter (relative to this runner's start) ───────────────
    private int localTicks = 0;

    // ─────────────────────────────────────────────────────────────────────────

    public DomainRunner(AscendantAquaPlugin plugin,
                        AscendantAquaStateManager stateManager,
                        ActiveDomain domain) {
        this.plugin       = plugin;
        this.stateManager = stateManager;
        this.domain       = domain;
        this.owner        = domain.getOwner();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Main loop
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public void run() {
        // ── Sanity: verify owner and domain are still valid ───────────────────
        if (!owner.isOnline() || owner.isDead()) {
            DomainManager.endDomain(owner, plugin, stateManager);
            return;
        }

        localTicks += TICK_INTERVAL;
        domain.advanceTicks(TICK_INTERVAL);

        Location center = owner.getLocation();
        List<LivingEntity> enemies = getEnemiesInRadius(center);

        // ── 1. Owner passive buffs ────────────────────────────────────────────
        applyOwnerPassiveEffects();

        // ── 2. Ambient particles ──────────────────────────────────────────────
        DomainEffectUtil.spawnDomainAmbient(center);

        // ── 3. Ocean Domain aura on each enemy ───────────────────────────────
        for (LivingEntity enemy : enemies) {
            applyDomainAura(enemy, center);
        }

        // ── 4. Crushing Vortex (every 30 ticks) ──────────────────────────────
        if (!enemies.isEmpty() && (localTicks % VORTEX_INTERVAL == 0)) {
            LivingEntity vortexTarget = enemies.get(rng.nextInt(enemies.size()));
            activateCrushingVortex(vortexTarget);
        }

        // ── 5. Depths Judgment execute checks ────────────────────────────────
        for (LivingEntity enemy : enemies) {
            checkExecuteThreshold(enemy);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Owner passive buffs
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Refreshes the owner's passive potion effects so they appear permanent
     * for the full duration of Poseidon's Wrath.
     *
     * <ul>
     *   <li>Water Breathing (Infinite)</li>
     *   <li>Night Vision</li>
     *   <li>Dolphin's Grace (Fast Swim)</li>
     *   <li>Haste II</li>
     * </ul>
     */
    private void applyOwnerPassiveEffects() {
        applyEffect(owner, PotionEffectType.WATER_BREATHING,  EFFECT_DURATION_TICKS, 0);
        applyEffect(owner, PotionEffectType.NIGHT_VISION,     EFFECT_DURATION_TICKS, 0);
        applyEffect(owner, PotionEffectType.DOLPHINS_GRACE,   EFFECT_DURATION_TICKS, 0);
        applyEffect(owner, PotionEffectType.HASTE,            EFFECT_DURATION_TICKS, 1); // Haste II = amplifier 1
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Ocean Domain aura per-enemy
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Applies all Ocean Domain aura effects to a single enemy:
     * <ul>
     *   <li>Slowness III</li>
     *   <li>Mining Fatigue II</li>
     *   <li>Extinguish fire ticks</li>
     *   <li>Disable health regeneration</li>
     *   <li>Constant pull toward owner</li>
     * </ul>
     *
     * <p>The owner is NEVER passed here (filtered in {@link #getEnemiesInRadius}).
     */
    private void applyDomainAura(LivingEntity enemy, Location center) {
        // ── Debuffs ────────────────────────────────────────────────────────────
        applyEffect(enemy, PotionEffectType.SLOWNESS,         EFFECT_DURATION_TICKS, 2); // Slowness III = amp 2
        applyEffect(enemy, PotionEffectType.MINING_FATIGUE,   EFFECT_DURATION_TICKS, 1); // Mining Fatigue II = amp 1

        // ── Extinguish fire ────────────────────────────────────────────────────
        if (enemy.getFireTicks() > 0) {
            enemy.setFireTicks(0);
        }

        // ── Disable health regen: remove REGENERATION effect if present ────────
        if (enemy.hasPotionEffect(PotionEffectType.REGENERATION)) {
            enemy.removePotionEffect(PotionEffectType.REGENERATION);
        }

        // ── Constant gravitational pull (1 block per iteration) ───────────────
        // Owner immunity is enforced inside pullToward() as well, but the
        // owner never reaches this branch anyway.
        DomainEffectUtil.pullToward(enemy, center, 1.0, owner);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Crushing Vortex
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Targets one random enemy with the Crushing Vortex:
     * <ol>
     *   <li>Spawns heavy water vortex particle effect at their location.</li>
     *   <li>Stuns them for 1 second (velocity zeroed, re-zeroed after 20 ticks).</li>
     *   <li>Deals 4 hearts of flat true damage.</li>
     * </ol>
     */
    private void activateCrushingVortex(LivingEntity target) {
        // Particle effect
        DomainEffectUtil.spawnVortexEffect(target.getLocation());

        // Stun: zero velocity now, and again after 20 ticks (1 second) to
        // prevent the entity from immediately resuming movement.
        DomainEffectUtil.applyStun(target, owner);

        UUID targetUUID = target.getUniqueId();
        new BukkitRunnable() {
            @Override
            public void run() {
                // Re-check validity before the delayed stun-release
                Entity ent = plugin.getServer().getEntity(targetUUID);
                if (ent instanceof LivingEntity living && !living.isDead()) {
                    DomainEffectUtil.applyStun(living, owner);
                }
            }
        }.runTaskLater(plugin, 20L); // re-zero velocity at the 1-second mark

        // True damage: 4 hearts = 8 HP
        DomainEffectUtil.dealTrueDamage(target, 4.0, owner);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Depths Judgment (execute phase)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Checks whether the given enemy should enter the execute phase.
     *
     * <p>Conditions for entering Depths Judgment:
     * <ul>
     *   <li>Enemy's current HP is below 40 % of their max HP.</li>
     *   <li>They are not already marked.</li>
     * </ul>
     *
     * <p>Effects applied on entering:
     * <ul>
     *   <li>Glowing effect (indefinite duration while HP stays below threshold).</li>
     *   <li>Movement locked (velocity zeroed per tick).</li>
     *   <li>50 % extra trident damage – tracked via the execute-mark set in
     *       {@link AscendantAquaStateManager}.</li>
     * </ul>
     *
     * <p>The +50 % damage multiplier is applied in the trident hit listener
     * {@link com.ascendantaqua.listeners.AbyssalTridentListener}.
     */
    private void checkExecuteThreshold(LivingEntity enemy) {
        if (enemy.isDead()) {
            stateManager.unmarkExecute(enemy.getUniqueId());
            return;
        }

        AttributeInstance maxHpAttr = enemy.getAttribute(Attribute.MAX_HEALTH);
        if (maxHpAttr == null) return;

        double maxHp      = maxHpAttr.getValue();
        double currentHp  = enemy.getHealth();
        double threshold  = maxHp * EXECUTE_THRESHOLD;

        boolean belowThreshold = currentHp < threshold;
        boolean alreadyMarked  = stateManager.isExecuteMarked(enemy.getUniqueId());

        if (belowThreshold && !alreadyMarked) {
            // ── Enter execute phase ────────────────────────────────────────────
            stateManager.markExecute(enemy.getUniqueId());

            // Glowing (amplifier 0; duration is kept refreshed below)
            applyEffect(enemy, PotionEffectType.GLOWING, EFFECT_DURATION_TICKS, 0);

            // Notify owner
            owner.sendMessage("§b§l[Depths Judgment] §f" +
                    "§e" + getDisplayName(enemy) + " §7is now marked for execution!");

        } else if (belowThreshold && alreadyMarked) {
            // ── Refresh effects while still below threshold ────────────────────
            applyEffect(enemy, PotionEffectType.GLOWING, EFFECT_DURATION_TICKS, 0);

            // Lock mobility: zero velocity every tick so they cannot move
            DomainEffectUtil.applyStun(enemy, owner);

        } else if (!belowThreshold && alreadyMarked) {
            // ── Enemy healed above threshold – remove execute mark ─────────────
            stateManager.unmarkExecute(enemy.getUniqueId());
            enemy.removePotionEffect(PotionEffectType.GLOWING);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Returns all {@link LivingEntity} instances within {@value #DOMAIN_RADIUS}
     * blocks of {@code center} that are valid hostile targets (not the owner,
     * not dead, not invalid).
     */
    private List<LivingEntity> getEnemiesInRadius(Location center) {
        List<LivingEntity> result = new ArrayList<>();
        for (Entity entity : owner.getWorld().getNearbyEntities(center, DOMAIN_RADIUS, DOMAIN_RADIUS, DOMAIN_RADIUS)) {
            if (DomainEffectUtil.isValidTarget(entity, owner)) {
                result.add((LivingEntity) entity);
            }
        }
        return result;
    }

    /**
     * Applies a {@link PotionEffect} with the "force" flag, overriding any
     * shorter existing effect of the same type.
     */
    private static void applyEffect(LivingEntity entity, PotionEffectType type,
                                    int durationTicks, int amplifier) {
        entity.addPotionEffect(
                new PotionEffect(type, durationTicks, amplifier,
                        true,   // ambient – subtle particles
                        false,  // showParticles – keep screen clean for the owner
                        false), // showIcon
                true            // force-override shorter existing effects
        );
    }

    /**
     * Returns a human-readable name for the entity (player name or entity type).
     */
    private static String getDisplayName(LivingEntity entity) {
        if (entity instanceof Player p) return p.getName();
        String typeName = entity.getType().name();
        // Convert ZOMBIE_VILLAGER → Zombie Villager
        String[] parts = typeName.split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!sb.isEmpty()) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0)));
            sb.append(part.substring(1).toLowerCase());
        }
        return sb.toString();
    }
}

package com.ascendantaqua.domain;

import com.ascendantaqua.AscendantAquaPlugin;
import com.ascendantaqua.state.ActiveDomain;
import com.ascendantaqua.state.AscendantAquaStateManager;
import com.ascendantaqua.util.DomainEffectUtil;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Heartbeat runnable for Poseidon's Wrath.
 * Runs every 4 ticks (200 ms).
 *
 * FIXES vs previous version:
 * - Passive effects now use ambient=false, showParticles=true so they actually
 *   SHOW on the player's screen and in the effect HUD.
 * - EFFECT_DURATION_TICKS increased to 100 (5 s) so refreshing every 200 ms
 *   keeps them permanently visible without flicker.
 * - Added plugin logger debug line on first run so we can confirm the runner starts.
 */
public class DomainRunner extends BukkitRunnable {

    // 4 ticks per iteration
    private static final int    TICK_INTERVAL    = 4;
    // Vortex fires every 30 ticks (1.5 s)
    private static final int    VORTEX_INTERVAL  = 30;
    // Domain radius
    private static final double DOMAIN_RADIUS    = 20.0;
    // Execute threshold
    private static final double EXECUTE_THRESHOLD = 0.40;
    // Effect refresh duration — longer than the refresh interval so effects never flicker
    private static final int    EFFECT_TICKS     = 100; // 5 seconds

    private final AscendantAquaPlugin       plugin;
    private final AscendantAquaStateManager stateManager;
    private final ActiveDomain              domain;
    private final Player                    owner;
    private final Random                    rng        = new Random();
    private       int                       localTicks = 0;
    private       boolean                   firstRun   = true;

    public DomainRunner(AscendantAquaPlugin plugin,
                        AscendantAquaStateManager stateManager,
                        ActiveDomain domain) {
        this.plugin       = plugin;
        this.stateManager = stateManager;
        this.domain       = domain;
        this.owner        = domain.getOwner();
    }

    @Override
    public void run() {

        // ── First-run confirmation log ────────────────────────────────────────
        if (firstRun) {
            firstRun = false;
            plugin.getLogger().info("[AA-DEBUG] DomainRunner started for " + owner.getName());
        }

        // ── Guard: stop if owner offline or dead ──────────────────────────────
        if (!owner.isOnline() || owner.isDead()) {
            DomainManager.endDomain(owner, plugin, stateManager);
            return;
        }

        localTicks += TICK_INTERVAL;
        domain.advanceTicks(TICK_INTERVAL);

        Location center = owner.getLocation();
        List<LivingEntity> enemies = getEnemiesInRadius(center);

        // 1. Owner passive buffs
        applyOwnerPassiveEffects();

        // 2. Ambient particles
        DomainEffectUtil.spawnDomainAmbient(center);

        // 3. Ocean Domain aura on each enemy
        for (LivingEntity enemy : enemies) {
            applyDomainAura(enemy, center);
        }

        // 4. Crushing Vortex every 30 ticks
        if (!enemies.isEmpty() && (localTicks % VORTEX_INTERVAL == 0)) {
            LivingEntity vortexTarget = enemies.get(rng.nextInt(enemies.size()));
            activateCrushingVortex(vortexTarget);
        }

        // 5. Depths Judgment execute check
        for (LivingEntity enemy : enemies) {
            checkExecuteThreshold(enemy);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Owner passive buffs
    // ─────────────────────────────────────────────────────────────────────────

    private void applyOwnerPassiveEffects() {
        // ambient=false, showParticles=true, showIcon=true
        // so effects appear in the player's HUD and show particles
        applyEffect(owner, PotionEffectType.WATER_BREATHING, EFFECT_TICKS, 0);
        applyEffect(owner, PotionEffectType.NIGHT_VISION,    EFFECT_TICKS, 0);
        applyEffect(owner, PotionEffectType.DOLPHINS_GRACE,  EFFECT_TICKS, 0);
        applyEffect(owner, PotionEffectType.HASTE,           EFFECT_TICKS, 1); // Haste II
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Ocean Domain aura per enemy
    // ─────────────────────────────────────────────────────────────────────────

    private void applyDomainAura(LivingEntity enemy, Location center) {
        applyEffect(enemy, PotionEffectType.SLOWNESS,       EFFECT_TICKS, 2); // Slowness III
        applyEffect(enemy, PotionEffectType.MINING_FATIGUE, EFFECT_TICKS, 1); // Mining Fatigue II

        // Extinguish fire
        if (enemy.getFireTicks() > 0) enemy.setFireTicks(0);

        // Remove regeneration
        if (enemy.hasPotionEffect(PotionEffectType.REGENERATION)) {
            enemy.removePotionEffect(PotionEffectType.REGENERATION);
        }

        // Constant pull (1 block per iteration = pulls ~1 block every 200 ms)
        DomainEffectUtil.pullToward(enemy, center, 1.0, owner);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Crushing Vortex
    // ─────────────────────────────────────────────────────────────────────────

    private void activateCrushingVortex(LivingEntity target) {
        DomainEffectUtil.spawnVortexEffect(target.getLocation());

        // Stun now
        DomainEffectUtil.applyStun(target, owner);

        // Re-stun at 1 second mark (20 ticks) to hold them in place
        UUID targetUUID = target.getUniqueId();
        new BukkitRunnable() {
            @Override
            public void run() {
                Entity ent = plugin.getServer().getEntity(targetUUID);
                if (ent instanceof LivingEntity living && !living.isDead()) {
                    DomainEffectUtil.applyStun(living, owner);
                }
            }
        }.runTaskLater(plugin, 20L);

        // True damage: 4 hearts
        DomainEffectUtil.dealTrueDamage(target, 4.0, owner);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Depths Judgment
    // ─────────────────────────────────────────────────────────────────────────

    private void checkExecuteThreshold(LivingEntity enemy) {
        if (enemy.isDead()) {
            stateManager.unmarkExecute(enemy.getUniqueId());
            return;
        }

        AttributeInstance maxHpAttr = enemy.getAttribute(Attribute.MAX_HEALTH);
        if (maxHpAttr == null) return;

        double maxHp          = maxHpAttr.getValue();
        double currentHp      = enemy.getHealth();
        boolean belowThreshold = currentHp < (maxHp * EXECUTE_THRESHOLD);
        boolean alreadyMarked  = stateManager.isExecuteMarked(enemy.getUniqueId());

        if (belowThreshold && !alreadyMarked) {
            stateManager.markExecute(enemy.getUniqueId());
            applyEffect(enemy, PotionEffectType.GLOWING, EFFECT_TICKS, 0);
            owner.sendMessage("§b§l[Depths Judgment] §e" + getDisplayName(enemy)
                    + " §7is marked for execution!");

        } else if (belowThreshold) {
            // Refresh Glowing and lock movement
            applyEffect(enemy, PotionEffectType.GLOWING, EFFECT_TICKS, 0);
            DomainEffectUtil.applyStun(enemy, owner);

        } else if (alreadyMarked) {
            // Healed above threshold — remove mark
            stateManager.unmarkExecute(enemy.getUniqueId());
            enemy.removePotionEffect(PotionEffectType.GLOWING);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private List<LivingEntity> getEnemiesInRadius(Location center) {
        List<LivingEntity> result = new ArrayList<>();
        for (Entity entity : owner.getWorld()
                .getNearbyEntities(center, DOMAIN_RADIUS, DOMAIN_RADIUS, DOMAIN_RADIUS)) {
            if (DomainEffectUtil.isValidTarget(entity, owner)) {
                result.add((LivingEntity) entity);
            }
        }
        return result;
    }

    /**
     * Applies a potion effect with force-override.
     * ambient=false, showParticles=true, showIcon=true — so the effect
     * is always visible in the HUD and shows particle effects on the entity.
     */
    private static void applyEffect(LivingEntity entity, PotionEffectType type,
                                    int durationTicks, int amplifier) {
        entity.addPotionEffect(
                new PotionEffect(type, durationTicks, amplifier,
                        false,  // ambient = false → particles show normally
                        true,   // showParticles = true
                        true),  // showIcon = true
                true            // override existing shorter effects
        );
    }

    private static String getDisplayName(LivingEntity entity) {
        if (entity instanceof Player p) return p.getName();
        String[] parts = entity.getType().name().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (!sb.isEmpty()) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0)));
            sb.append(part.substring(1).toLowerCase());
        }
        return sb.toString();
    }
}

package com.ascendantaqua.domain;

import com.ascendantaqua.AscendantAquaPlugin;
import com.ascendantaqua.state.ActiveDomain;
import com.ascendantaqua.state.AscendantAquaStateManager;
import com.ascendantaqua.util.AbyssalTridentFactory;
import com.ascendantaqua.util.AscendantAquaItemFactory;
import com.ascendantaqua.util.DomainEffectUtil;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;

/**
 * Manages the lifecycle of Poseidon's Wrath for a single owner.
 *
 * <p>Responsibilities:
 * <ul>
 *   <li>Building and registering the {@link ActiveDomain}.</li>
 *   <li>Replacing the owner's main-hand item with the Abyssal Trident.</li>
 *   <li>Starting the {@link DomainRunner} loop.</li>
 *   <li>Scheduling the 20-second expiry task.</li>
 *   <li>Ending and cleaning up all state on expiry or forced removal.</li>
 * </ul>
 */
public final class DomainManager {

    /** Duration of Poseidon's Wrath in ticks (20 s × 20 ticks/s). */
    public static final long DOMAIN_DURATION_TICKS = 400L;
    /** Tick interval for the domain loop. */
    private static final int  DOMAIN_LOOP_TICKS     = 4;   // runs at 4-tick (200 ms) intervals
    /** Radius for the domain. */
    private static final double DOMAIN_RADIUS        = 20.0;

    private DomainManager() { /* static utility */ }

    // ─────────────────────────────────────────────────────────────────────────
    // Domain start
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Activates Poseidon's Wrath for {@code owner}:
     * <ol>
     *   <li>Saves and replaces their main-hand item with the Abyssal Trident.</li>
     *   <li>Creates and registers an {@link ActiveDomain}.</li>
     *   <li>Starts the {@link DomainRunner} repeating task.</li>
     *   <li>Schedules the 20-second expiry task.</li>
     *   <li>Records the cooldown.</li>
     *   <li>Sends the owner an activation message.</li>
     * </ol>
     */
    public static void startDomain(Player owner,
                                   AscendantAquaPlugin plugin,
                                   AscendantAquaStateManager stateManager) {

        PlayerInventory inv       = owner.getInventory();
        ItemStack       prevItem  = inv.getItemInMainHand().clone();

        // If there is no item in hand (air), treat it as null for restoration.
        if (prevItem.getType() == Material.AIR) {
            prevItem = null;
        }

        // ── Create domain state ───────────────────────────────────────────────
        ActiveDomain domain = new ActiveDomain(owner, prevItem);
        stateManager.addActiveDomain(owner.getUniqueId(), domain);

        // ── Record cooldown (starts at activation, not expiry) ────────────────
        stateManager.setCooldown(owner.getUniqueId());

        // ── Replace main hand with Abyssal Trident ────────────────────────────
        inv.setItemInMainHand(AbyssalTridentFactory.createAbyssalTrident());

        // ── Start domain loop task ────────────────────────────────────────────
        DomainRunner runner = new DomainRunner(plugin, stateManager, domain);
        BukkitTask loopTask = runner.runTaskTimer(plugin, 0L, DOMAIN_LOOP_TICKS);
        domain.setDomainLoopTask(loopTask);

        // ── Schedule 20-second expiry ─────────────────────────────────────────
        BukkitTask expiryTask = new BukkitRunnable() {
            @Override
            public void run() {
                endDomain(owner, plugin, stateManager);
            }
        }.runTaskLater(plugin, DOMAIN_DURATION_TICKS);
        domain.setExpiryTask(expiryTask);

        // ── Activation feedback ───────────────────────────────────────────────
        owner.sendMessage("§b§l✦ POSEIDON'S WRATH ACTIVATED! §7(20 seconds)");
        owner.getWorld().playSound(owner.getLocation(),
                Sound.ENTITY_ELDER_GUARDIAN_AMBIENT, 1.5f, 0.5f);
        owner.getWorld().playSound(owner.getLocation(),
                Sound.WEATHER_RAIN,                  1.5f, 0.7f);
        owner.getWorld().playSound(owner.getLocation(),
                Sound.BLOCK_BUBBLE_COLUMN_UPWARDS_AMBIENT, 1.5f, 0.8f);

        // Particle burst at activation
        DomainEffectUtil.spawnWaterExplosion(owner.getLocation());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Domain end
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Ends Poseidon's Wrath for {@code owner} and restores all modified state:
     * <ol>
     *   <li>Cancels all scheduled tasks.</li>
     *   <li>Removes the domain from the state manager.</li>
     *   <li>Restores the owner's main-hand item.</li>
     *   <li>Removes passive buff effects.</li>
     *   <li>Un-marks all execute-phase enemies and removes their Glowing effect.</li>
     *   <li>Sends an expiry message.</li>
     * </ol>
     *
     * <p>Safe to call even if no domain is currently active (no-op in that case).
     */
    public static void endDomain(Player owner,
                                  AscendantAquaPlugin plugin,
                                  AscendantAquaStateManager stateManager) {

        ActiveDomain domain = stateManager.getActiveDomain(owner.getUniqueId());
        if (domain == null) {
            return; // already ended or never started
        }

        // ── Cancel tasks ──────────────────────────────────────────────────────
        domain.cancelAllTasks();

        // ── Remove domain from state ──────────────────────────────────────────
        stateManager.removeDomain(owner.getUniqueId());

        // ── Restore main-hand item ────────────────────────────────────────────
        if (owner.isOnline()) {
            PlayerInventory inv = owner.getInventory();
            ItemStack currentHand = inv.getItemInMainHand();

            // Only restore if the trident is still there (owner might have
            // swapped it away manually; we don't take their real items).
            if (AbyssalTridentFactory.isAbyssalTrident(currentHand)) {
                ItemStack restoredItem = domain.getPreviousMainHandItem();
                inv.setItemInMainHand(restoredItem != null ? restoredItem : new ItemStack(Material.AIR));
            }

            // ── Remove owner passive buffs ─────────────────────────────────────
            owner.removePotionEffect(PotionEffectType.WATER_BREATHING);
            owner.removePotionEffect(PotionEffectType.NIGHT_VISION);
            owner.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
            owner.removePotionEffect(PotionEffectType.HASTE);

            // ── Expiry message ─────────────────────────────────────────────────
            owner.sendMessage("§9§l✦ Poseidon's Wrath §7has faded. §8(Cooldown: 240s)");
            owner.getWorld().playSound(owner.getLocation(),
                    Sound.BLOCK_BUBBLE_COLUMN_WHIRLPOOL_AMBIENT, 1.2f, 0.6f);
        }

        // ── Clean up execute-marked entities nearby ───────────────────────────
        // We must iterate all loaded entities, because the owner may have moved.
        // For performance, only check entities in the world the domain was active in.
        if (owner.isOnline()) {
            List<Entity> nearbyAll = new ArrayList<>(
                    owner.getWorld().getNearbyEntities(owner.getLocation(), 30, 30, 30)
            );
            for (Entity entity : nearbyAll) {
                if (stateManager.isExecuteMarked(entity.getUniqueId())) {
                    stateManager.unmarkExecute(entity.getUniqueId());
                    if (entity instanceof LivingEntity living) {
                        living.removePotionEffect(PotionEffectType.GLOWING);
                    }
                }
            }
        }
    }
}

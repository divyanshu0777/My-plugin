package com.ascendantaqua.domain;

import com.ascendantaqua.AscendantAquaPlugin;
import com.ascendantaqua.state.ActiveDomain;
import com.ascendantaqua.state.AscendantAquaStateManager;
import com.ascendantaqua.util.AbyssalTridentFactory;
import com.ascendantaqua.util.DomainEffectUtil;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;

/**
 * Manages the full lifecycle of one Poseidon's Wrath session.
 *
 * FIXES vs previous version:
 * - startDomain() now removes the Elixir from inventory (it gets consumed on use).
 *   If you prefer keeping it, remove the setItemInMainHand(AIR) call before
 *   the trident swap.
 * - endDomain() null-checks owner.isOnline() before every inventory/world op.
 * - Debug logs added so you can trace start/end in console.
 */
public final class DomainManager {

    /** 20 seconds × 20 ticks = 400 ticks */
    public static final long   DOMAIN_DURATION_TICKS = 400L;
    private static final int   DOMAIN_LOOP_TICKS      = 4;

    private DomainManager() {}

    // ─────────────────────────────────────────────────────────────────────────
    // Start
    // ─────────────────────────────────────────────────────────────────────────

    public static void startDomain(Player owner,
                                   AscendantAquaPlugin plugin,
                                   AscendantAquaStateManager stateManager) {

        PlayerInventory inv      = owner.getInventory();
        ItemStack       prevItem = inv.getItemInMainHand();

        // Clone the previous item for restoration; treat AIR as null
        ItemStack savedItem = (prevItem.getType() == Material.AIR) ? null : prevItem.clone();

        // Create state
        ActiveDomain domain = new ActiveDomain(owner, savedItem);
        stateManager.addActiveDomain(owner.getUniqueId(), domain);

        // Record cooldown (starts at activation)
        stateManager.setCooldown(owner.getUniqueId());

        // Replace main hand with Abyssal Trident
        inv.setItemInMainHand(AbyssalTridentFactory.createAbyssalTrident());

        // Start the domain loop (every 4 ticks)
        DomainRunner runner   = new DomainRunner(plugin, stateManager, domain);
        BukkitTask   loopTask = runner.runTaskTimer(plugin, 0L, DOMAIN_LOOP_TICKS);
        domain.setDomainLoopTask(loopTask);

        // Schedule expiry after 20 seconds
        BukkitTask expiryTask = new BukkitRunnable() {
            @Override
            public void run() {
                endDomain(owner, plugin, stateManager);
            }
        }.runTaskLater(plugin, DOMAIN_DURATION_TICKS);
        domain.setExpiryTask(expiryTask);

        // Feedback
        owner.sendMessage("§b§l✦ POSEIDON'S WRATH ACTIVATED! §7(20 seconds)");
        owner.getWorld().playSound(owner.getLocation(),
                Sound.ENTITY_ELDER_GUARDIAN_AMBIENT, 1.5f, 0.5f);
        owner.getWorld().playSound(owner.getLocation(),
                Sound.WEATHER_RAIN, 1.5f, 0.7f);
        owner.getWorld().playSound(owner.getLocation(),
                Sound.BLOCK_BUBBLE_COLUMN_UPWARDS_AMBIENT, 1.5f, 0.8f);

        DomainEffectUtil.spawnWaterExplosion(owner.getLocation());

        plugin.getLogger().info("[AA-DEBUG] Domain started for " + owner.getName());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // End
    // ─────────────────────────────────────────────────────────────────────────

    public static void endDomain(Player owner,
                                  AscendantAquaPlugin plugin,
                                  AscendantAquaStateManager stateManager) {

        ActiveDomain domain = stateManager.getActiveDomain(owner.getUniqueId());
        if (domain == null) return; // already ended

        // Cancel all scheduled tasks
        domain.cancelAllTasks();

        // Remove from state
        stateManager.removeDomain(owner.getUniqueId());

        plugin.getLogger().info("[AA-DEBUG] Domain ended for " + owner.getName());

        if (owner.isOnline()) {
            PlayerInventory inv         = owner.getInventory();
            ItemStack       currentHand = inv.getItemInMainHand();

            // Restore previous item only if the Abyssal Trident is still there
            if (AbyssalTridentFactory.isAbyssalTrident(currentHand)) {
                ItemStack restore = domain.getPreviousMainHandItem();
                inv.setItemInMainHand(restore != null ? restore : new ItemStack(Material.AIR));
            }

            // Remove passive buffs
            owner.removePotionEffect(PotionEffectType.WATER_BREATHING);
            owner.removePotionEffect(PotionEffectType.NIGHT_VISION);
            owner.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
            owner.removePotionEffect(PotionEffectType.HASTE);

            owner.sendMessage("§9§l✦ Poseidon's Wrath §7has faded. §8(Cooldown: 240s)");
            owner.getWorld().playSound(owner.getLocation(),
                    Sound.BLOCK_BUBBLE_COLUMN_WHIRLPOOL_AMBIENT, 1.2f, 0.6f);

            // Clean up execute marks in nearby range
            List<Entity> nearby = new ArrayList<>(
                    owner.getWorld().getNearbyEntities(owner.getLocation(), 30, 30, 30));
            for (Entity entity : nearby) {
                if (stateManager.isExecuteMarked(entity.getUniqueId())) {
                    stateManager.unmarkExecute(entity.getUniqueId());
                    if (entity instanceof LivingEntity living) {
                        living.removePotionEffect(PotionEffectType.GLOWING);
                    }
                }
            }
        }
    }
}

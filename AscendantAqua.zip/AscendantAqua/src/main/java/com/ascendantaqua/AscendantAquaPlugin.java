package com.ascendantaqua;

import com.ascendantaqua.commands.AscendantAquaCommand;
import com.ascendantaqua.listeners.AscendantAquaListener;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * AscendantAqua – Ultimate Ability Plugin
 * Target: Paper/Spigot 1.21.1, Java 21
 *
 * Registration instructions
 * ─────────────────────────
 * plugin.yml must declare:
 *
 *   name: AscendantAqua
 *   version: 1.0.0
 *   main: com.ascendantaqua.AscendantAquaPlugin
 *   api-version: '1.21'
 *   commands:
 *     ascendantaqua:
 *       description: Admin command for the Ascendant Aqua ability.
 *       usage: /ascendantaqua give <player>
 *       permission: ascendantaqua.admin
 *   permissions:
 *     ascendantaqua.admin:
 *       description: Allows giving the Ascendant Elixir.
 *       default: op
 */
public class AscendantAquaPlugin extends JavaPlugin {

    // Singleton accessor – safe because the plugin is always loaded on the
    // main thread before any listener or command can run.
    private static AscendantAquaPlugin instance;

    @Override
    public void onEnable() {
        instance = this;

        // ── Listener ─────────────────────────────────────────────────────────
        AscendantAquaListener listener = new AscendantAquaListener(this);
        getServer().getPluginManager().registerEvents(listener, this);

        // ── Command executor ─────────────────────────────────────────────────
        AscendantAquaCommand commandExecutor = new AscendantAquaCommand(this);
        //noinspection DataFlowIssue  – the command is always declared in plugin.yml
        getCommand("ascendantaqua").setExecutor(commandExecutor);
        getCommand("ascendantaqua").setTabCompleter(commandExecutor);

        getLogger().info("[AscendantAqua] Plugin enabled successfully.");
    }

    @Override
    public void onDisable() {
        // Cancel every pending BukkitTask that was scheduled by active domains
        // so they do not fire after the plugin is torn down.
        getServer().getScheduler().cancelTasks(this);
        getLogger().info("[AscendantAqua] Plugin disabled. All tasks cancelled.");
    }

    /** @return the running plugin instance. */
    public static AscendantAquaPlugin getInstance() {
        return instance;
    }
}

package com.ascendantaqua;

import com.ascendantaqua.commands.AscendantAquaCommand;
import com.ascendantaqua.listeners.AbyssalTridentListener;
import com.ascendantaqua.listeners.AscendantAquaListener;
import com.ascendantaqua.state.AscendantAquaStateManager;

import org.bukkit.plugin.java.JavaPlugin;

/**
 * Main plugin class — AscendantAqua (Paper 1.21.1 / Java 21)
 *
 * Registration:
 *   - Events: AscendantAquaListener + AbyssalTridentListener
 *   - Command: /ascendantaqua  →  AscendantAquaCommand
 */
public class AscendantAquaPlugin extends JavaPlugin {

    private static AscendantAquaPlugin instance;

    @Override
    public void onEnable() {
        instance = this;

        AscendantAquaStateManager stateManager = AscendantAquaStateManager.getInstance();

        // ── Register listeners ────────────────────────────────────────────────
        getServer().getPluginManager()
                .registerEvents(new AscendantAquaListener(this), this);
        getServer().getPluginManager()
                .registerEvents(new AbyssalTridentListener(this, stateManager), this);

        // ── Register command ──────────────────────────────────────────────────
        AscendantAquaCommand cmd = new AscendantAquaCommand(this);
        //noinspection DataFlowIssue
        getCommand("ascendantaqua").setExecutor(cmd);
        getCommand("ascendantaqua").setTabCompleter(cmd);

        getLogger().info("[AscendantAqua] Plugin enabled! Version " + getDescription().getVersion());
    }

    @Override
    public void onDisable() {
        // Cancel every running domain task
        getServer().getScheduler().cancelTasks(this);
        AscendantAquaStateManager.getInstance().shutdown();
        getLogger().info("[AscendantAqua] Plugin disabled.");
    }

    public static AscendantAquaPlugin getInstance() {
        return instance;
    }
}

package com.ascendantaqua.state;

import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Central state store for the AscendantAqua plugin.
 *
 * <p>All maps use {@link UUID} keys so that they remain valid even if a player
 * disconnects and reconnects (though the domain itself is ended on logout via
 * the listener).
 *
 * <p>Thread-safety note: Bukkit's main thread is single-threaded for game logic;
 * we use ConcurrentHashMap only as a defensive measure in case Paper's async
 * scheduler ever touches these maps.
 */
public class AscendantAquaStateManager {

    // ── Cooldown tracking ─────────────────────────────────────────────────────
    /** Maps player UUID → System.currentTimeMillis() of the last activation. */
    private final Map<UUID, Long> cooldownMap = new ConcurrentHashMap<>();

    /** Cooldown duration in milliseconds (240 seconds). */
    public static final long COOLDOWN_MILLIS = 240_000L;

    // ── Active domains ────────────────────────────────────────────────────────
    /** Maps owner UUID → their running ActiveDomain. */
    private final Map<UUID, ActiveDomain> activeDomains = new ConcurrentHashMap<>();

    // ── Execute-phase tracking ────────────────────────────────────────────────
    /**
     * Set of entity UUIDs that are currently "marked" by Depths Judgment
     * (Glowing, movement locked, +50% trident damage).
     */
    private final Set<UUID> executeMarkedEntities = Collections.newSetFromMap(new ConcurrentHashMap<>());

    // ── Singleton ─────────────────────────────────────────────────────────────
    private static final AscendantAquaStateManager INSTANCE = new AscendantAquaStateManager();

    private AscendantAquaStateManager() { /* singleton */ }

    public static AscendantAquaStateManager getInstance() {
        return INSTANCE;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Cooldown API
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * @param uuid player UUID to check.
     * @return {@code true} if this player is still on cooldown.
     */
    public boolean isOnCooldown(UUID uuid) {
        Long last = cooldownMap.get(uuid);
        if (last == null) return false;
        return (System.currentTimeMillis() - last) < COOLDOWN_MILLIS;
    }

    /**
     * Returns the remaining cooldown in whole seconds, or 0 if not on cooldown.
     */
    public long getRemainingCooldownSeconds(UUID uuid) {
        Long last = cooldownMap.get(uuid);
        if (last == null) return 0L;
        long elapsed = System.currentTimeMillis() - last;
        long remaining = COOLDOWN_MILLIS - elapsed;
        return remaining > 0 ? (remaining / 1000L) : 0L;
    }

    /**
     * Records the current timestamp as the activation time for the given player,
     * effectively starting their cooldown.
     */
    public void setCooldown(UUID uuid) {
        cooldownMap.put(uuid, System.currentTimeMillis());
    }

    /** Clears a player's cooldown (e.g. for admin commands). */
    public void clearCooldown(UUID uuid) {
        cooldownMap.remove(uuid);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Active Domain API
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Registers an {@link ActiveDomain} for the given owner.
     * If a domain already exists (e.g. a bug) it is cancelled before being replaced.
     */
    public void addActiveDomain(UUID ownerUUID, ActiveDomain domain) {
        ActiveDomain existing = activeDomains.get(ownerUUID);
        if (existing != null) {
            existing.cancelAllTasks();
        }
        activeDomains.put(ownerUUID, domain);
    }

    /** @return the running {@link ActiveDomain} for the given UUID, or {@code null}. */
    public ActiveDomain getActiveDomain(UUID ownerUUID) {
        return activeDomains.get(ownerUUID);
    }

    /** @return {@code true} if the player currently has an active domain. */
    public boolean hasDomain(UUID ownerUUID) {
        return activeDomains.containsKey(ownerUUID);
    }

    /**
     * Removes and cancels the active domain for the given player.
     * Does nothing if no domain exists.
     */
    public void removeDomain(UUID ownerUUID) {
        ActiveDomain domain = activeDomains.remove(ownerUUID);
        if (domain != null) {
            domain.cancelAllTasks();
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Execute-mark API (Depths Judgment)
    // ═════════════════════════════════════════════════════════════════════════

    /** Marks an entity as being in the execute phase (Depths Judgment). */
    public void markExecute(UUID entityUUID) {
        executeMarkedEntities.add(entityUUID);
    }

    /** Removes the execute mark from an entity. */
    public void unmarkExecute(UUID entityUUID) {
        executeMarkedEntities.remove(entityUUID);
    }

    /** @return {@code true} if the entity is currently execute-marked. */
    public boolean isExecuteMarked(UUID entityUUID) {
        return executeMarkedEntities.contains(entityUUID);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Global cleanup (called from onDisable)
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Cancels every active domain and clears all state.
     * Should only be called from {@code onDisable()}.
     */
    public void shutdown() {
        for (ActiveDomain domain : activeDomains.values()) {
            domain.cancelAllTasks();
        }
        activeDomains.clear();
        cooldownMap.clear();
        executeMarkedEntities.clear();
    }
}

package com.ascendantaqua.state;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

/**
 * Immutable-ish state record that describes one active Poseidon's Wrath session.
 *
 * <p>Lifecycle:
 * <ol>
 *   <li>Created when the owner activates the ability.</li>
 *   <li>Stored in {@link AscendantAquaStateManager} keyed by owner UUID.</li>
 *   <li>Removed (and all tasks cancelled) when the 20-second window expires
 *       or when the plugin shuts down.</li>
 * </ol>
 */
public class ActiveDomain {

    // ── Owner ─────────────────────────────────────────────────────────────────
    private final UUID   ownerUUID;
    private final Player owner;

    // ── Hit tracking for Tidal Surge (every 6th hit) ──────────────────────────
    private int physicalHitCount = 0;

    // ── Execute phase tracking: set of UUIDs currently marked (Glowing) ───────
    // Stored in StateManager, not here, for performance.

    // ── Saved previous main-hand item (restored after domain ends) ────────────
    private final ItemStack previousMainHandItem;

    // ── Scheduled tasks ───────────────────────────────────────────────────────
    /** The repeating domain loop (passive effects, domain auras, crushing vortex). */
    private BukkitTask domainLoopTask;
    /** The task that ends the domain after 20 seconds. */
    private BukkitTask expiryTask;

    // ── Wall-clock start time ─────────────────────────────────────────────────
    private final long startTimeMillis;

    // ── Ticks elapsed inside domain loop (used for vortex interval) ──────────
    private int domainTicksElapsed = 0;

    // ─────────────────────────────────────────────────────────────────────────

    public ActiveDomain(Player owner, ItemStack previousMainHandItem) {
        this.ownerUUID            = owner.getUniqueId();
        this.owner                = owner;
        this.previousMainHandItem = previousMainHandItem != null
                                    ? previousMainHandItem.clone()
                                    : null;
        this.startTimeMillis      = System.currentTimeMillis();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Accessors
    // ─────────────────────────────────────────────────────────────────────────

    public UUID getOwnerUUID()            { return ownerUUID; }
    public Player getOwner()              { return owner;     }
    public ItemStack getPreviousMainHandItem() { return previousMainHandItem; }
    public long getStartTimeMillis()      { return startTimeMillis; }
    public int getDomainTicksElapsed()    { return domainTicksElapsed; }

    // ─────────────────────────────────────────────────────────────────────────
    // Task management
    // ─────────────────────────────────────────────────────────────────────────

    public void setDomainLoopTask(BukkitTask task) { this.domainLoopTask = task; }
    public void setExpiryTask(BukkitTask task)     { this.expiryTask     = task; }

    /** Cancels all running scheduled tasks associated with this domain. */
    public void cancelAllTasks() {
        if (domainLoopTask != null && !domainLoopTask.isCancelled()) {
            domainLoopTask.cancel();
        }
        if (expiryTask != null && !expiryTask.isCancelled()) {
            expiryTask.cancel();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Hit counter (Tidal Surge)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Increments the physical hit counter.
     *
     * @return the new hit count (callers check {@code count % 6 == 0}).
     */
    public int incrementHitCount() {
        return ++physicalHitCount;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Domain tick counter
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Advances the domain tick counter by {@code ticks} and returns the new value.
     * Called from the domain loop runnable.
     */
    public int advanceTicks(int ticks) {
        domainTicksElapsed += ticks;
        return domainTicksElapsed;
    }
}

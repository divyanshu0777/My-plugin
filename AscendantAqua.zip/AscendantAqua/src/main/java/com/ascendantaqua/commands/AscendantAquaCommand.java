package com.ascendantaqua.commands;

import com.ascendantaqua.AscendantAquaPlugin;
import com.ascendantaqua.util.AscendantAquaItemFactory;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * Handles the {@code /ascendantaqua} admin command.
 *
 * <p>Registered in {@code plugin.yml}:
 * <pre>
 * commands:
 *   ascendantaqua:
 *     description: Admin command for the Ascendant Aqua ability.
 *     usage: /ascendantaqua give &lt;player&gt;
 *     permission: ascendantaqua.admin
 * </pre>
 *
 * <h2>Sub-commands</h2>
 * <ul>
 *   <li>{@code /ascendantaqua give <player>} – constructs the Ascendant Elixir
 *       with the correct PersistentDataContainer tag and safely delivers it to
 *       the target player's inventory (drops at feet if full).</li>
 * </ul>
 */
public class AscendantAquaCommand implements CommandExecutor, TabCompleter {

    private static final String PERMISSION_ADMIN = "ascendantaqua.admin";

    @SuppressWarnings("unused") // retained for future expansion
    private final AscendantAquaPlugin plugin;

    public AscendantAquaCommand(AscendantAquaPlugin plugin) {
        this.plugin = plugin;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CommandExecutor
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public boolean onCommand(CommandSender sender,
                             Command command,
                             String label,
                             String[] args) {

        // ── Permission check ──────────────────────────────────────────────────
        if (!sender.hasPermission(PERMISSION_ADMIN)) {
            sender.sendMessage("§cYou do not have permission to use this command.");
            return true;
        }

        // ── Argument validation ───────────────────────────────────────────────
        if (args.length < 2) {
            sendUsage(sender);
            return true;
        }

        String subCommand = args[0].toLowerCase();

        switch (subCommand) {
            case "give" -> handleGive(sender, args);
            default     -> sendUsage(sender);
        }

        return true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Sub-command: give
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Handles {@code /ascendantaqua give <player>}.
     *
     * <p>Steps:
     * <ol>
     *   <li>Validate that {@code args[1]} is the name of an online player.</li>
     *   <li>Construct a fresh Ascendant Elixir via
     *       {@link AscendantAquaItemFactory#createAscendantElixir()}.</li>
     *   <li>Add it to the target's inventory. If the inventory is full, drop
     *       it at the target's feet rather than silently discarding it.</li>
     * </ol>
     */
    private void handleGive(CommandSender sender, String[] args) {
        String targetName = args[1];
        Player target     = Bukkit.getPlayerExact(targetName);

        // ── Validate target is online ─────────────────────────────────────────
        if (target == null || !target.isOnline()) {
            sender.sendMessage("§cPlayer §e" + targetName + " §cis not online.");
            return;
        }

        // ── Build item with correct PDC ───────────────────────────────────────
        ItemStack elixir = AscendantAquaItemFactory.createAscendantElixir();

        // ── Safe inventory insertion ──────────────────────────────────────────
        giveItemSafely(target, elixir, sender);
    }

    /**
     * Tries to add {@code item} to {@code target}'s inventory.
     * If the inventory is full, the item is instead dropped at the target's feet.
     *
     * @param target    the recipient.
     * @param item      the item to deliver.
     * @param sender    the command issuer (for feedback messages).
     */
    private void giveItemSafely(Player target, ItemStack item, CommandSender sender) {
        // addItem returns a map of items that did NOT fit; if empty, everything was added.
        var leftover = target.getInventory().addItem(item);

        if (leftover.isEmpty()) {
            // Full delivery
            sender.sendMessage("§aSuccessfully gave §b§lAscendant Elixir §ato §e" +
                    target.getName() + "§a.");
            target.sendMessage("§b§l✦ §fYou have been given the §b§lAscendant Elixir§f!");
        } else {
            // Inventory full – drop at feet
            Location dropLoc = target.getLocation();
            for (ItemStack overflow : leftover.values()) {
                target.getWorld().dropItemNaturally(dropLoc, overflow);
            }
            sender.sendMessage("§e" + target.getName() + "§a's inventory was full. " +
                    "§b§lAscendant Elixir §adropped at their feet.");
            target.sendMessage("§e§l⚠ §fYour inventory is full! " +
                    "The §b§lAscendant Elixir §fhas been dropped at your feet.");
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Tab completion
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public List<String> onTabComplete(CommandSender sender,
                                      Command command,
                                      String alias,
                                      String[] args) {

        if (!sender.hasPermission(PERMISSION_ADMIN)) {
            return List.of();
        }

        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            // Sub-command completions
            String partial = args[0].toLowerCase();
            if ("give".startsWith(partial)) {
                completions.add("give");
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            // Player name completions for /ascendantaqua give <player>
            String partial = args[1].toLowerCase();
            for (Player online : Bukkit.getOnlinePlayers()) {
                if (online.getName().toLowerCase().startsWith(partial)) {
                    completions.add(online.getName());
                }
            }
        }

        return completions;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Usage message
    // ─────────────────────────────────────────────────────────────────────────

    private static void sendUsage(CommandSender sender) {
        sender.sendMessage("§cUsage: §f/ascendantaqua give <player>");
    }
}

package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Single centralized controller for the Speed Potion's Minecraft
 * {@link PotionEffectType#SPEED} effect.
 *
 * There are exactly two states, and this class is the ONLY code path
 * allowed to add/remove/replace the Speed Potion's SPEED effect:
 *
 *   PASSIVE_SPEED_I   — amplifier 0 (Speed I), infinite duration, while equipped.
 *   SPEED_IV_BURST    — amplifier 3 (Speed IV), fixed short duration, then
 *                        automatically reverts back to PASSIVE_SPEED_I.
 *
 * The 5-hit combo counter (2s window between valid hits) lives here too,
 * but the counter is purely a HUD/state concern — it does NOT itself apply
 * any PotionEffect. Only reaching 5 causes a transition into SPEED_IV_BURST.
 *
 * Lightning Dash's own temporary Speed IV also routes through
 * {@link #triggerExternalBurst}, so there is never a second independent
 * piece of code calling addPotionEffect(SPEED, ...) for this potion.
 */
public class SpeedEffectController {

    public static final int MAX_COMBO = 5;
    public static final int COMBO_WINDOW_TICKS = 40; // 2 seconds
    public static final int BURST_TICKS = 60;         // 3 seconds
    public static final int PASSIVE_AMPLIFIER = 0;    // Speed I
    public static final int BURST_AMPLIFIER = 3;      // Speed IV

    private final PotionSMP plugin;
    private final Map<UUID, State> states = new ConcurrentHashMap<>();

    public SpeedEffectController(PotionSMP plugin) {
        this.plugin = plugin;
    }

    private static class State {
        int comboCount = 0;
        boolean inBurst = false;
        BukkitTask comboTimeoutTask;
        BukkitTask burstEndTask;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────

    /** Called once when Speed Potion is equipped. Starts clean at Speed I, 0×⚡. */
    public void onEquip(Player player) {
        UUID uid = player.getUniqueId();
        cancelTasks(uid);
        states.put(uid, new State());
        applyEffect(player, PASSIVE_AMPLIFIER, Integer.MAX_VALUE);
    }

    /**
     * Full cleanup: unequip, death, quit, or any other potion-lifecycle end.
     * Cancels both timers, clears all state, and removes the SPEED effect
     * so no stale scheduled task can restore it later.
     */
    public void onUnequip(Player player) {
        UUID uid = player.getUniqueId();
        cancelTasks(uid);
        states.remove(uid);
        player.removePotionEffect(PotionEffectType.SPEED);
    }

    private void cancelTasks(UUID uid) {
        State st = states.get(uid);
        if (st == null) return;
        if (st.comboTimeoutTask != null) { st.comboTimeoutTask.cancel(); st.comboTimeoutTask = null; }
        if (st.burstEndTask != null) { st.burstEndTask.cancel(); st.burstEndTask = null; }
    }

    // ── Hit combo ─────────────────────────────────────────────────────────

    /**
     * Registers one valid hit (caller is responsible for hit-validity /
     * debounce checks via the existing hit-detection architecture).
     * Ignored entirely while in SPEED_IV_BURST — extra hits during the
     * burst must never restart or extend it.
     */
    public void onValidHit(Player player) {
        UUID uid = player.getUniqueId();
        State st = states.get(uid);
        if (st == null || st.inBurst) return;

        if (st.comboTimeoutTask != null) {
            st.comboTimeoutTask.cancel();
            st.comboTimeoutTask = null;
        }

        st.comboCount = Math.min(st.comboCount + 1, MAX_COMBO);

        if (st.comboCount >= MAX_COMBO) {
            enterBurst(player, st, BURST_AMPLIFIER, BURST_TICKS);
        } else {
            st.comboTimeoutTask = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                State cur = states.get(uid);
                if (cur == null || cur.inBurst) return;
                cur.comboCount = 0;
                cur.comboTimeoutTask = null;
            }, COMBO_WINDOW_TICKS);
        }
    }

    /**
     * External trigger for a Speed IV burst that isn't from the 5-hit combo
     * (currently: Lightning Dash). Goes through the exact same state
     * machine so there is still only ever one SPEED effect and one owner.
     * Does not require/consume combo progress.
     */
    public void triggerExternalBurst(Player player, int amplifier, int durationTicks) {
        UUID uid = player.getUniqueId();
        State st = states.get(uid);
        if (st == null) return; // Speed Potion must be equipped
        enterBurst(player, st, amplifier, durationTicks);
    }

    private void enterBurst(Player player, State st, int amplifier, int durationTicks) {
        UUID uid = player.getUniqueId();

        if (st.comboTimeoutTask != null) { st.comboTimeoutTask.cancel(); st.comboTimeoutTask = null; }
        if (st.burstEndTask != null) { st.burstEndTask.cancel(); st.burstEndTask = null; }

        st.comboCount = 0;
        st.inBurst = true;

        applyEffect(player, amplifier, durationTicks);

        st.burstEndTask = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            State cur = states.get(uid);
            if (cur == null) return; // already unequipped/cleaned up
            cur.inBurst = false;
            cur.burstEndTask = null;
            if (player.isOnline()) {
                applyEffect(player, PASSIVE_AMPLIFIER, Integer.MAX_VALUE);
            }
        }, durationTicks);
    }

    // ── Effect application (the ONLY place that touches PotionEffectType.SPEED) ──

    private void applyEffect(Player player, int amplifier, int durationTicks) {
        player.removePotionEffect(PotionEffectType.SPEED);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, durationTicks, amplifier, false, false));
    }

    // ── HUD accessors ─────────────────────────────────────────────────────

    public boolean isTracked(Player player) {
        return states.containsKey(player.getUniqueId());
    }

    public boolean isInBurst(Player player) {
        State st = states.get(player.getUniqueId());
        return st != null && st.inBurst;
    }

    /** Current combo count (0–5) for the HUD counter, above the Speed icon. */
    public int getComboCount(Player player) {
        State st = states.get(player.getUniqueId());
        return st == null ? 0 : st.comboCount;
    }
}

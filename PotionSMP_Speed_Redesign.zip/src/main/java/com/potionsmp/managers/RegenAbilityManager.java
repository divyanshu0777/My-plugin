package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Handles Regen Potion's active ability (Vitality Surge):
 *
 *  1. Player runs /slot1 or /slot2 (whichever has Regen equipped) -> this
 *     "arms" the ability and starts its cooldown immediately. Nothing else
 *     happens yet - no launch, no regen window.
 *  2. While armed, the player jumps normally once, lands, then jumps again
 *     (a ground-to-ground double-tap, detected via a short time window
 *     between landed jumps) -> THIS is what actually launches them ~10
 *     blocks up and starts the 20s regen+glow window and Mace Dive charge.
 *  3. Being armed has no expiry timer - it stays armed until either the
 *     double-jump launch consumes it, or the player drinks a different
 *     potion (which unequips Regen and clears the arm state).
 */
public class RegenAbilityManager {

    private final PotionSMP plugin;

    // Players who have run /slot1 or /slot2 for Regen and are waiting to double-jump
    private final Set<UUID> armed = new HashSet<>();

    // Tracks last single-jump timestamp (ms) for ground-to-ground double-tap detection
    private final Map<UUID, Long> lastJumpTime = new HashMap<>();
    private static final long DOUBLE_JUMP_WINDOW_MS = 600;

    // Players currently airborne+charged for a bonus Mace Dive hit
    private final Set<UUID> chargedForDive = new HashSet<>();

    // Players inside their active-duration window: opened by the FIRST
    // double-jump launch, stays open for durationTicks, during which any
    // further double-jump re-triggers a launch (no re-arm / no new cooldown
    // needed). Closes automatically once the window's duration elapses.
    private final Set<UUID> windowActive = new HashSet<>();

    public RegenAbilityManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public void arm(UUID uuid) {
        armed.add(uuid);
    }

    public boolean isArmed(UUID uuid) {
        return armed.contains(uuid);
    }

    public void disarm(UUID uuid) {
        armed.remove(uuid);
        lastJumpTime.remove(uuid);
    }

    public boolean isWindowActive(UUID uuid) {
        return windowActive.contains(uuid);
    }

    /**
     * Opens the multi-use window for durationTicks. Called once, on the
     * first launch of a Vitality Surge cycle — re-launches inside the
     * window don't reopen/extend it.
     */
    private void openWindow(UUID uuid, int durationTicks) {
        windowActive.add(uuid);
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> windowActive.remove(uuid), durationTicks);
    }

    /** Cleanup — e.g. on unequip. */
    public void closeWindow(UUID uuid) {
        windowActive.remove(uuid);
    }

    /**
     * Registers a jump. Returns true if this is the second jump of a
     * ground-to-ground double-tap (i.e. the player landed after their
     * first jump and is now jumping again within the window).
     */
    public boolean registerJumpAndCheckDouble(UUID uuid) {
        long now = System.currentTimeMillis();
        Long last = lastJumpTime.get(uuid);
        lastJumpTime.put(uuid, now);
        return last != null && (now - last) <= DOUBLE_JUMP_WINDOW_MS;
    }

    public boolean isChargedForDive(UUID uuid) {
        return chargedForDive.contains(uuid);
    }

    public void clearCharge(UUID uuid) {
        chargedForDive.remove(uuid);
    }

    /**
     * Performs the launch + regen/glow window. On the FIRST launch of a
     * cycle (firstLaunch = true) this also consumes the armed state and
     * opens the multi-use window for durationTicks. Re-launches during
     * that window (firstLaunch = false) just re-apply velocity/effects —
     * they don't touch armed/window state, so the window keeps running on
     * its original schedule.
     */
    public void launch(Player player, int heightBlocks, int durationTicks, int regenAmplifier, boolean firstLaunch) {
        UUID uid = player.getUniqueId();

        if (firstLaunch) {
            disarm(uid); // armed state is consumed by the first launch
            openWindow(uid, durationTicks);
        }

        double velocity = Math.sqrt(heightBlocks) * 0.85;
        player.setVelocity(new Vector(0, velocity, 0));

        chargedForDive.add(uid);

        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, durationTicks, regenAmplifier, false, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, durationTicks, 0, false, false));

        Location loc = player.getLocation();
        loc.getWorld().playSound(loc, Sound.BLOCK_BEACON_AMBIENT, 1f, 1.2f);

        runLandingWatcher(player);
    }

    private void runLandingWatcher(Player player) {
        UUID uid = player.getUniqueId();
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!player.isOnline() || ticks > 200) {
                    cancel();
                    return;
                }
                if (player.isOnGround() && ticks > 2) {
                    chargedForDive.remove(uid);
                    cancel();
                    return;
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    public void triggerMaceDive(Player player, LivingEntity target, double diveDamage) {
        UUID uid = player.getUniqueId();
        chargedForDive.remove(uid);

        target.damage(diveDamage, player);

        Location loc = target.getLocation();
        loc.getWorld().spawnParticle(Particle.HEART, loc.clone().add(0, 1, 0), 25, 0.6, 0.6, 0.6, 0);
        loc.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc.clone().add(0, 1, 0), 30, 0.6, 0.4, 0.6, 0.3);

        for (int i = 0; i < 30; i++) {
            double angle = (2 * Math.PI * i) / 30;
            double x = loc.getX() + 1.5 * Math.cos(angle);
            double z = loc.getZ() + 1.5 * Math.sin(angle);
            loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK, x, loc.getY() + 0.1, z, 1, 0, 0, 0, 0);
        }

        loc.getWorld().playSound(loc, Sound.ITEM_MACE_SMASH_GROUND, 1.2f, 1f);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 0.5f);
    }
}

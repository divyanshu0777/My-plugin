package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages Shield Potion's Divine Barrier:
 *  - Complete damage immunity
 *  - Knockback immunity
 *  - Two intersecting particle rings (vertical clockwise + horizontal counter-clockwise)
 *    that follow player yaw/pitch in real time
 *  - Hit effect: white flash + shockwave + glass shard burst
 */
public class ShieldManager {

    private final PotionSMP plugin;
    private final Map<UUID, Integer> shieldTasks = new HashMap<>();
    private final Map<UUID, Boolean> shielded = new HashMap<>();

    public ShieldManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public boolean isShielded(UUID uuid) {
        return shielded.getOrDefault(uuid, false);
    }

    public void activateShield(Player player, int durationTicks) {
        UUID uid = player.getUniqueId();

        // Cancel any leftover legacy task reference
        Integer existing = shieldTasks.remove(uid);
        if (existing != null) plugin.getServer().getScheduler().cancelTask(existing);

        shielded.put(uid, true);
        player.sendMessage(PotionUtils.colorize("&f🛡 Divine Barrier active!"));

        // All visuals (activation burst, 3-layer rotating barrier, shield
        // fragments, core energy, and the end-of-duration collapse) are
        // handled entirely by ShieldAuraManager — kept as the single
        // visual system so it never runs alongside a duplicate set of
        // particles here.
        plugin.getShieldAuraManager().startDivineBarrier(player, durationTicks);

        // Auto-deactivate immunity after duration
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (isShielded(uid)) {
                deactivateShield(player);
                player.sendMessage(PotionUtils.colorize("&7Divine Barrier has faded."));
            }
        }, durationTicks + 1);
    }

    /** Spawns hit effect when damage is blocked */
    public void spawnHitEffect(Player player) {
        Location loc = player.getLocation().add(0, 1, 0);
        // White flash
        loc.getWorld().spawnParticle(Particle.DUST, loc, 50,
            new Particle.DustOptions(Color.WHITE, 1.5f));
        // Shockwave ring
        for (int i = 0; i < 24; i++) {
            double a = Math.toRadians(15.0 * i);
            double x = Math.cos(a) * 2.0;
            double z = Math.sin(a) * 2.0;
            loc.getWorld().spawnParticle(Particle.END_ROD,
                loc.getX() + x, loc.getY(), loc.getZ() + z, 1, 0, 0, 0, 0);
        }
        // Glass shard burst
        loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 12, 0.5, 0.5, 0.5, 0.3);
        loc.getWorld().playSound(loc, Sound.BLOCK_GLASS_BREAK, 1.5f, 2f);
        loc.getWorld().playSound(loc, Sound.ENTITY_IRON_GOLEM_HURT, 0.8f, 2f);
    }

    private void deactivateShield(Player player) {
        UUID uid = player.getUniqueId();
        shielded.remove(uid);
        Integer taskId = shieldTasks.remove(uid);
        if (taskId != null) plugin.getServer().getScheduler().cancelTask(taskId);

        // Stop the visual barrier if it's somehow still running. Under
        // normal timing ShieldAuraManager's own task already finished and
        // played its end-of-duration collapse a tick earlier (both are
        // started with the same durationTicks) — this is just a safety
        // cleanup, not a second ending animation.
        plugin.getShieldAuraManager().stopDivineBarrier(uid);
    }

    public void cancelAll() {
        shieldTasks.values().forEach(id -> plugin.getServer().getScheduler().cancelTask(id));
        shieldTasks.clear();
        shielded.clear();
    }
}

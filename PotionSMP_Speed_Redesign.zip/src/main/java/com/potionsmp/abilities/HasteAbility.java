package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * ⛏ Haste Potion
 *
 * PASSIVE:
 * - Held pickaxe gets Efficiency III + Fortune II (refreshed every 5 ticks)
 * - Haste I always active (attack speed +10%)
 *
 * ACTIVE – Haste Rush (10s, 45s CD):
 * - Held pickaxe gets Efficiency 10 + Fortune 5 + Unbreaking 10
 * - After 10s, restore original enchants
 */
public class HasteAbility implements Ability {

    // Store original pickaxe meta per player so we can restore after Rush ends
    private final Map<UUID, ItemMeta> savedMeta    = new HashMap<>();
    private final Map<UUID, ItemStack> savedItem   = new HashMap<>();
    private final Set<UUID> rushActive              = new HashSet<>();

    @Override
    public PotionType type() { return PotionType.HASTE; }

    // ── Equip ─────────────────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        startPassiveLoop(plugin, player);
        player.sendMessage(PotionUtils.colorize("&6⛏ Haste Potion passive active!"));
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());
        rushActive.remove(player.getUniqueId());
        restorePickaxe(player);
        player.removePotionEffect(PotionEffectType.HASTE);
    }

    // ── Passive loop (every 5 ticks) ──────────────────────────────────────

    private void startPassiveLoop(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() ||
                    !plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.HASTE)) {
                    player.removePotionEffect(PotionEffectType.HASTE);
                    cancel();
                    return;
                }

                // Haste I — permanent (attack speed +10%)
                if (!rushActive.contains(player.getUniqueId())) {
                    player.addPotionEffect(new PotionEffect(
                        PotionEffectType.HASTE, 30, 0, false, false));
                }

                // Apply Efficiency III + Fortune II to held pickaxe
                if (!rushActive.contains(player.getUniqueId())) {
                    applyPassiveEnchants(player);
                }

                // Subtle mining aura
                Location loc = player.getLocation().add(0, 1, 0);
                if (Math.random() < 0.3) {
                    loc.getWorld().spawnParticle(Particle.CRIT,
                        loc, 2, 0.3, 0.3, 0.3, 0.05);
                }
            }
        }.runTaskTimer(plugin, 0L, 5L);
    }

    /**
     * Apply Efficiency III + Fortune II to held pickaxe (passive).
     * Only modifies the ItemStack temporarily in-hand — does NOT save/restore
     * (passive is lightweight, Rush does full save/restore).
     */
    private void applyPassiveEnchants(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (!isPickaxe(item)) return;
        if (rushActive.contains(player.getUniqueId())) return; // Rush handles its own enchants

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        // Only add if not already at this level or higher
        int currEff  = meta.getEnchantLevel(Enchantment.EFFICIENCY);
        int currFort = meta.getEnchantLevel(Enchantment.FORTUNE);

        if (currEff < 3)  meta.addEnchant(Enchantment.EFFICIENCY, 3, true);
        if (currFort < 2) meta.addEnchant(Enchantment.FORTUNE,    2, true);

        item.setItemMeta(meta);
    }

    // ── Active: Haste Rush ────────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        ItemStack item = player.getInventory().getItemInMainHand();
        if (!isPickaxe(item)) {
            player.sendMessage(PotionUtils.colorize("&cHold a pickaxe to activate Haste Rush!"));
            return ActivationResult.SUCCESS;
        }

        int dur      = plugin.getConfig().getInt("potions.haste.active-duration", 10);
        int cooldown = plugin.getConfig().getInt("potions.haste.active-cooldown", 45);

        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);
        rushActive.add(uid);

        // ── Save original meta ────────────────────────────────────────────
        savedMeta.put(uid, item.getItemMeta().clone());
        savedItem.put(uid, item.clone());

        // ── Apply Rush enchants ───────────────────────────────────────────
        ItemMeta rushMeta = item.getItemMeta();
        rushMeta.addEnchant(Enchantment.EFFICIENCY, 10, true);
        rushMeta.addEnchant(Enchantment.FORTUNE,    5,  true);
        rushMeta.addEnchant(Enchantment.UNBREAKING, 10, true);
        // Rename to show Rush active
        rushMeta.setDisplayName("§6⚡ §e" + (item.getType().name().replace("_PICKAXE","")
            .replace("_"," ")) + " §6[HASTE RUSH]");
        item.setItemMeta(rushMeta);

        // Haste II during Rush
        player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, dur * 20 + 5, 1, false, false));

        // ── Visual ────────────────────────────────────────────────────────
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.CRIT,          loc.clone().add(0,1,0), 30, 0.7,1,0.7, 0.2);
        loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(0,1,0), 20, 0.5,0.8,0.5, 0.1);
        loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK,   loc.clone().add(0,1,0), 10, 0.5,0.5,0.5, 0);
        loc.getWorld().playSound(loc, Sound.BLOCK_ANVIL_USE,             1f,   1.2f);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.4f, 1.5f);

        player.sendTitle("§6§l⛏ HASTE RUSH", "§eEff 10 · Fortune 5 · Unbreaking 10", 5, 40, 10);
        plugin.getBossBarManager().show(player, "§6⛏ Haste Rush Active",
            org.bukkit.boss.BarColor.YELLOW, dur);

        // ── Rush aura loop ────────────────────────────────────────────────
        new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;
            @Override
            public void run() {
                if (ticks >= dur * 20 || !player.isOnline()) { cancel(); return; }
                Location l = player.getLocation().add(0, 0.3, 0);
                angle += 0.25;
                for (int i = 0; i < 4; i++) {
                    double a = angle + (Math.PI / 2) * i;
                    l.getWorld().spawnParticle(Particle.CRIT,
                        l.clone().add(Math.cos(a)*0.7, 0.5, Math.sin(a)*0.7),
                        1, 0, 0, 0, 0);
                }
                if (ticks % 10 == 0)
                    l.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, l, 2, 0.4,0.3,0.4, 0.05);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        // ── Schedule Rush end ─────────────────────────────────────────────
        new BukkitRunnable() {
            @Override
            public void run() {
                rushActive.remove(uid);
                restorePickaxe(player);
                plugin.getBossBarManager().remove(uid);
                if (player.isOnline()) {
                    player.sendActionBar(net.kyori.adventure.text.Component.text(
                        "§7Haste Rush ended. Pickaxe restored."));
                    player.getWorld().playSound(player.getLocation(),
                        Sound.BLOCK_ANVIL_LAND, 0.6f, 1.2f);
                }
            }
        }.runTaskLater(plugin, dur * 20L);

        return ActivationResult.SUCCESS;
    }

    // ── Restore original pickaxe meta ─────────────────────────────────────

    private void restorePickaxe(Player player) {
        UUID uid = player.getUniqueId();
        ItemMeta meta = savedMeta.remove(uid);
        if (meta == null) return;

        ItemStack held = player.getInventory().getItemInMainHand();
        if (isPickaxe(held)) {
            held.setItemMeta(meta);
        }
        savedItem.remove(uid);
    }

    // ── Helper ────────────────────────────────────────────────────────────

    private boolean isPickaxe(ItemStack item) {
        if (item == null) return false;
        String name = item.getType().name();
        return name.endsWith("_PICKAXE");
    }
}

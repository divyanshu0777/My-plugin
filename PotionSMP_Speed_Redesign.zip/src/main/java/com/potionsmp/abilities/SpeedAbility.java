package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * §e Speed Potion – Lightning Fast Warrior
 *
 * PASSIVE — single centralized state machine (see {@link com.potionsmp.managers.SpeedEffectController}):
 * - PASSIVE_SPEED_I: Speed I, infinite, while equipped.
 * - Every valid hit builds a combo counter (1×⚡ … 5×⚡), reset if 2s pass
 *   without another valid hit.
 * - On the 5th valid hit within the window: SPEED_IV_BURST — Speed IV for
 *   exactly 3 seconds, then automatically back to Speed I passive.
 * - There is never more than ONE Minecraft SPEED effect on the player from
 *   this potion — SpeedEffectController is the sole owner of that effect.
 * - 25% reduced iframes on hit targets (unrelated to the Speed effect itself).
 *
 * ACTIVE – Lightning Dash:
 * - Dash in look direction
 * - Speed IV during dash (routed through SpeedEffectController so it can
 *   never run alongside/independently of the combo-burst state)
 * - 20% damage reduction
 * - Shockwave at end (4-5 block radius)
 * - Duration: 1.8s | Cooldown: 28s
 * - The 5-hit combo NEVER triggers Dash — Dash only fires via its own
 *   /slot activation, unchanged.
 */
public class SpeedAbility implements Ability, Listener {

    // Players currently dashing
    private final Set<UUID> dashing = new HashSet<>();

    public void register(PotionSMP plugin) {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public PotionType type() { return PotionType.SPEED; }

    // ── Equip / Unequip ───────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        plugin.getSpeedEffectController().onEquip(player);
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        dashing.remove(uid);
        plugin.getSpeedEffectController().onUnequip(player);
    }

    // ── Cleanup on quit / death ──────────────────────────────────────────
    // Ensures dashing and the Speed state machine can never get stuck if
    // the player disconnects or dies mid-dash / mid-combo / mid-burst.

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uid = player.getUniqueId();
        dashing.remove(uid);
        PotionSMP.getInstance().getSpeedEffectController().onUnequip(player);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        // Only clear the in-progress dash flag — hit-combo/passive state is
        // left alone here since respawn/equip handling already governs that
        // elsewhere, and touching it would be a gameplay change.
        dashing.remove(event.getEntity().getUniqueId());
    }

    // ── Passive hit: build the 5-hit combo ─────────────────────────────────

    @Override
    public void onHit(PotionSMP plugin, Player player, LivingEntity target) {
        // Valid-hit check via the project's existing hit-detection/debounce
        // architecture (HitCounterManager) — protects against Minecraft
        // occasionally firing EntityDamageByEntityEvent twice for one swing.
        int debounced = plugin.getHitCounterManager().registerHit(
            player.getUniqueId(), type(), target.getUniqueId(),
            player.getWorld().getFullTime());
        if (debounced == -1) return; // duplicate event for the same swing — not a valid hit

        plugin.getSpeedEffectController().onValidHit(player);

        // Reduce iframes by 25% (set to 75% of default 20) — unrelated to
        // the Speed effect state machine, unchanged.
        target.setNoDamageTicks(Math.max(0, (int) (target.getNoDamageTicks() * 0.75)));

        // Spark on hit
        target.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,
            target.getLocation().add(0, 1, 0), 4, 0.2, 0.2, 0.2, 0.05);
    }

    // ── Active: Lightning Dash ────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        // Hard guard: never allow a second dash while one is already
        // active — checked independently of cooldown timing/config so it
        // can't be bypassed even with a custom short cooldown value.
        if (dashing.contains(uid)) return ActivationResult.ON_COOLDOWN;

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        int cooldown = plugin.getConfig().getInt("potions.speed.active-cooldown", 28);
        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);

        executeDash(plugin, player);
        return ActivationResult.SUCCESS;
    }

    private void executeDash(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        dashing.add(uid);

        // Speed IV + 20% damage reduction during dash. Speed IV is routed
        // through SpeedEffectController (the single SPEED-effect owner) so
        // the combo/passive state is automatically restored once the dash's
        // speed window ends, and it can never run alongside a combo burst.
        plugin.getSpeedEffectController().triggerExternalBurst(player, 3, 40);
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 40, 0, false, false));

        // Launch in look direction
        Vector dir = player.getLocation().getDirection().normalize().multiply(1.4);
        dir.setY(Math.max(dir.getY(), 0.1));
        player.setVelocity(dir);

        player.sendTitle("", "§e⚡ Lightning Dash!", 2, 15, 5);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.8f);

        // Dash trail
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= 36 || !player.isOnline() || player.isDead() || !dashing.contains(uid)) { // 1.8s
                    if (player.isOnline() && !player.isDead()) {
                        triggerShockwave(plugin, player);
                        player.removePotionEffect(PotionEffectType.RESISTANCE);
                    }
                    dashing.remove(uid);
                    cancel(); return;
                }
                Location loc = player.getLocation();
                loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 5, 0.2, 0.2, 0.2, 0.05);
                loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK, loc, 2, 0.3, 0.1, 0.3, 0);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void triggerShockwave(PotionSMP plugin, Player player) {
        Location loc = player.getLocation();
        World world = loc.getWorld();
        double radius = plugin.getConfig().getDouble("potions.speed.shockwave-radius", 4.5);
        double dmg = plugin.getConfig().getDouble("potions.speed.shockwave-damage", 5.0);

        // Ring particles
        for (int i = 0; i < 36; i++) {
            double angle = Math.toRadians(i * 10);
            Location p = loc.clone().add(Math.cos(angle) * radius, 0.1, Math.sin(angle) * radius);
            world.spawnParticle(Particle.ELECTRIC_SPARK, p, 2, 0.1, 0.1, 0.1, 0.05);
            world.spawnParticle(Particle.SWEEP_ATTACK, p, 1, 0, 0, 0, 0);
        }

        world.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.4f);
        world.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 1.5f);

        // Damage + knockback nearby
        for (Entity e : world.getNearbyEntities(loc, radius, radius, radius)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e.getUniqueId().equals(player.getUniqueId())) continue;
            le.damage(dmg, player);
            le.setNoDamageTicks(0);
            Vector kb = le.getLocation().toVector().subtract(loc.toVector()).normalize()
                .multiply(1.5).setY(0.5);
            le.setVelocity(kb);
        }
    }

    // ── Reduce iframes on victim (EntityDamageByEntityEvent) ─────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (!PotionSMP.getInstance().getSpeedEffectController().isTracked(p)) return;
        if (e.getEntity() instanceof LivingEntity le) {
            PotionSMP plugin = PotionSMP.getInstance();
            plugin.getServer().getScheduler().runTaskLater(
                plugin, () -> le.setNoDamageTicks(
                    (int) (le.getNoDamageTicks() * 0.75)), 1L);
        }
    }
}

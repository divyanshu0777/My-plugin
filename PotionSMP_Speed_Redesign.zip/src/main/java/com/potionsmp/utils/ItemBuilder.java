package com.potionsmp.utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.util.List;

public class ItemBuilder {

    public static ItemStack buildPotion(com.potionsmp.utils.PotionType type) {
        ItemStack item = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) item.getItemMeta();

        meta.setCustomModelData(PotionUtils.getModelData(type));
        meta.setDisplayName(type.getDisplayName());

        switch (type) {

            case FIRE -> {
                meta.setBasePotionType(PotionType.FIRE_RESISTANCE);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fEvery 10 hits ignites enemies"),
                    PotionUtils.colorize("&7Passive: &fInfinite Fire Resistance"),
                    PotionUtils.colorize("&7Active: &c&lInferno Rage &7(10×10 aura, 10s)"),
                    PotionUtils.colorize("&eCooldown: &f30s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case FREEZE -> {
                meta.setBasePotionType(PotionType.SLOWNESS);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fEvery 10 hits stuns target for 1s"),
                    PotionUtils.colorize("&7Active: &b&lArctic Prison &7(10-block freeze zone)"),
                    PotionUtils.colorize("&eCooldown: &f45s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case REGEN -> {
                meta.setBasePotionType(PotionType.REGENERATION);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fRegeneration I (always active)"),
                    PotionUtils.colorize("&7Active: &a&lVitality Surge"),
                    PotionUtils.colorize("&f  Double-jump to launch · Mace Dive for 10-heart AoE"),
                    PotionUtils.colorize("&f  Land again to re-launch while ability is active"),
                    PotionUtils.colorize("&eCooldown: &f45s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case GLITCH -> {
                meta.setBasePotionType(PotionType.SWIFTNESS);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fMining Fatigue I + glitch aura"),
                    PotionUtils.colorize("&7Active: &d&lSystem Corruption &7(10s)"),
                    PotionUtils.colorize("&f  Force-drop · no pickup · teleport stutter"),
                    PotionUtils.colorize("&eCooldown: &f35s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case SHIELD -> {
                meta.setBasePotionType(PotionType.TURTLE_MASTER);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Active: &f&lDivine Barrier &7(8s)"),
                    PotionUtils.colorize("&f  Full damage + knockback immunity"),
                    PotionUtils.colorize("&f  Dual spinning celestial rings"),
                    PotionUtils.colorize("&eCooldown: &f45s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case ENDER -> {
                meta.setBasePotionType(PotionType.NIGHT_VISION);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &5Void Corruption"),
                    PotionUtils.colorize("&f  Every 10 hits → void lightning + 1s stun + true dmg"),
                    PotionUtils.colorize("&7Active: &5&lAbyss Domain &7(12s, 15-block radius)"),
                    PotionUtils.colorize("&f  Blindness · Weakness II · True DOT · Void Lightning"),
                    PotionUtils.colorize("&f  Suppresses Teleport/Shield/Regen inside zone"),
                    PotionUtils.colorize("&eCooldown: &f180s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case TELEPORT -> {
                meta.setBasePotionType(PotionType.INVISIBILITY);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &3Infinite Invisibility"),
                    PotionUtils.colorize("&f  Faint shadow trail — barely detectable"),
                    PotionUtils.colorize("&7Active: &3&lShadow Teleport &7(instant)"),
                    PotionUtils.colorize("&f  5s countdown → teleport to nearest player"),
                    PotionUtils.colorize("&f  Applies Nausea + Blindness to target (3s)"),
                    PotionUtils.colorize("&eCooldown: &f90s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case SPEED -> {
                meta.setBasePotionType(PotionType.SWIFTNESS);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &eSpeed I (stacks to Speed IV on hits)"),
                    PotionUtils.colorize("&f  Speed resets to I if no hit for 1.5s"),
                    PotionUtils.colorize("&f  25% reduced iframes on targets"),
                    PotionUtils.colorize("&7Active: &e&lLightning Dash &7(1.8s)"),
                    PotionUtils.colorize("&f  Dash forward · shockwave on end"),
                    PotionUtils.colorize("&eCooldown: &f28s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case FEATHER -> {
                meta.setBasePotionType(PotionType.SLOW_FALLING);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &fFully immune to fall damage"),
                    PotionUtils.colorize("&f  Auto-glide when falling — slow descent"),
                    PotionUtils.colorize("&f  Preserves horizontal momentum while gliding"),
                    PotionUtils.colorize("&f  Glide ends automatically on landing"),
                    PotionUtils.colorize("&7Active: &fNone (fully passive potion)"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case EMERALD -> {
                meta.setBasePotionType(PotionType.LUCK);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &aPermanent Luck"),
                    PotionUtils.colorize("&f  Mob drops = Looting III · 1.5× EXP"),
                    PotionUtils.colorize("&f  15% chance consumables are not consumed"),
                    PotionUtils.colorize("&7Active: &a&lHero's Blessing &7(11s)"),
                    PotionUtils.colorize("&f  Hero of the Village · 3× EXP · 30% item save"),
                    PotionUtils.colorize("&eCooldown: &f50s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case STRENGTH -> {
                meta.setBasePotionType(PotionType.STRENGTH);
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &42× damage to hostile mobs"),
                    PotionUtils.colorize("&f  Bonus dmg at low enemy HP (<6/4/2 hearts)"),
                    PotionUtils.colorize("&7Active: &4&lSpark &7(15s)"),
                    PotionUtils.colorize("&f  Every attack = critical hit"),
                    PotionUtils.colorize("&f  Disables enemy shields · Arrows pierce shields"),
                    PotionUtils.colorize("&eCooldown: &f30s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }

            case HASTE -> {
                // No vanilla "Haste" potion type exists in org.bukkit.potion.PotionType —
                // Minecraft has never had a brewable Haste potion (Haste only comes from
                // beacons/conduits). Use a neutral WATER base + an explicit gold tint so
                // the item still visually reads as "Haste"; the real gameplay identity is
                // carried by PotionUtils.tagPotion() (PDC) + custom-model-data (set above).
                meta.setBasePotionType(PotionType.WATER);
                meta.setColor(org.bukkit.Color.fromRGB(222, 184, 45));
                meta.setLore(List.of(
                    PotionUtils.colorize("&7Passive: &6Efficiency III + Fortune II on held pickaxe"),
                    PotionUtils.colorize("&f  Haste I always active (+10% attack speed)"),
                    PotionUtils.colorize("&7Active: &6&lHaste Rush &7(10s)"),
                    PotionUtils.colorize("&f  Efficiency 10 · Fortune 5 · Unbreaking 10"),
                    PotionUtils.colorize("&f  Enchants restored automatically after 10s"),
                    PotionUtils.colorize("&eCooldown: &f45s"),
                    PotionUtils.colorize("&7Drink to equip!")
                ));
            }
        }

        PotionUtils.tagPotion(meta, type);
        item.setItemMeta(meta);
        return item;
    }
}

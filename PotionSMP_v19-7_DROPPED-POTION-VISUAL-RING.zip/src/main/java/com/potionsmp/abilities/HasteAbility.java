package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * ⛏ Haste Potion
 *
 * PASSIVE:
 * - Held pickaxe gets Efficiency III + Fortune II (refreshed every 5 ticks)
 * - Haste I always active (attack speed +10%)
 *
 * ACTIVE – Haste Rush (10s, 45s CD):
 * - Held pickaxe gets Efficiency 10 + Fortune 5 + Unbreaking 10
 * - After 10s, restore original enchants
 *
 * ── Item-restoration design ─────────────────────────────────────────────
 * Every pickaxe Haste modifies (passively or via Rush) is stamped with a
 * random per-modification ID in its PersistentDataContainer, alongside a
 * full ItemStack clone taken the instant before Haste touched it. That tag
 * is what "identifies" the modified item — never its current inventory
 * slot or whether it's still in the main hand. Restoration always searches
 * the player's whole inventory (hotbar + main + offhand) for the item
 * carrying that exact tag and swaps it back to the saved snapshot. If the
 * tagged item can no longer be found (dropped, destroyed, consumed, etc.)
 * that's a safe no-op — the tracking entry is simply discarded.
 *
 * Two independent snapshots are kept per player:
 *  - passiveTracked: the state of the pickaxe from just before the passive
 *    Efficiency III / Fortune II was applied. Restored on full unequip, on
 *    switching away from that pickaxe, or on disconnect.
 *  - rushTracked: the state from just before Rush's Efficiency 10 / Fortune
 *    5 / Unbreaking 10 + rename was applied (this may already include the
 *    passive enchants above, which is correct — ending Rush should hand the
 *    item back to whatever the passive layer had it at, not strip further).
 */
public class HasteAbility implements Ability, Listener {

    private static final String PASSIVE_TAG = "haste_passive_id";
    private static final String RUSH_TAG    = "haste_rush_id";

    /** A snapshot of an item Haste modified, keyed by the ID tagged onto it. */
    private static final class Tracked {
        final String trackId;
        final ItemStack original;
        Tracked(String trackId, ItemStack original) {
            this.trackId = trackId;
            this.original = original;
        }
    }

    private final Set<UUID> rushActive              = new HashSet<>();
    // Tracks the running passive loop per player so a duplicate onEquip()
    // call cancels the old loop instead of leaving two running at once.
    private final Map<UUID, BukkitTask> passiveLoop = new HashMap<>();
    // The scheduled "Rush end" restoration task, so it can be cancelled if
    // Haste is unequipped (or the player quits) before Rush naturally ends.
    private final Map<UUID, BukkitTask> rushEndTask = new HashMap<>();
    // The exact pickaxe currently carrying the passive enchants, and its
    // state from immediately before Haste touched it.
    private final Map<UUID, Tracked> passiveTracked = new HashMap<>();
    // The exact pickaxe currently carrying Rush's enchants, and its state
    // from immediately before Rush touched it.
    private final Map<UUID, Tracked> rushTracked    = new HashMap<>();


    @Override
    public PotionType type() { return PotionType.HASTE; }

    // ── Equip ─────────────────────────────────────────────────────────────

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        startPassiveLoop(plugin, player);
        if (!PotionUtils.isQuiet()) {
            player.sendMessage(PotionUtils.colorize("&6⛏ Haste Potion passive active!"));
        }
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();
        plugin.getParticleManager().cancelAura(uid);
        rushActive.remove(uid);

        BukkitTask loop = passiveLoop.remove(uid);
        if (loop != null) loop.cancel();

        BukkitTask endTask = rushEndTask.remove(uid);
        if (endTask != null) endTask.cancel();

        // Restore Rush's modification first (it may sit "on top of" the
        // passive one), then the passive one. Both are safe no-ops if the
        // tagged item can no longer be found anywhere in the inventory.
        restoreTracked(player, RUSH_TAG, rushTracked.remove(uid));
        restoreTracked(player, PASSIVE_TAG, passiveTracked.remove(uid));

        plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.HASTE);
    }

    // ── Disconnect ───────────────────────────────────────────────────────
    // A player's inventory NBT is saved on quit, so any Haste enchants
    // still on an item at that moment would otherwise become permanent.
    // Inventory is still accessible synchronously during this event.

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uid = player.getUniqueId();

        BukkitTask loop = passiveLoop.remove(uid);
        if (loop != null) loop.cancel();
        BukkitTask endTask = rushEndTask.remove(uid);
        if (endTask != null) endTask.cancel();
        rushActive.remove(uid);

        restoreTracked(player, RUSH_TAG, rushTracked.remove(uid));
        restoreTracked(player, PASSIVE_TAG, passiveTracked.remove(uid));
    }

    // ── Plugin disable / restart safety ─────────────────────────────────
    // A player's inventory is saved to disk on a normal server shutdown too
    // (not just on quit), so any tracked pickaxe still enchanted at that
    // moment would otherwise survive a restart permanently. This mirrors
    // onQuit's cleanup for every player still tracked when the plugin
    // disables — same restoreTracked() logic, just reached from a different
    // lifecycle point (called from PotionSMP#onDisable()).

    public void restoreAllTrackedItems(PotionSMP plugin) {
        for (UUID uid : new HashSet<>(passiveTracked.keySet())) {
            Player player = plugin.getServer().getPlayer(uid);
            if (player == null) continue; // offline — onQuit already handled them

            BukkitTask loop = passiveLoop.remove(uid);
            if (loop != null) loop.cancel();
            BukkitTask endTask = rushEndTask.remove(uid);
            if (endTask != null) endTask.cancel();
            rushActive.remove(uid);

            restoreTracked(player, RUSH_TAG, rushTracked.remove(uid));
            restoreTracked(player, PASSIVE_TAG, passiveTracked.remove(uid));
        }
        // Any leftover Rush-only entries (no matching passive entry, so the
        // loop above wouldn't reach them) get the same treatment.
        for (UUID uid : new HashSet<>(rushTracked.keySet())) {
            Player player = plugin.getServer().getPlayer(uid);
            if (player == null) continue;
            restoreTracked(player, RUSH_TAG, rushTracked.remove(uid));
        }
    }

    // ── Passive loop (every 5 ticks) ──────────────────────────────────────

    private void startPassiveLoop(PotionSMP plugin, Player player) {
        plugin.getParticleManager().cancelAura(player.getUniqueId());

        UUID uid = player.getUniqueId();
        // Idempotency guard: cancel any previous loop before starting a
        // fresh one, so a duplicate onEquip() call never doubles the
        // Haste/enchant application rate.
        BukkitTask existing = passiveLoop.remove(uid);
        if (existing != null) existing.cancel();

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() ||
                    !plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.HASTE)) {
                    plugin.getEffectOwnershipManager().clear(player, type(), PotionEffectType.HASTE);
                    cancel();
                    return;
                }

                if (!rushActive.contains(player.getUniqueId())) {
                    // Haste I — permanent while equipped (attack speed +10%)
                    plugin.getEffectOwnershipManager().apply(player, type(),
                        new PotionEffect(PotionEffectType.HASTE, 30, 0, false, false));
                    applyPassiveEnchants(player);
                }

                // Subtle mining aura
                Location loc = player.getLocation().add(0, 1, 0);
                if (Math.random() < 0.3) {
                    loc.getWorld().spawnParticle(Particle.CRIT,
                        loc, 2, 0.3, 0.3, 0.3, 0.05);
                }
            }
        }.runTaskTimer(plugin, 0L, 5L);
        passiveLoop.put(uid, task);
    }

    /**
     * Apply Efficiency III + Fortune II to whichever pickaxe is currently
     * held. The exact item is tagged with a fresh random ID the first time
     * it's touched, so it (and only it) can be found and restored later no
     * matter which inventory slot it ends up in — never based on "whatever
     * happens to be in the main hand" at restoration time.
     */
    private void applyPassiveEnchants(Player player) {
        UUID uid = player.getUniqueId();
        ItemStack held = player.getInventory().getItemInMainHand();

        Tracked tracked = passiveTracked.get(uid);
        if (tracked != null) {
            if (itemHasTrackId(held, PASSIVE_TAG, tracked.trackId)) {
                // Still the same tracked pickaxe — just make sure the
                // enchants are still there (defensive re-apply in case an
                // anvil/grindstone stripped them since the last tick).
                ensurePassiveEnchants(held);
                return;
            }
            // Player switched away from (or moved) the tracked pickaxe.
            // Restore it wherever it currently is before tracking anything
            // new, so it never keeps the enchants permanently.
            restoreTracked(player, PASSIVE_TAG, passiveTracked.remove(uid));
        }

        if (!isPickaxe(held)) return;
        // Already tagged (e.g. a stray tag from a prior session with no
        // in-memory record) — don't re-snapshot a possibly-already-modified
        // item as if it were the true original.
        if (hasTag(held, PASSIVE_TAG)) return;

        ItemStack original = held.clone();
        ItemMeta meta = held.getItemMeta();
        if (meta == null) return;

        String trackId = UUID.randomUUID().toString();
        meta.getPersistentDataContainer().set(tagKey(PASSIVE_TAG), PersistentDataType.STRING, trackId);
        held.setItemMeta(meta);
        ensurePassiveEnchants(held);

        passiveTracked.put(uid, new Tracked(trackId, original));
    }

    private void ensurePassiveEnchants(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        int currEff  = meta.getEnchantLevel(Enchantment.EFFICIENCY);
        int currFort = meta.getEnchantLevel(Enchantment.FORTUNE);
        boolean changed = false;
        if (currEff < 3)  { meta.addEnchant(Enchantment.EFFICIENCY, 3, true); changed = true; }
        if (currFort < 2) { meta.addEnchant(Enchantment.FORTUNE,    2, true); changed = true; }
        if (changed) item.setItemMeta(meta);
    }

    // ── Active: Haste Rush ────────────────────────────────────────────────

    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        UUID uid = player.getUniqueId();

        if (plugin.getCooldownManager().isOnCooldown(uid, type()))
            return ActivationResult.ON_COOLDOWN;

        // Defensive: never overwrite an in-progress Rush's saved original
        // (the cooldown above should already prevent re-activation, but this
        // guards against re-entrancy from any other future call site too).
        if (rushActive.contains(uid))
            return ActivationResult.ON_COOLDOWN;

        ItemStack item = player.getInventory().getItemInMainHand();
        if (!isPickaxe(item)) {
            player.sendMessage(PotionUtils.colorize("&cHold a pickaxe to activate Haste Rush!"));
            return ActivationResult.SUCCESS;
        }

        int dur      = plugin.getConfig().getInt("potions.haste.active-duration", 10);
        int cooldown = plugin.getConfig().getInt("potions.haste.active-cooldown", 45);

        plugin.getCooldownManager().setCooldown(uid, type(), cooldown);
        rushActive.add(uid);

        // ── Save the exact original item and tag it so restoration can
        //    find it again wherever it ends up in the inventory. ─────────
        ItemStack original = item.clone();
        ItemMeta rushMeta = item.getItemMeta();
        if (rushMeta == null) return ActivationResult.SUCCESS;

        String trackId = UUID.randomUUID().toString();
        rushMeta.getPersistentDataContainer().set(tagKey(RUSH_TAG), PersistentDataType.STRING, trackId);
        rushMeta.addEnchant(Enchantment.EFFICIENCY, 10, true);
        rushMeta.addEnchant(Enchantment.FORTUNE,    5,  true);
        rushMeta.addEnchant(Enchantment.UNBREAKING, 10, true);
        // Rename to show Rush active
        rushMeta.setDisplayName("§6⚡ §e" + (item.getType().name().replace("_PICKAXE","")
            .replace("_"," ")) + " §6[HASTE RUSH]");
        item.setItemMeta(rushMeta);

        rushTracked.put(uid, new Tracked(trackId, original));

        // Haste II during Rush
        plugin.getEffectOwnershipManager().apply(player, type(),
            new PotionEffect(PotionEffectType.HASTE, dur * 20 + 5, 1, false, false));

        // ── Visual ────────────────────────────────────────────────────────
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.CRIT,          loc.clone().add(0,1,0), 30, 0.7,1,0.7, 0.2);
        loc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc.clone().add(0,1,0), 20, 0.5,0.8,0.5, 0.1);
        loc.getWorld().spawnParticle(Particle.SWEEP_ATTACK,   loc.clone().add(0,1,0), 10, 0.5,0.5,0.5, 0);
        loc.getWorld().playSound(loc, Sound.BLOCK_ANVIL_USE,             1f,   1.2f);
        loc.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.4f, 1.5f);

        player.sendTitle("§6§l⛏ HASTE RUSH", "§eEff 10 · Fortune 5 · Unbreaking 10", 5, 40, 10);
        plugin.getBossBarManager().show(player, "§6⛏ Haste Rush Active",
            org.bukkit.boss.BarColor.YELLOW, dur);

        // ── Rush aura loop ────────────────────────────────────────────────
        new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;
            @Override
            public void run() {
                if (ticks >= dur * 20 || !player.isOnline()) { cancel(); return; }
                Location l = player.getLocation().add(0, 0.3, 0);
                angle += 0.25;
                for (int i = 0; i < 4; i++) {
                    double a = angle + (Math.PI / 2) * i;
                    l.getWorld().spawnParticle(Particle.CRIT,
                        l.clone().add(Math.cos(a)*0.7, 0.5, Math.sin(a)*0.7),
                        1, 0, 0, 0, 0);
                }
                if (ticks % 10 == 0)
                    l.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, l, 2, 0.4,0.3,0.4, 0.05);
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        // ── Schedule Rush end ─────────────────────────────────────────────
        BukkitTask endTask = new BukkitRunnable() {
            @Override
            public void run() {
                rushActive.remove(uid);
                rushEndTask.remove(uid);
                restoreTracked(player, RUSH_TAG, rushTracked.remove(uid));
                plugin.getBossBarManager().remove(uid);
                if (player.isOnline()) {
                    player.sendActionBar(net.kyori.adventure.text.Component.text(
                        "§7Haste Rush ended. Pickaxe restored."));
                    player.getWorld().playSound(player.getLocation(),
                        Sound.BLOCK_ANVIL_LAND, 0.6f, 1.2f);
                }
            }
        }.runTaskLater(plugin, dur * 20L);
        rushEndTask.put(uid, endTask);

        return ActivationResult.SUCCESS;
    }

    // ── Tag-based exact-item tracking / restoration ─────────────────────

    private NamespacedKey tagKey(String tag) {
        return new NamespacedKey(PotionSMP.getInstance(), tag);
    }

    private boolean itemHasTrackId(ItemStack item, String tag, String trackId) {
        if (item == null || trackId == null) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        String stored = meta.getPersistentDataContainer().get(tagKey(tag), PersistentDataType.STRING);
        return trackId.equals(stored);
    }

    private boolean hasTag(ItemStack item, String tag) {
        if (item == null) return false;
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(tagKey(tag), PersistentDataType.STRING);
    }

    /**
     * Finds the exact item carrying the given tracked snapshot's ID anywhere
     * in the player's inventory (hotbar, main inventory, offhand) — never
     * assumes it's still in the main hand — and replaces it with the exact
     * saved snapshot (enchantments, levels, meta, name/lore, durability all
     * included, since it's a full ItemStack clone). If the tagged item can
     * no longer be found (dropped, consumed, destroyed, etc.) this is a
     * silent no-op — nothing is left half-restored and nothing throws.
     */
    private void restoreTracked(Player player, String tag, Tracked tracked) {
        if (tracked == null) return;

        PlayerInventory inv = player.getInventory();
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            if (itemHasTrackId(contents[i], tag, tracked.trackId)) {
                inv.setItem(i, tracked.original.clone());
                return;
            }
        }
        if (itemHasTrackId(inv.getItemInOffHand(), tag, tracked.trackId)) {
            inv.setItemInOffHand(tracked.original.clone());
        }
        // Not found anywhere — item was dropped/consumed/destroyed since it
        // was modified. Nothing left to restore; caller has already dropped
        // the tracking entry.
    }

    // ── Helper ────────────────────────────────────────────────────────────

    private boolean isPickaxe(ItemStack item) {
        if (item == null) return false;
        String name = item.getType().name();
        return name.endsWith("_PICKAXE");
    }
}

package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInputEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * §f Feather Potion – Feather Flight
 *
 * PASSIVE ONLY:
 * - Elytra-like flight without an Elytra item, chest slot untouched.
 * - Auto-activates once the player is airborne and at least
 *   `potions.feather.flight-min-altitude` blocks above solid ground
 *   (FeatherFlightManager measures altitude via a downward ray trace).
 * - Look direction (pitch/yaw) drives flight: dive to speed up, pull up to
 *   climb (capped), steer left/right naturally.
 * - Fall damage is cancelled only while actively flying (plus a brief
 *   landing-frame grace window) — NOT a standing fall-damage immunity.
 * - Flight stops immediately on landing, entering water/lava, unequip,
 *   death, world change, or logout. See FeatherFlightManager for the full
 *   flight loop and all physics/stop-condition logic.
 *
 * ACTIVE: None — this potion is fully passive, same as before.
 */
public class FeatherAbility implements Ability, Listener {


    @Override
    public PotionType type() { return PotionType.FEATHER; }

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        // Equipping Feather never activates flight by itself. A new Jump input
        // is required before the existing airborne/altitude conditions are checked.
        if (!PotionUtils.isQuiet()) {
            player.sendMessage("§fFeather Glide passive active — no fall damage!");
        }
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        plugin.getFeatherFlightManager().stopFlight(player);
    }

    // ── Flight activation: a real Jump input is required. ───────────────
    @EventHandler
    public void onJumpInput(PlayerInputEvent e) {
        if (!e.getInput().isJump()) return;

        Player player = e.getPlayer();
        if (!PotionSMP.getInstance().getSlotManager()
                .hasEquipped(player.getUniqueId(), PotionType.FEATHER)) {
            return;
        }

        PotionSMP.getInstance().getFeatherFlightManager().requestFlightOnJump(player);
    }

    // A ground jump input is received before the player is airborne. This
    // movement event only completes that already-recorded jump request; it
    // is never used as an independent activation trigger.
    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        PotionSMP.getInstance().getFeatherFlightManager().completePendingJump(e.getPlayer());
    }

    // ── Stop conditions not already covered by the flight loop itself ─────
    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        PotionSMP.getInstance().getFeatherFlightManager().stopFlight(e.getEntity());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        PotionSMP.getInstance().getFeatherFlightManager().stopFlight(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        PotionSMP.getInstance().getFeatherFlightManager().stopFlight(e.getPlayer());
    }


    /**
     * Paper normally rejects fall-flying without a real Elytra. Feather must
     * keep the vanilla fall-flying state active, but it never changes the
     * player's chest item. Only an active Feather flight may suppress the
     * server's automatic glide-stop.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onToggleGlide(EntityToggleGlideEvent e) {
        if (!(e.getEntity() instanceof Player player)) return;
        if (e.isGliding()) return;

        if (PotionSMP.getInstance().getFeatherFlightManager()
                .isFlying(player.getUniqueId())) {
            e.setCancelled(true);
        }
    }

    // ── Feather-equipped fall-damage immunity. This is independent of
    //    whether native fall-flying is currently active. ────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onFallDamage(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(e.getEntity() instanceof Player p)) return;
        if (PotionSMP.getInstance().getSlotManager()
                .hasEquipped(p.getUniqueId(), PotionType.FEATHER)) {
            e.setCancelled(true);
        }
    }

    // ── Active: none ──────────────────────────────────────────────────────
    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        player.sendActionBar(net.kyori.adventure.text.Component.text(
            "§fFeather Potion has no active ability — it's fully passive!"));
        return ActivationResult.SUCCESS;
    }
}

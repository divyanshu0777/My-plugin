package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Feather Potion — plugin-controlled, Elytra-like flight WITHOUT ever
 * giving/equipping an actual Elytra item. This is the ONLY Feather flight
 * system in the codebase; the old "slow descent while falling" glide loop
 * has been fully removed (see FeatherAbility.java).
 *
 * Activation: the player must have Feather equipped, be airborne (not on
 * ground, not in water/lava), and be at least `flight-min-altitude` blocks
 * above the nearest solid ground below them. Altitude is measured with a
 * downward ray trace, not just onGround()/a fixed Y check.
 *
 * While flying: Feather keeps the player in Minecraft's vanilla fall-flying
 * state. The 1.21.11 LivingEntity travelGliding/calcGlidingVelocity path
 * therefore supplies momentum, pitch control, drag, gravity interaction,
 * steering and collision behavior. No Elytra item is equipped.
 *
 * This manager never touches the player's chest slot / inventory.
 */
public class FeatherFlightManager {

    private final PotionSMP plugin;

    private final Map<UUID, BukkitTask> flightTasks = new HashMap<>();
    private final Set<UUID> pendingJumpActivation = new HashSet<>();

    public FeatherFlightManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public boolean isFlying(UUID uid) {
        return flightTasks.containsKey(uid);
    }

    /**
     * Records an actual Jump input and immediately checks the existing
     * Feather activation conditions. If the player is still on the ground,
     * the request remains pending until the jump has made them airborne.
     */
    public void requestFlightOnJump(Player player) {
        UUID uid = player.getUniqueId();
        if (flightTasks.containsKey(uid)) return;
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.FEATHER)) return;

        pendingJumpActivation.add(uid);
        tryStartFlight(player);
    }

    /**
     * Completes a previously recorded Jump input after the movement state has
     * actually become airborne. Movement alone never creates activation.
     */
    public void completePendingJump(Player player) {
        UUID uid = player.getUniqueId();
        if (!pendingJumpActivation.contains(uid)) return;
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.FEATHER)) {
            pendingJumpActivation.remove(uid);
            return;
        }
        if (player.isOnGround()) return;
        tryStartFlight(player);
    }

    private void tryStartFlight(Player player) {
        UUID uid = player.getUniqueId();
        if (flightTasks.containsKey(uid)) return;
        if (!pendingJumpActivation.contains(uid)) return;
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.FEATHER)) {
            pendingJumpActivation.remove(uid);
            return;
        }
        if (player.isOnGround()) return;
        if (isInLiquid(player)) return;

        // Don't fight vanilla creative/spectator flight.
        GameMode mode = player.getGameMode();
        if (mode == GameMode.CREATIVE || mode == GameMode.SPECTATOR) return;

        double minAltitude = plugin.getConfig().getDouble("potions.feather.flight-min-altitude", 5.0);
        if (distanceToGround(player) < minAltitude) return;

        pendingJumpActivation.remove(uid);
        startFlight(player);
    }

    private void startFlight(Player player) {
        UUID uid = player.getUniqueId();

        BukkitRunnable task = new BukkitRunnable() {

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead()) {
                    stopFlight(player);
                    return;
                }
                if (!plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.FEATHER)) {
                    stopFlight(player);
                    return;
                }
                if (isInLiquid(player)) {
                    stopFlight(player);
                    return;
                }
                if (player.isOnGround()) {
                    playLandingEffect(player);
                    stopFlight(player);
                    return;
                }

                // Keep the vanilla fall-flying state alive. No custom velocity
                // calculation is performed here; Minecraft applies its own
                // 1.21.11 Elytra physics during entity travel.
                if (!player.isGliding()) {
                    player.setGliding(true);
                }

            }
        };

        BukkitTask handle = task.runTaskTimer(plugin, 0L, 1L);
        flightTasks.put(uid, handle);

        // Put the flight state in the authoritative map first so the
        // EntityToggleGlideEvent guard is active before the no-Elytra glide
        // state is requested. Vanilla then owns the actual movement physics.
        player.setGliding(true);
    }

    public void stopFlight(Player player) {
        UUID uid = player.getUniqueId();
        BukkitTask task = flightTasks.remove(uid);
        if (task != null) task.cancel();
        if (player.isGliding()) {
            player.setGliding(false);
        }
        pendingJumpActivation.remove(uid);
    }

    public void cancelAll() {
        Set<UUID> flying = new HashSet<>(flightTasks.keySet());
        for (BukkitTask task : flightTasks.values()) {
            task.cancel();
        }
        // Clear authoritative state before changing the glide flag so the
        // EntityToggleGlideEvent guard cannot cancel our own shutdown.
        flightTasks.clear();
        pendingJumpActivation.clear();

        for (UUID uid : flying) {
            Player player = plugin.getServer().getPlayer(uid);
            if (player != null && player.isGliding()) {
                player.setGliding(false);
            }
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    /**
     * Distance from the player's current location straight down to the
     * nearest solid block below them, via a downward ray trace. Returns
     * Double.MAX_VALUE if nothing solid is found within range (i.e.
     * definitely high enough to fly).
     */
    private double distanceToGround(Player player) {
        World world = player.getWorld();
        Location start = player.getLocation();
        RayTraceResult result = world.rayTraceBlocks(start, new Vector(0, -1, 0),
            320.0, FluidCollisionMode.NEVER, true);
        if (result == null || result.getHitPosition() == null) {
            return Double.MAX_VALUE;
        }
        return start.getY() - result.getHitPosition().getY();
    }

    private boolean isInLiquid(Player player) {
        return isLiquid(player.getLocation().getBlock().getType())
            || isLiquid(player.getEyeLocation().getBlock().getType());
    }

    private boolean isLiquid(Material m) {
        return m == Material.WATER || m == Material.LAVA;
    }

    private void playLandingEffect(Player player) {
        Location loc = player.getLocation();
        loc.getWorld().spawnParticle(Particle.CLOUD, loc, 8, 0.4, 0.1, 0.4, 0.05);
        loc.getWorld().playSound(loc, Sound.BLOCK_WOOL_STEP, 0.8f, 1.2f);
    }

}

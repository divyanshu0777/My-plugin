package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Renders a small, purely visual particle ring around dropped PotionSMP
 * potion Item entities. It never modifies the ItemStack or item physics.
 */
public final class DroppedPotionVisualManager implements Listener {

    private static final double RADIUS = 0.55;
    private static final double BASE_Y = 0.18;
    private static final double BOB_AMPLITUDE = 0.08;
    private static final double ANGLE_INCREMENT = 0.12;
    private static final int RING_POINTS = 8;
    private static final long UPDATE_INTERVAL = 2L;

    private final PotionSMP plugin;
    private final Map<UUID, BukkitTask> activeTasks = new HashMap<>();
    private final Map<PotionType, Color> ringColors = new EnumMap<>(PotionType.class);

    public DroppedPotionVisualManager(PotionSMP plugin) {
        this.plugin = plugin;
        initializeColors();
    }

    private void initializeColors() {
        ringColors.put(PotionType.FIRE,     Color.fromRGB(0xFF9900));
        ringColors.put(PotionType.FREEZE,   Color.fromRGB(0x8BAFE0));
        ringColors.put(PotionType.REGEN,    Color.fromRGB(0xCD5CAB));
        ringColors.put(PotionType.GLITCH,   Color.fromRGB(0xA9656A));
        ringColors.put(PotionType.SHIELD,   Color.fromRGB(0x8D82E6));
        ringColors.put(PotionType.ENDER,    Color.fromRGB(0xC2FF66));
        ringColors.put(PotionType.TELEPORT, Color.fromRGB(0xF6F6F6));
        ringColors.put(PotionType.SPEED,    Color.fromRGB(0x33EBFF));
        ringColors.put(PotionType.FEATHER,  Color.fromRGB(0xF3CFB9));
        ringColors.put(PotionType.EMERALD,  Color.fromRGB(0x59C106));
        ringColors.put(PotionType.STRENGTH, Color.fromRGB(0xFFC700));
        ringColors.put(PotionType.HASTE,    Color.fromRGB(0xFDFF84));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDrop(PlayerDropItemEvent event) {
        Item item = event.getItemDrop();
        PotionType type = PotionUtils.getPotionType(item.getItemStack());
        if (type == null || !ringColors.containsKey(type)) return;

        start(item, type);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onItemPickup(EntityPickupItemEvent event) {
        stop(event.getItem().getUniqueId());
    }

    private void start(Item item, PotionType type) {
        UUID id = item.getUniqueId();

        BukkitTask existing = activeTasks.remove(id);
        if (existing != null) existing.cancel();

        Color color = ringColors.get(type);
        Particle.DustOptions dust = new Particle.DustOptions(color, 0.65F);

        BukkitTask task = new BukkitRunnable() {
            private double angle = 0.0;
            private double phase = 0.0;

            @Override
            public void run() {
                if (!item.isValid() || item.isDead() || item.getWorld() == null) {
                    stop(id);
                    return;
                }

                Location center = item.getLocation();
                World world = center.getWorld();
                if (world == null) {
                    stop(id);
                    return;
                }

                double y = BASE_Y + BOB_AMPLITUDE * Math.sin(phase);

                for (int i = 0; i < RING_POINTS; i++) {
                    double currentAngle = angle + (Math.PI * 2.0 / RING_POINTS) * i;
                    double x = Math.cos(currentAngle) * RADIUS;
                    double z = Math.sin(currentAngle) * RADIUS;

                    Location particleLocation = center.clone().add(x, y, z);
                    world.spawnParticle(
                        Particle.DUST,
                        particleLocation,
                        1,
                        0, 0, 0,
                        0,
                        dust
                    );
                }

                angle += ANGLE_INCREMENT;
                phase += 0.10;
            }
        }.runTaskTimer(plugin, 0L, UPDATE_INTERVAL);

        activeTasks.put(id, task);
    }

    private void stop(UUID id) {
        BukkitTask task = activeTasks.remove(id);
        if (task != null) task.cancel();
    }

    public void cancelAll() {
        for (BukkitTask task : activeTasks.values()) {
            if (task != null) task.cancel();
        }
        activeTasks.clear();
    }

    public int getActiveTaskCount() {
        return activeTasks.size();
    }
}

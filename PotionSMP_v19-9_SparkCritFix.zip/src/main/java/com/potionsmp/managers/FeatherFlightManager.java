package com.potionsmp.managers;

import com.potionsmp.PotionSMP;
import com.potionsmp.utils.PotionType;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Feather Potion — plugin-controlled, Elytra-like flight WITHOUT ever
 * giving/equipping an actual Elytra item. This is the ONLY Feather flight
 * system in the codebase; the old "slow descent while falling" glide loop
 * has been fully removed (see FeatherAbility.java).
 *
 * Activation: MANUAL, double-jump style. The player must have Feather
 * equipped, be airborne (not on ground, not in water/lava), and press
 * Space a SECOND time while still airborne — that press is the only
 * trigger that starts Glide. Simply falling/jumping/being airborne never
 * auto-starts it. Implemented by granting a temporary setAllowFlight(true)
 * the moment the player is airborne (see armDoubleJump), which makes the
 * client's own double-tap-Space gesture surface as a
 * PlayerToggleFlightEvent we can catch (see FeatherAbility.onToggleFlight)
 * — that event, and only that event, calls startFlight().
 *
 * While flying: the player is posed via {@code setGliding(true)} for the
 * visual/animation side, but since there's no real Elytra item equipped,
 * vanilla server-side glide physics never actually engages — so the
 * movement itself is still driven manually, every tick, via velocity.
 * The key difference from a "custom flying" feel is that velocity is
 * never replaced outright: each tick computes a pitch/look-driven desired
 * velocity, then the player's actual velocity is eased toward it (see
 * {@link #tickFlight}). That single smoothing step is what makes speed
 * changes, dives, climbs, and left/right steering all ramp gradually
 * instead of snapping — direction changes stop feeling instant because
 * the vector itself is blended, not swapped.
 *
 * This manager never touches the player's chest slot / inventory — flight
 * is achieved purely by easing velocity every tick, not by giving an
 * Elytra, and never by teleporting/repositioning the player directly.
 */
public class FeatherFlightManager {

    private final PotionSMP plugin;

    private final Map<UUID, BukkitTask> flightTasks = new HashMap<>();

    // Desired-speed accumulator (scalar "throttle"): eases toward a
    // pitch-driven target each tick using the existing dive/decel config.
    private final Map<UUID, Double> currentSpeed = new HashMap<>();

    // Actual velocity being applied to the player. Blended toward the
    // desired (direction + speed) vector each tick instead of being
    // replaced by it — this is what removes the instant-direction-snap
    // "custom flying" feel and produces smooth steering/accel/decel.
    private final Map<UUID, Vector> currentVelocity = new HashMap<>();

    // Fraction of the gap between current and desired velocity closed per
    // tick. Lower = smoother/slower to respond, higher = snappier. Kept as
    // a fixed constant rather than a config value since this pass is
    // scoped to the movement model, not configuration.
    private static final double TURN_SMOOTHING = 0.12;

    // Short grace window after flight ends during which fall damage is
    // still cancelled (covers the same-tick landing case where the
    // EntityDamageEvent for FALL can fire right as/just after we stop the
    // task). Cleared automatically a few ticks later — this is NOT a
    // standing fall-damage immunity, just a landing-frame safety net.
    private final Set<UUID> recentlyFlying = new HashSet<>();

    // UUIDs currently in the "armed" double-jump window: airborne, Feather
    // equipped, and we've granted setAllowFlight(true) purely so the
    // client's double-tap-Space gesture fires PlayerToggleFlightEvent for
    // us to catch. This is NOT real flight — it's consumed the instant it
    // either triggers Glide or the player lands/unequips/quits.
    private final Set<UUID> armedForDoubleJump = new HashSet<>();

    public FeatherFlightManager(PotionSMP plugin) {
        this.plugin = plugin;
    }

    public boolean isFlying(UUID uid) {
        return flightTasks.containsKey(uid);
    }

    public boolean isArmed(UUID uid) {
        return armedForDoubleJump.contains(uid);
    }

    /**
     * Whether fall damage should be cancelled right now for this player —
     * true only while actively flying, or within the brief landing-frame
     * grace window right after flight ends. Never true just because
     * Feather is equipped.
     */
    public boolean shouldCancelFallDamage(UUID uid) {
        return flightTasks.containsKey(uid) || recentlyFlying.contains(uid);
    }

    /**
     * Call on every airborne move tick (Feather equipped) to open the
     * double-jump window: grants setAllowFlight(true) so the client's
     * double-tap-Space gesture becomes observable via
     * PlayerToggleFlightEvent. Purely idempotent bookkeeping — does NOT
     * start flight by itself. No-op if already armed, already flying, on
     * ground, in liquid, or in creative/spectator (never touch vanilla
     * flight there).
     */
    public void armDoubleJump(Player player) {
        UUID uid = player.getUniqueId();
        if (flightTasks.containsKey(uid)) return;
        if (armedForDoubleJump.contains(uid)) return;
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.FEATHER)) return;
        if (player.isOnGround()) return;
        if (isInLiquid(player)) return;

        GameMode mode = player.getGameMode();
        if (mode == GameMode.CREATIVE || mode == GameMode.SPECTATOR) return;
        if (player.getAllowFlight()) return; // some other system already grants flight — don't touch it

        player.setAllowFlight(true);
        armedForDoubleJump.add(uid);
    }

    /**
     * Closes the double-jump window without activating Glide (e.g. the
     * player landed, unequipped, or toggled flight off again without a
     * second airborne press ever mattering). Revokes the allow-flight
     * grant we made, but only if we're the ones who set it.
     */
    public void disarmDoubleJump(Player player) {
        UUID uid = player.getUniqueId();
        if (!armedForDoubleJump.remove(uid)) return;
        if (player.isOnline()) {
            GameMode mode = player.getGameMode();
            if (mode != GameMode.CREATIVE && mode != GameMode.SPECTATOR) {
                player.setAllowFlight(false);
            }
        }
    }

    /**
     * The single activation trigger for Feather Glide: called from
     * PlayerToggleFlightEvent when the player double-taps Space while
     * armed. Starts flight if still eligible; either way the arm window is
     * consumed (one attempt, not retried).
     */
    public boolean tryActivateFromDoubleJump(Player player) {
        UUID uid = player.getUniqueId();
        if (!armedForDoubleJump.contains(uid)) return false;

        disarmDoubleJump(player); // consume the window regardless of outcome below

        if (flightTasks.containsKey(uid)) return false;
        if (!plugin.getSlotManager().hasEquipped(uid, PotionType.FEATHER)) return false;
        if (player.isOnGround()) return false;
        if (isInLiquid(player)) return false;

        startFlight(player);
        return true;
    }

    private void startFlight(Player player) {
        UUID uid = player.getUniqueId();
        double baseSpeed = plugin.getConfig().getDouble("potions.feather.flight-base-speed", 0.5);
        currentSpeed.put(uid, baseSpeed);
        // Start the actual velocity aligned with current look/baseSpeed so
        // the very first tick doesn't have to ease in from a stale/zero
        // vector left over from a previous flight.
        currentVelocity.put(uid, player.getEyeLocation().getDirection().clone().normalize().multiply(baseSpeed));
        recentlyFlying.remove(uid);
        player.setGliding(true);

        BukkitRunnable task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() || player.isDead()) {
                    stopFlight(player);
                    return;
                }
                if (!plugin.getSlotManager().hasEquipped(player.getUniqueId(), PotionType.FEATHER)) {
                    stopFlight(player);
                    return;
                }
                if (isInLiquid(player)) {
                    stopFlight(player);
                    return;
                }
                if (player.isOnGround()) {
                    playLandingEffect(player);
                    stopFlight(player);
                    return;
                }

                tickFlight(player);
            }
        };

        BukkitTask handle = task.runTaskTimer(plugin, 0L, 1L);
        flightTasks.put(uid, handle);
    }

    /**
     * One tick of Elytra-like flight physics.
     *
     * Two-stage smoothing, both driven by the player's current look
     * direction (yaw handles left/right steering, pitch drives dive/climb):
     *
     *  1. Desired SPEED (magnitude/throttle) eases toward a pitch-driven
     *     target — diving gradually builds it up, leveling out or climbing
     *     gradually bleeds it back down. Same accel/decel model as before.
     *  2. Desired VELOCITY (that speed applied along the current look
     *     direction) is then blended into the player's ACTUAL velocity by
     *     only a fraction (TURN_SMOOTHING) each tick, instead of replacing
     *     it outright. That second step is what turns instant direction
     *     snaps into a smooth steer/dive/climb — the same math handles
     *     turning, accelerating, and decelerating, since all three are just
     *     "current vector easing toward a moving target vector".
     *
     * No Elytra item or real vanilla glide physics is involved — the
     * gliding pose (setGliding) is purely cosmetic here since the server
     * only applies real Elytra physics when an Elytra is actually equipped.
     */
    private void tickFlight(Player player) {
        UUID uid = player.getUniqueId();

        // Re-assert the glide pose every tick — cheap flag set, and cheaper
        // than risking it silently getting cleared by an unrelated event.
        player.setGliding(true);

        Vector look = player.getEyeLocation().getDirection().clone().normalize();

        // Bukkit pitch: -90 (straight up) .. 0 (level) .. 90 (straight down)
        float pitch = player.getLocation().getPitch();
        double diveFactor = clamp(pitch / 90.0, -1.0, 1.0); // >0 diving, <0 climbing

        double baseSpeed    = plugin.getConfig().getDouble("potions.feather.flight-base-speed", 0.5);
        double maxSpeed      = plugin.getConfig().getDouble("potions.feather.flight-max-speed", 1.4);
        double diveAccel     = plugin.getConfig().getDouble("potions.feather.flight-dive-acceleration", 0.03);
        double decel         = plugin.getConfig().getDouble("potions.feather.flight-deceleration", 0.02);
        double climbMaxSpeed = plugin.getConfig().getDouble("potions.feather.flight-climb-max-speed", 0.5);
        double minSpeed      = baseSpeed * 0.6;

        // --- Stage 1: desired speed (scalar throttle), eased toward a
        // pitch-driven target — unchanged in spirit from before, this part
        // was never the "jerky" problem. ---
        double speed = currentSpeed.getOrDefault(uid, baseSpeed);
        if (diveFactor > 0.05) {
            speed += diveAccel * diveFactor; // diving: gradually build up speed
        } else {
            speed -= decel;                   // level/climbing: gradually bleed off
        }
        speed = clamp(speed, minSpeed, maxSpeed);
        currentSpeed.put(uid, speed);

        // --- Desired velocity for this instant: that speed, applied along
        // wherever the player is currently looking. ---
        Vector desired = look.multiply(speed);
        if (diveFactor < 0) {
            // Looking upward: never generate positive (lift) Y velocity
            // from this — real Elytra doesn't gain altitude just because
            // you look up, it loses glide efficiency instead. Clamping the
            // upward component to <= 0 here (rather than to climbMaxSpeed)
            // is what stops "look up to fly"; horizontal/steering/speed
            // math above is untouched.
            if (desired.getY() > 0) {
                desired.setY(0);
            }
        } else if (desired.getY() > climbMaxSpeed) {
            // Not normally reachable (only upward pitches produce a
            // positive Y component here) — kept as a safety cap.
            desired.setY(climbMaxSpeed);
        }

        // --- Stage 2: ease the ACTUAL velocity toward that desired vector
        // instead of replacing it. This single blend is what removes
        // instant direction snapping — turning, diving, and climbing all
        // ramp smoothly because the whole vector (direction + magnitude)
        // moves a bounded fraction of the way to its target each tick,
        // never jumping straight to it. ---
        Vector current = currentVelocity.getOrDefault(uid, desired);
        Vector blended = current.clone().multiply(1.0 - TURN_SMOOTHING)
                                  .add(desired.clone().multiply(TURN_SMOOTHING));
        currentVelocity.put(uid, blended);

        player.setVelocity(blended);

        // Continuously reset fall distance while actively flying so no
        // fall-damage accrues from the dive itself.
        player.setFallDistance(0f);
    }

    public void stopFlight(Player player) {
        UUID uid = player.getUniqueId();
        disarmDoubleJump(player);

        BukkitTask task = flightTasks.remove(uid);
        if (task != null) task.cancel();
        currentSpeed.remove(uid);
        currentVelocity.remove(uid);

        // Never leave the glide pose stuck once flight actually ends.
        if (player.isOnline()) {
            player.setGliding(false);
        }

        // Brief landing-frame grace window for fall-damage cancellation —
        // NOT a standing immunity. Cleared automatically shortly after.
        recentlyFlying.add(uid);
        plugin.getServer().getScheduler().runTaskLater(plugin,
            () -> recentlyFlying.remove(uid), 10L);
    }

    public void cancelAll() {
        for (Map.Entry<UUID, BukkitTask> entry : flightTasks.entrySet()) {
            entry.getValue().cancel();
            Player p = plugin.getServer().getPlayer(entry.getKey());
            if (p != null && p.isOnline()) {
                p.setGliding(false);
            }
        }
        flightTasks.clear();
        currentSpeed.clear();
        currentVelocity.clear();
        recentlyFlying.clear();
        armedForDoubleJump.clear();
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    private boolean isInLiquid(Player player) {
        return isLiquid(player.getLocation().getBlock().getType())
            || isLiquid(player.getEyeLocation().getBlock().getType());
    }

    private boolean isLiquid(Material m) {
        return m == Material.WATER || m == Material.LAVA;
    }

    private void playLandingEffect(Player player) {
        // Particles intentionally removed — Feather flight must be pure
        // movement with zero visual/cosmetic effects. Landing sound kept
        // as audio-only feedback (not a particle).
        Location loc = player.getLocation();
        loc.getWorld().playSound(loc, Sound.BLOCK_WOOL_STEP, 0.8f, 1.2f);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}

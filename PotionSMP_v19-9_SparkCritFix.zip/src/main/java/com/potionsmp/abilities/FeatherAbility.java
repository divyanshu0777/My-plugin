package com.potionsmp.abilities;

import com.potionsmp.PotionSMP;
import com.potionsmp.managers.FeatherFlightManager;
import com.potionsmp.utils.PotionType;
import com.potionsmp.utils.PotionUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;

/**
 * §f Feather Potion – Feather Flight
 *
 * ACTIVATION — manual double-jump:
 * - Jump and become airborne first. Merely being airborne/falling never
 *   starts Glide by itself.
 * - While still airborne, press Space a SECOND time — that press is the
 *   ONLY activation trigger. One jump with no second press = no Glide.
 * - Mechanically: while airborne with Feather equipped, we grant a
 *   temporary setAllowFlight(true) (see FeatherFlightManager.armDoubleJump)
 *   purely so the client's own double-tap-Space gesture surfaces as a
 *   PlayerToggleFlightEvent — that event below is the single place Glide
 *   actually starts.
 * - Elytra-like flight without an Elytra item, chest slot untouched.
 * - Look direction (pitch/yaw) drives flight: dive to speed up, pull up to
 *   climb (capped), steer left/right naturally.
 * - Fall damage is cancelled only while actively flying (plus a brief
 *   landing-frame grace window) — NOT a standing fall-damage immunity.
 *
 * TERMINATION:
 * - The instant player.isOnGround() is true, Glide stops immediately (the
 *   flight loop checks this every tick — see FeatherFlightManager.tickFlight
 *   / the runTaskTimer body): gliding pose cleared, the movement task
 *   cancelled, all glide state wiped, no more velocity applied afterward,
 *   and it does not auto-reactivate — landing again requires a fresh
 *   jump + second Space.
 * - Same immediate stop on entering water/lava, unequip, death, world
 *   change, or logout. See FeatherFlightManager for the full flight loop
 *   and all stop-condition logic.
 *
 * ACTIVE: None — no ability-key action, same as before.
 */
public class FeatherAbility implements Ability, Listener {

    public void register(PotionSMP plugin) {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public PotionType type() { return PotionType.FEATHER; }

    @Override
    public void onEquip(PotionSMP plugin, Player player) {
        // Activation is manual (jump → airborne → second Space) — equipping
        // never launches flight by itself. If the player happens to already
        // be airborne the moment they drink, arm the double-jump window
        // immediately so they don't need to touch ground first.
        plugin.getFeatherFlightManager().armDoubleJump(player);

        if (!PotionUtils.isQuiet()) {
            player.sendMessage("§fFeather Glide ready — jump, then press Space again mid-air!");
        }
    }

    @Override
    public void onUnequip(PotionSMP plugin, Player player) {
        plugin.getFeatherFlightManager().stopFlight(player);
    }

    // ── Double-jump arming: opens/closes the window each airborne/ground
    //    move tick. Never starts flight by itself — see onToggleFlight. ────
    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player player = e.getPlayer();
        if (!PotionSMP.getInstance().getSlotManager()
                .hasEquipped(player.getUniqueId(), PotionType.FEATHER)) {
            return;
        }
        FeatherFlightManager mgr = PotionSMP.getInstance().getFeatherFlightManager();
        if (player.isOnGround()) {
            mgr.disarmDoubleJump(player);
        } else {
            mgr.armDoubleJump(player);
        }
    }

    // ── The single activation trigger: the client's double-tap-Space
    //    gesture, surfaced via the temporary allow-flight grant above. ─────
    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        Player player = e.getPlayer();
        FeatherFlightManager mgr = PotionSMP.getInstance().getFeatherFlightManager();
        if (!mgr.isArmed(player.getUniqueId())) return; // not our grant — leave it alone

        // Always cancel: this allow-flight was only ever meant to catch the
        // double-tap gesture, never to grant real creative-style flight.
        e.setCancelled(true);

        if (e.isFlying()) {
            mgr.tryActivateFromDoubleJump(player);
        } else {
            mgr.disarmDoubleJump(player);
        }
    }

    // ── Stop conditions not already covered by the flight loop itself ─────
    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        PotionSMP.getInstance().getFeatherFlightManager().stopFlight(e.getEntity());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        PotionSMP.getInstance().getFeatherFlightManager().stopFlight(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        PotionSMP.getInstance().getFeatherFlightManager().stopFlight(e.getPlayer());
    }

    // ── Fall damage cancel — only while actually flying (or the brief
    //    landing-frame grace window), never just because Feather is
    //    equipped. ─────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onFallDamage(EntityDamageEvent e) {
        if (e.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        if (!(e.getEntity() instanceof Player p)) return;
        if (PotionSMP.getInstance().getFeatherFlightManager()
                .shouldCancelFallDamage(p.getUniqueId())) {
            e.setCancelled(true);
        }
    }

    // ── Active: none ──────────────────────────────────────────────────────
    @Override
    public ActivationResult activate(PotionSMP plugin, Player player) {
        player.sendActionBar(net.kyori.adventure.text.Component.text(
            "§fFeather Potion has no active ability — it's fully passive!"));
        return ActivationResult.SUCCESS;
    }
}
